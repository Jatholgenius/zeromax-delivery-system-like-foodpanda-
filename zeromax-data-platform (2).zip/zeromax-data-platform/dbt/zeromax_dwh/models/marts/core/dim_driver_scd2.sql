{{
  config(
    materialized='table',
    cluster_by=['driver_id'],
    tags=['gold', 'dimension', 'scd_type2', 'driver'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter",
      "GRANT SELECT ON {{ this }} TO ROLE analyst"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: DIM_DRIVER (SCD Type 2)
-- ============================================================
-- Slowly Changing Dimension Type 2 for drivers.
-- Tracks historical changes to driver attributes.
-- Each change creates a new row with validity period.
-- ============================================================

WITH current_source AS (
    SELECT
        driver_id,
        driver_name,
        phone,
        email,
        experience_years,
        experience_level,
        vehicle_type,
        vehicle_id,
        home_zone,
        base_rating,
        speed_factor,
        efficiency_score,
        status,
        hire_date,
        shift_start_hour,
        shift_end_hour,
        
        -- Generate hash for change detection
        MD5(
            CONCAT_WS('|',
                COALESCE(driver_name, ''),
                COALESCE(CAST(experience_years AS VARCHAR), '0'),
                COALESCE(experience_level, ''),
                COALESCE(vehicle_type, ''),
                COALESCE(home_zone, ''),
                COALESCE(CAST(base_rating AS VARCHAR), '0'),
                COALESCE(CAST(speed_factor AS VARCHAR), '0'),
                COALESCE(CAST(efficiency_score AS VARCHAR), '0'),
                COALESCE(status, ''),
                COALESCE(CAST(shift_start_hour AS VARCHAR), '0'),
                COALESCE(CAST(shift_end_hour AS VARCHAR), '0')
            )
        ) AS row_hash,
        
        updated_at AS source_updated_at
        
    FROM {{ ref('stg_driver') }}
    WHERE driver_id IS NOT NULL
),

-- Get existing latest records
existing_latest AS (
    SELECT *
    FROM {{ this }}
    WHERE is_current = TRUE
),

-- Identify new drivers
new_drivers AS (
    SELECT
        cs.*,
        'INSERT' AS dml_type,
        {{ dbt_utils.generate_surrogate_key(['cs.driver_id', 'cs.source_updated_at']) }} AS driver_sk
    FROM current_source cs
    LEFT JOIN existing_latest el
        ON cs.driver_id = el.driver_id
    WHERE el.driver_id IS NULL
),

-- Identify changed drivers
changed_drivers AS (
    SELECT
        cs.*,
        'UPDATE' AS dml_type,
        el.driver_sk
    FROM current_source cs
    INNER JOIN existing_latest el
        ON cs.driver_id = el.driver_id
    WHERE cs.row_hash != el.row_hash
),

-- Identify unchanged drivers (carry forward)
unchanged_drivers AS (
    SELECT
        el.*,
        'NO_CHANGE' AS dml_type
    FROM existing_latest el
    INNER JOIN current_source cs
        ON el.driver_id = cs.driver_id
    WHERE cs.row_hash = el.row_hash
),

-- Combine all records
all_records AS (
    SELECT
        driver_sk,
        driver_id,
        driver_name,
        phone,
        email,
        experience_years,
        experience_level,
        vehicle_type,
        vehicle_id,
        home_zone,
        base_rating,
        speed_factor,
        efficiency_score,
        status,
        hire_date,
        shift_start_hour,
        shift_end_hour,
        row_hash,
        dml_type,
        
        -- Validity period
        CURRENT_TIMESTAMP() AS valid_from,
        TO_TIMESTAMP('9999-12-31 23:59:59') AS valid_to,
        TRUE AS is_current,
        
        -- Metadata
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'dim_driver_scd2' AS dw_source
        
    FROM new_drivers
    
    UNION ALL
    
    SELECT
        driver_sk,
        driver_id,
        driver_name,
        phone,
        email,
        experience_years,
        experience_level,
        vehicle_type,
        vehicle_id,
        home_zone,
        base_rating,
        speed_factor,
        efficiency_score,
        status,
        hire_date,
        shift_start_hour,
        shift_end_hour,
        row_hash,
        dml_type,
        CURRENT_TIMESTAMP() AS valid_from,
        TO_TIMESTAMP('9999-12-31 23:59:59') AS valid_to,
        TRUE AS is_current,
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'dim_driver_scd2' AS dw_source
    FROM changed_drivers
    
    UNION ALL
    
    SELECT
        driver_sk,
        driver_id,
        driver_name,
        phone,
        email,
        experience_years,
        experience_level,
        vehicle_type,
        vehicle_id,
        home_zone,
        base_rating,
        speed_factor,
        efficiency_score,
        status,
        hire_date,
        shift_start_hour,
        shift_end_hour,
        row_hash,
        dml_type,
        valid_from,
        valid_to,
        is_current,
        dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'dim_driver_scd2' AS dw_source
    FROM unchanged_drivers
)

SELECT
    -- Surrogate Key
    driver_sk,
    
    -- Natural Key
    driver_id,
    
    -- Attributes (tracked for changes)
    driver_name,
    phone,
    email,
    experience_years,
    experience_level,
    vehicle_type,
    vehicle_id,
    home_zone,
    base_rating,
    speed_factor,
    efficiency_score,
    status,
    hire_date,
    shift_start_hour,
    shift_end_hour,
    
    -- Derived Attributes
    CASE
        WHEN experience_years < 1 THEN 'Novice (<1 yr)'
        WHEN experience_years < 3 THEN 'Intermediate (1-3 yr)'
        WHEN experience_years < 5 THEN 'Experienced (3-5 yr)'
        ELSE 'Veteran (5+ yr)'
    END AS experience_category,
    
    CASE
        WHEN base_rating >= 4.5 THEN 'Top Performer'
        WHEN base_rating >= 4.0 THEN 'Strong Performer'
        WHEN base_rating >= 3.5 THEN 'Average Performer'
        WHEN base_rating >= 3.0 THEN 'Below Average'
        ELSE 'Needs Improvement'
    END AS performance_category,
    
    -- Validity Period
    valid_from,
    valid_to,
    is_current,
    
    -- Change Tracking
    row_hash,
    dml_type AS change_type,
    
    -- Metadata
    dw_created_at,
    dw_updated_at,
    dw_source

FROM all_records

-- Ensure no duplicate active records
QUALIFY ROW_NUMBER() OVER (
    PARTITION BY driver_id 
    ORDER BY valid_from DESC
) = 1