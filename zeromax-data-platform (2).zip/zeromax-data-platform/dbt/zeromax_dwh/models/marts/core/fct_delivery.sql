{{
  config(
    materialized='incremental',
    unique_key='delivery_sk',
    partition_by={
      "field": "order_datetime",
      "data_type": "timestamp",
      "granularity": "day"
    },
    cluster_by=['zone_key', 'date_key', 'driver_sk'],
    tags=['gold', 'fact', 'critical', 'star_schema'],
    on_schema_change='append_new_columns'
  )
}}

-- ============================================================
-- GOLD LAYER: FCT_DELIVERY
-- ============================================================
-- Core fact table for delivery analytics.
-- Granularity: One row per delivery order.
-- Surrogate keys resolve to current dimension versions.
-- ============================================================

WITH delivery_enriched AS (
    SELECT *
    FROM {{ ref('int_delivery_enriched') }}
    {% if is_incremental() %}
    WHERE order_datetime > (SELECT MAX(order_datetime) FROM {{ this }})
    {% endif %}
),

-- Resolve surrogate keys from dimensions
fact_data AS (
    SELECT
        -- ==========================================
        -- SURROGATE KEYS (Primary & Foreign)
        -- ==========================================
        {{ dbt_utils.generate_surrogate_key(['de.delivery_id', 'de.order_datetime']) }} AS delivery_sk,
        
        -- Dimension surrogate keys (resolve at current point-in-time)
        dd.driver_sk,
        dc.customer_sk,
        dr.restaurant_sk,
        dz.zone_sk,
        dd_date.date_sk,
        dt.time_sk,
        dw.weather_sk,
        dtr.traffic_sk,
        dv.vehicle_sk,
        dp.payment_sk,
        dcn.cancel_sk,
        
        -- ==========================================
        -- NATURAL KEYS (for lineage & debugging)
        -- ==========================================
        de.delivery_id,
        de.order_id,
        de.driver_id,
        de.customer_id,
        de.restaurant_id,
        de.zone_id,
        
        -- ==========================================
        -- TEMPORAL DIMENSIONS
        -- ==========================================
        de.order_datetime,
        dd_date.full_date AS order_date,
        dt.hour AS order_hour,
        dt.period AS time_period,
        dt.peak_status,
        dt.is_peak_hour,
        dt.is_night,
        
        -- Calendar attributes
        dd_date.day_name,
        dd_date.is_weekend,
        dd_date.is_friday,
        dd_date.is_holiday,
        dd_date.holiday_name,
        dd_date.is_ramadan,
        dd_date.is_eid,
        dd_date.is_eid_adha,
        dd_date.season,
        dd_date.demand_multiplier,
        
        -- ==========================================
        -- GEOGRAPHICAL DIMENSIONS
        -- ==========================================
        de.cust_lat,
        de.cust_lon,
        de.rest_lat,
        de.rest_lon,
        dz.zone_name AS delivery_zone,
        dz.avg_base_time_min AS zone_avg_time,
        dz.traffic_factor AS zone_traffic_factor,
        
        -- ==========================================
        -- DISTANCE & ROUTE METRICS
        -- ==========================================
        de.distance_km,
        de.optimal_distance_km,
        de.route_efficiency_pct,
        
        -- Distance category
        {{ distance_category('de.distance_km') }} AS distance_category,
        
        -- ==========================================
        -- TIME METRICS (Minutes)
        -- ==========================================
        de.preparation_time_min,
        de.pickup_delay_min,
        de.travel_time_base_min,
        de.travel_time_actual_min,
        de.delivery_duration_min,
        de.expected_duration_min,
        de.promised_duration_min,
        de.delay_min,
        
        -- Delay analysis
        CASE
            WHEN de.delay_min <= 0 THEN 'On-Time / Early'
            WHEN de.delay_min <= 5 THEN 'Minor (≤5 min)'
            WHEN de.delay_min <= 15 THEN 'Moderate (6-15 min)'
            WHEN de.delay_min <= 30 THEN 'Major (16-30 min)'
            ELSE 'Critical (>30 min)'
        END AS delay_severity,
        
        -- SLA Compliance
        CASE WHEN de.delivery_duration_min <= {{ var('delivery_sla_minutes', 35) }} 
             THEN TRUE ELSE FALSE 
        END AS within_sla,
        
        -- ==========================================
        -- DELIVERY STATUS
        -- ==========================================
        de.delivery_status,
        de.delay_category,
        
        -- Status flags for easy filtering
        CASE WHEN de.delivery_status = 'On-Time' THEN 1 ELSE 0 END AS is_on_time,
        CASE WHEN de.delivery_status = 'Late' THEN 1 ELSE 0 END AS is_late,
        CASE WHEN de.delivery_status = 'Failed' THEN 1 ELSE 0 END AS is_failed,
        
        -- ==========================================
        -- CUSTOMER SATISFACTION
        -- ==========================================
        de.customer_rating,
        
        -- Rating category
        CASE
            WHEN de.customer_rating >= 4.5 THEN 'Excellent'
            WHEN de.customer_rating >= 4.0 THEN 'Good'
            WHEN de.customer_rating >= 3.0 THEN 'Average'
            WHEN de.customer_rating >= 2.0 THEN 'Poor'
            WHEN de.customer_rating IS NOT NULL THEN 'Very Poor'
            ELSE 'Not Rated'
        END AS rating_category,
        
        -- ==========================================
        -- FINANCIAL METRICS (PKR)
        -- ==========================================
        de.delivery_fee_pkr,
        de.driver_cost_pkr,
        de.platform_fee_pkr,
        de.delay_penalty_pkr,
        de.profit_pkr,
        
        -- Profit margin calculation
        ROUND(
            CASE 
                WHEN de.delivery_fee_pkr > 0 
                THEN (de.profit_pkr * 100.0 / de.delivery_fee_pkr)
                ELSE 0 
            END, 2
        ) AS profit_margin_pct,
        
        -- Profitability flag
        CASE 
            WHEN de.profit_pkr > 100 THEN 'High Profit'
            WHEN de.profit_pkr > 0 THEN 'Profitable'
            WHEN de.profit_pkr = 0 THEN 'Break-Even'
            ELSE 'Loss'
        END AS profitability,
        
        -- ==========================================
        -- VEHICLE & DRIVER ATTRIBUTES
        -- ==========================================
        dv.vehicle_type,
        dv.vehicle_category,
        dv.cost_per_km,
        dv.speed_kmh AS vehicle_speed,
        dv.fuel_efficiency,
        
        dd.driver_name,
        dd.experience_level,
        dd.home_zone AS driver_home_zone,
        dd.base_rating AS driver_base_rating,
        dd.speed_factor,
        dd.efficiency_score,
        
        -- Driver experience category
        CASE 
            WHEN dd.experience_years < 1 THEN 'Novice (<1 yr)'
            WHEN dd.experience_years < 3 THEN 'Intermediate (1-3 yr)'
            WHEN dd.experience_years < 5 THEN 'Experienced (3-5 yr)'
            ELSE 'Veteran (5+ yr)'
        END AS driver_experience_category,
        
        -- ==========================================
        -- CUSTOMER ATTRIBUTES
        -- ==========================================
        dc.customer_name,
        dc.customer_type,
        dc.loyalty_tier AS customer_loyalty_tier,
        de.customer_tenure_days,
        
        -- Customer tenure category
        CASE
            WHEN de.customer_tenure_days <= 30 THEN 'New (≤30 days)'
            WHEN de.customer_tenure_days <= 90 THEN 'Recent (31-90 days)'
            WHEN de.customer_tenure_days <= 180 THEN 'Established (91-180 days)'
            WHEN de.customer_tenure_days <= 365 THEN 'Loyal (181-365 days)'
            ELSE 'Long-term (365+ days)'
        END AS customer_tenure_category,
        
        -- ==========================================
        -- PAYMENT DETAILS
        -- ==========================================
        dp.payment_method,
        dp.is_cod,
        dp.fee_pct AS payment_fee_pct,
        
        -- ==========================================
        -- ENVIRONMENTAL FACTORS
        -- ==========================================
        dw.weather_condition,
        dw.weather_severity,
        dw.temperature_c,
        dw.humidity_pct,
        dw.wind_speed_kmh,
        dw.weather_delay_multiplier,
        
        dtr.traffic_level,
        dtr.traffic_severity,
        dtr.traffic_delay_multiplier,
        
        -- Combined severity index
        (dw.weather_severity * dtr.traffic_severity) AS severity_index,
        
        -- ==========================================
        -- RESTAURANT DETAILS
        -- ==========================================
        dr.restaurant_name,
        dr.restaurant_type,
        dr.avg_prep_time_min AS restaurant_avg_prep_time,
        dr.restaurant_zone,
        
        -- ==========================================
        -- CANCELLATION DETAILS (if applicable)
        -- ==========================================
        dcn.cancellation_reason,
        dcn.cancellation_category,
        dcn.is_controllable_cancel,
        
        -- ==========================================
        -- OPERATIONAL FLAGS
        -- ==========================================
        de.fatigue_factor,
        
        -- ==========================================
        -- METADATA
        -- ==========================================
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'fct_delivery' AS dw_source,
        '{{ invocation_id }}' AS dbt_run_id
        
    FROM delivery_enriched de
    
    -- Join current dimension versions (point-in-time lookup)
    LEFT JOIN {{ ref('dim_driver_scd2') }} dd
        ON de.driver_id = dd.driver_id
        AND de.order_datetime BETWEEN dd.valid_from AND dd.valid_to
    
    LEFT JOIN {{ ref('dim_customer_scd2') }} dc
        ON de.customer_id = dc.customer_id
        AND de.order_datetime BETWEEN dc.valid_from AND dc.valid_to
    
    LEFT JOIN {{ ref('dim_restaurant') }} dr
        ON de.restaurant_id = dr.restaurant_id
    
    LEFT JOIN {{ ref('dim_zone') }} dz
        ON de.zone_id = dz.zone_id
    
    LEFT JOIN {{ ref('dim_date') }} dd_date
        ON de.date_key = dd_date.date_key
    
    LEFT JOIN {{ ref('dim_time') }} dt
        ON de.time_key = dt.time_key
    
    LEFT JOIN {{ ref('dim_weather') }} dw
        ON de.weather_key = dw.weather_key
    
    LEFT JOIN {{ ref('dim_traffic') }} dtr
        ON de.traffic_key = dtr.traffic_key
    
    LEFT JOIN {{ ref('dim_vehicle') }} dv
        ON de.vehicle_key = dv.vehicle_key
    
    LEFT JOIN {{ ref('dim_payment') }} dp
        ON de.payment_key = dp.payment_key
    
    LEFT JOIN {{ ref('dim_cancellation') }} dcn
        ON de.cancel_key = dcn.cancel_key
)

SELECT * FROM fact_data