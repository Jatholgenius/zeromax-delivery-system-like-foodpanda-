{{
  config(
    materialized='table',
    tags=['gold', 'dimension', 'date', 'static', 'calendar'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter",
      "GRANT SELECT ON {{ this }} TO ROLE analyst"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: DIM_DATE
-- ============================================================
-- Calendar date dimension for 2024 (leap year: 366 days).
-- Includes Islamic calendar events (Ramadan, Eid).
-- ============================================================

WITH date_spine AS (
    {{ dbt_utils.date_spine(
        datepart="day",
        start_date="'2024-01-01'",
        end_date="'2024-12-31'"
    ) }}
),

pakistan_holidays AS (
    SELECT * FROM (VALUES
        ('2024-01-01', 'New Year\'s Day'),
        ('2024-02-05', 'Kashmir Solidarity Day'),
        ('2024-03-23', 'Pakistan Day'),
        ('2024-05-01', 'Labour Day'),
        ('2024-08-14', 'Independence Day'),
        ('2024-11-09', 'Iqbal Day'),
        ('2024-12-25', 'Quaid-e-Azam Day'),
        ('2024-03-11', 'Ramadan Start'),
        ('2024-04-09', 'Ramadan End'),
        ('2024-04-10', 'Eid-ul-Fitr Day 1'),
        ('2024-04-11', 'Eid-ul-Fitr Day 2'),
        ('2024-04-12', 'Eid-ul-Fitr Day 3'),
        ('2024-06-17', 'Eid-ul-Adha Day 1'),
        ('2024-06-18', 'Eid-ul-Adha Day 2'),
        ('2024-06-19', 'Eid-ul-Adha Day 3')
    ) AS h(holiday_date, holiday_name)
),

date_enriched AS (
    SELECT
        -- Surrogate Key
        ROW_NUMBER() OVER (ORDER BY date_day) AS date_sk,
        
        -- Date Values
        date_day AS full_date,
        EXTRACT(YEAR FROM date_day) AS year,
        EXTRACT(QUARTER FROM date_day) AS quarter_num,
        'Q' || EXTRACT(QUARTER FROM date_day) AS quarter,
        EXTRACT(MONTH FROM date_day) AS month_num,
        TO_CHAR(date_day, 'Month') AS month_name,
        TO_CHAR(date_day, 'Mon') AS month_abbr,
        EXTRACT(WEEK FROM date_day) AS week_num,
        EXTRACT(DAY FROM date_day) AS day_of_month,
        EXTRACT(DOY FROM date_day) AS day_of_year,
        
        -- Day Names
        TO_CHAR(date_day, 'Day') AS day_name,
        TO_CHAR(date_day, 'Dy') AS day_abbr,
        EXTRACT(DOW FROM date_day) AS day_of_week,  -- 0=Sun, 6=Sat
        
        -- Week Flags
        CASE WHEN EXTRACT(DOW FROM date_day) IN (5, 6) THEN TRUE ELSE FALSE END AS is_weekend,
        CASE WHEN EXTRACT(DOW FROM date_day) NOT IN (5, 6) THEN TRUE ELSE FALSE END AS is_weekday,
        CASE WHEN EXTRACT(DOW FROM date_day) = 4 THEN TRUE ELSE FALSE END AS is_friday,  -- Jummah
        
        -- Month Flags
        CASE 
            WHEN EXTRACT(DAY FROM date_day) = 1 THEN TRUE 
            ELSE FALSE 
        END AS is_first_day_of_month,
        CASE 
            WHEN date_day = LAST_DAY(date_day) THEN TRUE 
            ELSE FALSE 
        END AS is_last_day_of_month,
        
        -- Year Flags
        CASE 
            WHEN EXTRACT(MONTH FROM date_day) = 1 AND EXTRACT(DAY FROM date_day) = 1 
            THEN TRUE ELSE FALSE 
        END AS is_first_day_of_year,
        CASE 
            WHEN EXTRACT(MONTH FROM date_day) = 12 AND EXTRACT(DAY FROM date_day) = 31 
            THEN TRUE ELSE FALSE 
        END AS is_last_day_of_year,
        
        -- Season
        CASE
            WHEN EXTRACT(MONTH FROM date_day) IN (12, 1, 2) THEN 'Winter'
            WHEN EXTRACT(MONTH FROM date_day) IN (3, 4) THEN 'Spring'
            WHEN EXTRACT(MONTH FROM date_day) IN (5, 6, 7, 8, 9) THEN 'Summer'
            WHEN EXTRACT(MONTH FROM date_day) IN (10, 11) THEN 'Autumn'
        END AS season,
        
        CASE 
            WHEN EXTRACT(MONTH FROM date_day) BETWEEN 5 AND 9 THEN TRUE 
            ELSE FALSE 
        END AS is_summer,
        
        -- Holidays
        ph.holiday_name,
        CASE WHEN ph.holiday_date IS NOT NULL THEN TRUE ELSE FALSE END AS is_holiday,
        
        -- Islamic Calendar Events
        CASE 
            WHEN date_day BETWEEN '2024-03-11' AND '2024-04-09' THEN TRUE 
            ELSE FALSE 
        END AS is_ramadan,
        CASE 
            WHEN date_day IN ('2024-04-10', '2024-04-11', '2024-04-12') THEN TRUE 
            ELSE FALSE 
        END AS is_eid_ul_fitr,
        CASE 
            WHEN date_day IN ('2024-06-17', '2024-06-18', '2024-06-19') THEN TRUE 
            ELSE FALSE 
        END AS is_eid_ul_adha,
        CASE 
            WHEN date_day IN ('2024-04-10', '2024-04-11', '2024-04-12', '2024-06-17', '2024-06-18', '2024-06-19') 
            THEN TRUE ELSE FALSE 
        END AS is_eid,
        
        -- Demand Multiplier
        CASE
            WHEN date_day IN ('2024-04-10', '2024-04-11', '2024-04-12') THEN 1.50  -- Eid-ul-Fitr
            WHEN date_day IN ('2024-06-17', '2024-06-18', '2024-06-19') THEN 1.50  -- Eid-ul-Adha
            WHEN date_day BETWEEN '2024-03-11' AND '2024-04-09' THEN 1.35  -- Ramadan
            WHEN EXTRACT(DOW FROM date_day) = 4 THEN 1.20  -- Friday
            WHEN EXTRACT(DOW FROM date_day) IN (5, 6) THEN 1.10  -- Weekend
            WHEN ph.holiday_date IS NOT NULL THEN 1.15
            ELSE 1.00
        END AS demand_multiplier,
        
        -- Day Number
        EXTRACT(DOY FROM date_day) AS date_key,  -- 1-366
        
        -- Metadata
        CURRENT_TIMESTAMP() AS dw_created_at,
        'dim_date' AS dw_source
        
    FROM date_spine ds
    LEFT JOIN pakistan_holidays ph
        ON ds.date_day = ph.holiday_date
)

SELECT * FROM date_enriched
ORDER BY full_date