"""
================================================================================
ZEROMAX LOGISTICS - BRONZE LAYER CHECKPOINT
================================================================================
Great Expectations checkpoint for Bronze layer validation.
Validates raw data before transformation to Silver.

Checks:
- File arrival and completeness
- Schema compliance
- Row count thresholds
- Null rates in critical fields
- Duplicate detection
================================================================================
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import Dict, List

from great_expectations.checkpoint import Checkpoint
from great_expectations.data_context import BaseDataContext
from great_expectations.core.batch import BatchRequest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ============================================
# BRONZE LAYER CONFIGURATION
# ============================================

BRONZE_TABLES = {
    "delivery_events": {
        "source": "bronze_files",
        "pattern": "bronze/delivery_events/**/*.parquet",
        "suite": "bronze_delivery_suite",
        "min_files": 1,
        "critical": True,
    },
    "driver_data": {
        "source": "bronze_files",
        "pattern": "bronze/dim_driver/*.parquet",
        "suite": "bronze_driver_suite",
        "min_files": 1,
        "critical": True,
    },
    "customer_data": {
        "source": "bronze_files",
        "pattern": "bronze/dim_customer/*.parquet",
        "suite": "bronze_customer_suite",
        "min_files": 1,
        "critical": True,
    },
    "restaurant_data": {
        "source": "bronze_files",
        "pattern": "bronze/dim_restaurant/*.parquet",
        "suite": "bronze_restaurant_suite",
        "min_files": 1,
        "critical": True,
    },
    "weather_api": {
        "source": "bronze_files",
        "pattern": "bronze/weather_api/**/*.parquet",
        "suite": "bronze_weather_suite",
        "min_files": 1,
        "critical": False,
    },
    "traffic_api": {
        "source": "bronze_files",
        "pattern": "bronze/traffic_api/**/*.parquet",
        "suite": "bronze_traffic_suite",
        "min_files": 1,
        "critical": False,
    },
}

BRONZE_VALIDATION_RULES = {
    "min_rows_per_file": 1,
    "max_null_rate_pct": 5.0,
    "max_duplicate_rate_pct": 1.0,
    "max_file_age_hours": 6,
    "required_columns": {
        "delivery_events": ["delivery_id", "order_id", "customer_id", "restaurant_id", "order_datetime"],
        "driver_data": ["driver_id", "driver_name", "experience_level", "vehicle_type"],
        "customer_data": ["customer_id", "customer_name", "zone_id", "join_date"],
        "restaurant_data": ["restaurant_id", "restaurant_name", "cuisine_type", "zone_id"],
    },
}


class BronzeLayerValidator:
    """
    Validates Bronze layer data quality.
    Checks file arrival, completeness, and basic quality.
    """
    
    def __init__(self, context: BaseDataContext):
        self.context = context
        self.results: Dict = {}
        self.validation_summary: Dict = {}
    
    def check_file_arrival(self, table_key: str, config: Dict) -> Dict:
        """
        Check if expected files have arrived in Bronze layer.
        
        Args:
            table_key: Table identifier
            config: Table configuration
            
        Returns:
            Validation result dict
        """
        import glob
        
        pattern = config["pattern"]
        min_files = config.get("min_files", 1)
        
        files = glob.glob(pattern, recursive=True) if "*" in pattern else []
        
        result = {
            "table": table_key,
            "check": "file_arrival",
            "files_found": len(files),
            "min_expected": min_files,
            "status": "PASS" if len(files) >= min_files else "FAIL",
            "details": files[:5] if files else [],
        }
        
        if result["status"] == "PASS":
            logger.info(f"✅ {table_key}: {len(files)} files found")
        else:
            logger.warning(f"⚠️  {table_key}: Only {len(files)}/{min_files} files found")
        
        return result
    
    def check_row_counts(self, table_key: str, df) -> Dict:
        """
        Check row count thresholds.
        
        Args:
            table_key: Table identifier
            df: DataFrame to check
            
        Returns:
            Validation result
        """
        row_count = len(df)
        min_rows = BRONZE_VALIDATION_RULES["min_rows_per_file"]
        
        result = {
            "table": table_key,
            "check": "row_count",
            "row_count": row_count,
            "min_expected": min_rows,
            "status": "PASS" if row_count >= min_rows else "FAIL",
        }
        
        logger.info(f"  {table_key}: {row_count:,} rows")
        return result
    
    def check_null_rates(self, table_key: str, df) -> List[Dict]:
        """
        Check null rates in critical columns.
        
        Args:
            table_key: Table identifier
            df: DataFrame to check
            
        Returns:
            List of null rate results
        """
        required_cols = BRONZE_VALIDATION_RULES["required_columns"].get(table_key, [])
        max_null_rate = BRONZE_VALIDATION_RULES["max_null_rate_pct"]
        
        results = []
        
        for col in required_cols:
            if col in df.columns:
                null_count = df[col].isnull().sum()
                null_rate = (null_count / len(df)) * 100 if len(df) > 0 else 0
                
                result = {
                    "table": table_key,
                    "column": col,
                    "check": "null_rate",
                    "null_count": null_count,
                    "null_rate_pct": round(null_rate, 2),
                    "threshold_pct": max_null_rate,
                    "status": "PASS" if null_rate <= max_null_rate else "FAIL",
                }
                
                if result["status"] == "FAIL":
                    logger.warning(f"  ⚠️  {table_key}.{col}: {null_rate:.1f}% null")
                
                results.append(result)
        
        return results
    
    def check_duplicates(self, table_key: str, df, key_columns: List[str] = None) -> Dict:
        """
        Check for duplicate records.
        
        Args:
            table_key: Table identifier
            df: DataFrame to check
            key_columns: Columns to check for duplicates
            
        Returns:
            Validation result
        """
        max_dup_rate = BRONZE_VALIDATION_RULES["max_duplicate_rate_pct"]
        
        if key_columns:
            duplicate_count = df.duplicated(subset=key_columns).sum()
        else:
            duplicate_count = df.duplicated().sum()
        
        dup_rate = (duplicate_count / len(df)) * 100 if len(df) > 0 else 0
        
        result = {
            "table": table_key,
            "check": "duplicates",
            "duplicate_count": duplicate_count,
            "duplicate_rate_pct": round(dup_rate, 2),
            "threshold_pct": max_dup_rate,
            "status": "PASS" if dup_rate <= max_dup_rate else "FAIL",
        }
        
        if duplicate_count > 0:
            logger.warning(f"  ⚠️  {table_key}: {duplicate_count} duplicates ({dup_rate:.1f}%)")
        
        return result
    
    def check_file_freshness(self, table_key: str) -> Dict:
        """
        Check if files are recent.
        
        Args:
            table_key: Table identifier
            
        Returns:
            Validation result
        """
        import glob
        import os
        
        pattern = BRONZE_TABLES[table_key]["pattern"]
        files = glob.glob(pattern, recursive=True) if "*" in pattern else []
        
        max_age_hours = BRONZE_VALIDATION_RULES["max_file_age_hours"]
        stale_files = []
        
        for file_path in files:
            mtime = datetime.fromtimestamp(os.path.getmtime(file_path))
            age_hours = (datetime.now() - mtime).total_seconds() / 3600
            
            if age_hours > max_age_hours:
                stale_files.append({"file": file_path, "age_hours": round(age_hours, 1)})
        
        result = {
            "table": table_key,
            "check": "file_freshness",
            "total_files": len(files),
            "stale_files": len(stale_files),
            "max_age_hours": max_age_hours,
            "status": "PASS" if len(stale_files) == 0 else "WARN",
            "stale_details": stale_files[:5],
        }
        
        if stale_files:
            logger.warning(f"  ⚠️  {table_key}: {len(stale_files)} stale files")
        
        return result
    
    def validate_all(self) -> Dict:
        """
        Run all Bronze layer validations.
        
        Returns:
            Validation summary
        """
        import pandas as pd
        
        logger.info("=" * 60)
        logger.info("🔍 BRONZE LAYER VALIDATION")
        logger.info("=" * 60)
        
        all_results = []
        
        for table_key, config in BRONZE_TABLES.items():
            logger.info(f"\n📋 Checking: {table_key}")
            
            # Check file arrival
            arrival_result = self.check_file_arrival(table_key, config)
            all_results.append(arrival_result)
            
            if arrival_result["status"] == "FAIL":
                logger.warning(f"  Skipping {table_key} - no files found")
                continue
            
            # Try to read data
            try:
                import glob
                files = glob.glob(config["pattern"], recursive=True)
                
                if files:
                    df = pd.read_parquet(files[0])  # Sample first file
                    
                    # Row count
                    all_results.append(self.check_row_counts(table_key, df))
                    
                    # Null rates
                    all_results.extend(self.check_null_rates(table_key, df))
                    
                    # Duplicates
                    all_results.append(self.check_duplicates(table_key, df))
                    
                    # File freshness
                    all_results.append(self.check_file_freshness(table_key))
                    
            except Exception as e:
                logger.error(f"  ❌ Error reading {table_key}: {e}")
                all_results.append({
                    "table": table_key,
                    "check": "read_error",
                    "error": str(e),
                    "status": "ERROR",
                })
        
        # Build summary
        total = len(all_results)
        passed = sum(1 for r in all_results if r.get("status") == "PASS")
        failed = sum(1 for r in all_results if r.get("status") == "FAIL")
        warnings = sum(1 for r in all_results if r.get("status") in ["WARN", "ERROR"])
        
        self.validation_summary = {
            "layer": "BRONZE",
            "timestamp": datetime.now().isoformat(),
            "total_checks": total,
            "passed": passed,
            "failed": failed,
            "warnings": warnings,
            "overall_status": "PASS" if failed == 0 else "FAIL",
            "results": all_results,
        }
        
        return self.validation_summary
    
    def print_summary(self) -> None:
        """Print validation summary."""
        s = self.validation_summary
        
        print("\n" + "=" * 60)
        print("🏅 BRONZE LAYER VALIDATION SUMMARY")
        print("=" * 60)
        print(f"  Status:   {s.get('overall_status', 'UNKNOWN')}")
        print(f"  Checks:   {s.get('total_checks', 0)}")
        print(f"  Passed:   {s.get('passed', 0)} ✅")
        print(f"  Failed:   {s.get('failed', 0)} ❌")
        print(f"  Warnings: {s.get('warnings', 0)} ⚠️")
        print("=" * 60)
        
        # Print failures
        failures = [r for r in s.get("results", []) if r.get("status") in ["FAIL", "ERROR"]]
        if failures:
            print("\n🚨 FAILURES:")
            for f in failures:
                print(f"  • {f.get('table', '')}: {f.get('check', '')} - {f.get('status', '')}")
    
    def save_report(self, filename: str = None) -> str:
        """Save report to JSON."""
        if filename is None:
            os.makedirs("reports", exist_ok=True)
            filename = f"reports/bronze_validation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, "w") as f:
            json.dump(self.validation_summary, f, indent=2, default=str)
        
        logger.info(f"📄 Report saved: {filename}")
        return filename


def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Bronze Layer Validator")
    parser.add_argument("--output", type=str, help="Output report path")
    parser.add_argument("--strict", action="store_true", help="Exit with error on failure")
    args = parser.parse_args()
    
    # Get GE context (or use standalone mode)
    try:
        context = BaseDataContext(project_root_dir=".")
    except Exception:
        logger.warning("No GE context found, running in standalone mode")
        context = None
    
    validator = BronzeLayerValidator(context)
    validator.validate_all()
    validator.print_summary()
    
    if args.output:
        validator.save_report(args.output)
    else:
        validator.save_report()
    
    if args.strict and validator.validation_summary.get("overall_status") == "FAIL":
        sys.exit(1)


if __name__ == "__main__":
    main()