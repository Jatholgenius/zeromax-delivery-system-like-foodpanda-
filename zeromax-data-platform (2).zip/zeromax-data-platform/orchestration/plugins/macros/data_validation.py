"""
================================================================================
ZEROMAX LOGISTICS - DATA VALIDATION MACROS
================================================================================
Custom Jinja macros for data validation in Airflow templates.
Available in all DAGs automatically.
================================================================================
"""

from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional


def validate_not_null(value: Any, field_name: str = "value") -> str:
    """
    Validate that a value is not null/empty.
    
    Usage in DAG:
        {{ validate_not_null(task_instance.xcom_pull('key'), 'delivery_id') }}
    """
    if value is None or value == "":
        return f"⚠️  {field_name} is NULL or empty"
    return f"✅ {field_name}: {value}"


def validate_range(
    value: float,
    min_val: float,
    max_val: float,
    field_name: str = "value",
) -> str:
    """
    Validate that a value is within range.
    
    Usage:
        {{ validate_range(delay_min, 0, 60, 'Delay') }}
    """
    if value is None:
        return f"⚠️  {field_name} is NULL"
    
    if min_val <= value <= max_val:
        return f"✅ {field_name}: {value} (range: {min_val}-{max_val})"
    else:
        return f"🚨 {field_name}: {value} OUTSIDE range ({min_val}-{max_val})"


def validate_date_format(date_str: str, format_str: str = "%Y-%m-%d") -> str:
    """
    Validate date string format.
    
    Usage:
        {{ validate_date_format(ds, '%Y-%m-%d') }}
    """
    try:
        datetime.strptime(date_str, format_str)
        return f"✅ Valid date: {date_str}"
    except (ValueError, TypeError):
        return f"🚨 Invalid date: {date_str} (expected format: {format_str})"


def calculate_sla_status(
    delay_min: float,
    on_time_threshold: float = 5,
    late_threshold: float = 15,
) -> str:
    """
    Calculate SLA status based on delay.
    
    Usage:
        {{ calculate_sla_status(avg_delay, 5, 15) }}
    """
    if delay_min is None:
        return "UNKNOWN"
    
    if delay_min <= on_time_threshold:
        return "ON_TIME ✅"
    elif delay_min <= late_threshold:
        return "SLIGHT_DELAY ⚠️"
    else:
        return "BREACHED 🚨"


def format_pkr(amount: float, include_symbol: bool = True) -> str:
    """
    Format amount in PKR with commas.
    
    Usage:
        {{ format_pkr(total_revenue, true) }}
    """
    if amount is None:
        return "N/A"
    
    formatted = f"{amount:,.0f}"
    return f"PKR {formatted}" if include_symbol else formatted


def format_percentage(value: float, decimals: int = 1) -> str:
    """
    Format value as percentage.
    
    Usage:
        {{ format_percentage(on_time_rate, 1) }}
    """
    if value is None:
        return "N/A"
    
    return f"{value:.{decimals}f}%"


def generate_date_range(
    start_date: str,
    end_date: str,
    date_format: str = "%Y-%m-%d",
) -> List[str]:
    """
    Generate list of dates between start and end.
    
    Usage:
        {% for d in generate_date_range('2024-01-01', '2024-01-07') %}
    """
    start = datetime.strptime(start_date, date_format)
    end = datetime.strptime(end_date, date_format)
    
    dates = []
    current = start
    while current <= end:
        dates.append(current.strftime(date_format))
        current += timedelta(days=1)
    
    return dates


def calculate_growth(
    current: float,
    previous: float,
) -> Dict[str, Any]:
    """
    Calculate growth metrics.
    
    Usage:
        {{ calculate_growth(current_revenue, prev_revenue)['growth_pct'] }}
    """
    if previous is None or previous == 0:
        return {"growth": 0, "growth_pct": "N/A", "direction": "N/A"}
    
    growth = current - previous
    growth_pct = (growth / previous) * 100
    
    return {
        "growth": growth,
        "growth_pct": f"{growth_pct:.1f}%",
        "direction": "▲" if growth > 0 else "▼" if growth < 0 else "→",
        "is_positive": growth > 0,
    }


def truncate_string(text: str, max_length: int = 100, suffix: str = "...") -> str:
    """
    Truncate string to max length.
    
    Usage:
        {{ truncate_string(error_message, 200) }}
    """
    if not text:
        return ""
    
    if len(text) <= max_length:
        return text
    
    return text[:max_length - len(suffix)] + suffix


def safe_divide(numerator: float, denominator: float, default: Any = 0) -> float:
    """
    Safe division that avoids ZeroDivisionError.
    
    Usage:
        {{ safe_divide(profit, revenue) }}
    """
    if denominator is None or denominator == 0:
        return default
    
    return numerator / denominator


def get_env_or_default(env_var: str, default: Any = None) -> str:
    """
    Get environment variable or return default.
    
    Usage:
        {{ get_env_or_default('ENVIRONMENT', 'development') }}
    """
    import os
    return os.getenv(env_var, default)


# ============================================
# REGISTER MACROS
# ============================================

def register_macros() -> Dict[str, callable]:
    """
    Register all macros for Airflow DAGs.
    Called automatically when placed in plugins/macros/.
    """
    return {
        "validate_not_null": validate_not_null,
        "validate_range": validate_range,
        "validate_date_format": validate_date_format,
        "calculate_sla_status": calculate_sla_status,
        "format_pkr": format_pkr,
        "format_percentage": format_percentage,
        "generate_date_range": generate_date_range,
        "calculate_growth": calculate_growth,
        "truncate_string": truncate_string,
        "safe_divide": safe_divide,
        "get_env_or_default": get_env_or_default,
    }