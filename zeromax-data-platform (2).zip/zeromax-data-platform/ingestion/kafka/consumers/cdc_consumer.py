"""
================================================================================
ZEROMAX LOGISTICS - CDC (CHANGE DATA CAPTURE) KAFKA CONSUMER
================================================================================
Consumes CDC events from source databases and applies changes to Bronze.
Handles INSERT, UPDATE, DELETE operations from OLTP systems.

Usage:
    python cdc_consumer.py
    python cdc_consumer.py --source postgresql --tables orders,customers
================================================================================
"""

import os
import sys
import json
import time
import signal
import logging
from datetime import datetime
from typing import Dict, List, Optional, Set
from pathlib import Path
from enum import Enum

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from confluent_kafka import Consumer, KafkaError
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/cdc_consumer.log"),
    ],
)
logger = logging.getLogger(__name__)

# ============================================
# CONFIGURATION
# ============================================

KAFKA_CONFIG = {
    "bootstrap.servers": os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"),
    "group.id": "zeromax-cdc-consumer",
    "auto.offset.reset": "earliest",
    "enable.auto.commit": False,
    "isolation.level": "read_committed",
}

BRONZE_DIR = os.getenv("BRONZE_DIR", "data/bronze")
CDC_DIR = os.path.join(BRONZE_DIR, "cdc")

CDC_TOPICS = [
    "zeromax.cdc.postgresql.orders",
    "zeromax.cdc.postgresql.customers",
    "zeromax.cdc.postgresql.drivers",
    "zeromax.cdc.mysql.restaurants",
    "zeromax.cdc.mongodb.driver_locations",
]


class CDCOperation(Enum):
    """CDC operation types."""
    INSERT = "c"
    UPDATE = "u"
    DELETE = "d"
    READ = "r"  # Snapshot read
    TRUNCATE = "t"


class CDCEvent:
    """Represents a single CDC event."""
    
    def __init__(self, raw_message: Dict):
        self.raw = raw_message
        self.source = raw_message.get("source", {})
        self.op = CDCOperation(raw_message.get("op", "c"))
        self.ts_ms = raw_message.get("ts_ms", int(time.time() * 1000))
        self.before = raw_message.get("before")
        self.after = raw_message.get("after")
        self.table = self.source.get("table", "unknown")
        self.schema = self.source.get("schema", "public")
        self.database = self.source.get("db", "unknown")
        
    @property
    def key(self) -> str:
        """Generate event key for deduplication."""
        return f"{self.database}.{self.schema}.{self.table}:{self.op.value}:{self.ts_ms}"
    
    @property
    def is_insert(self) -> bool:
        return self.op == CDCOperation.INSERT
    
    @property
    def is_update(self) -> bool:
        return self.op == CDCOperation.UPDATE
    
    @property
    def is_delete(self) -> bool:
        return self.op == CDCOperation.DELETE
    
    def get_data(self) -> Optional[Dict]:
        """Get the data payload (after image for insert/update, before for delete)."""
        if self.is_delete:
            return self.before
        return self.after or self.before


class CDCMetadataTracker:
    """Tracks CDC processing metadata and schema evolution."""
    
    def __init__(self, base_dir: str = CDC_DIR):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.metadata_file = self.base_dir / "cdc_metadata.json"
        self.schema_dir = self.base_dir / "schemas"
        self.schema_dir.mkdir(exist_ok=True)
        self.metadata = self._load_metadata()
    
    def _load_metadata(self) -> Dict:
        """Load CDC metadata."""
        if self.metadata_file.exists():
            with open(self.metadata_file, "r") as f:
                return json.load(f)
        return {
            "processed_transactions": [],
            "last_lsn": None,
            "schema_versions": {},
            "error_transactions": [],
        }
    
    def save(self) -> None:
        """Save metadata to file."""
        self.metadata["updated_at"] = datetime.now().isoformat()
        with open(self.metadata_file, "w") as f:
            json.dump(self.metadata, f, indent=2, default=str)
    
    def record_transaction(self, event_key: str, status: str) -> None:
        """Record a processed transaction."""
        self.metadata["processed_transactions"].append({
            "event_key": event_key,
            "status": status,
            "timestamp": datetime.now().isoformat(),
        })
        # Keep only last 10000 transactions
        if len(self.metadata["processed_transactions"]) > 10000:
            self.metadata["processed_transactions"] = \
                self.metadata["processed_transactions"][-5000:]
    
    def is_duplicate(self, event_key: str) -> bool:
        """Check if event was already processed."""
        for tx in reversed(self.metadata["processed_transactions"]):
            if tx["event_key"] == event_key and tx["status"] == "success":
                return True
        return False
    
    def track_schema(self, table: str, schema: Dict) -> None:
        """Track schema version."""
        schema_file = self.schema_dir / f"{table}.json"
        current_version = self.metadata["schema_versions"].get(table, 0)
        new_version = current_version + 1
        
        schema_data = {
            "version": new_version,
            "table": table,
            "schema": schema,
            "updated_at": datetime.now().isoformat(),
        }
        
        with open(schema_file, "w") as f:
            json.dump(schema_data, f, indent=2)
        
        self.metadata["schema_versions"][table] = new_version
        logger.info(f"📋 Schema updated: {table} v{new_version}")


class CDCStore:
    """Stores CDC events in Bronze layer with upsert capability."""
    
    def __init__(self, base_dir: str = CDC_DIR):
        self.base_dir = Path(base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self.data_dir = self.base_dir / "data"
        self.data_dir.mkdir(exist_ok=True)
        self.tombstone_dir = self.base_dir / "tombstones"
        self.tombstone_dir.mkdir(exist_ok=True)
    
    def _get_table_path(self, database: str, schema: str, table: str) -> Path:
        """Get storage path for a table."""
        return self.data_dir / database / schema / table
    
    def apply_insert(self, event: CDCEvent) -> bool:
        """Apply INSERT operation."""
        data = event.get_data()
        if not data:
            return False
        
        try:
            table_path = self._get_table_path(event.database, event.schema, event.table)
            table_path.mkdir(parents=True, exist_ok=True)
            
            # Append to Parquet file
            df = pd.DataFrame([data])
            df["cdc_operation"] = "INSERT"
            df["cdc_timestamp"] = datetime.now().isoformat()
            
            output_file = table_path / f"insert_{datetime.now().strftime('%Y%m%d_%H%M%S')}.parquet"
            table = pa.Table.from_pandas(df)
            pq.write_table(table, output_file, compression="snappy")
            
            return True
            
        except Exception as e:
            logger.error(f"Insert failed for {event.table}: {e}")
            return False
    
    def apply_update(self, event: CDCEvent) -> bool:
        """Apply UPDATE operation with before/after image."""
        data = event.get_data()
        before = event.before
        
        if not data:
            return False
        
        try:
            table_path = self._get_table_path(event.database, event.schema, event.table)
            table_path.mkdir(parents=True, exist_ok=True)
            
            # Create update record with before/after
            update_record = {
                "operation": "UPDATE",
                "before": before,
                "after": data,
                "changed_fields": self._get_changed_fields(before, data) if before else [],
                "cdc_timestamp": datetime.now().isoformat(),
            }
            
            output_file = table_path / f"update_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(output_file, "w") as f:
                json.dump(update_record, f, indent=2, default=str)
            
            return True
            
        except Exception as e:
            logger.error(f"Update failed for {event.table}: {e}")
            return False
    
    def apply_delete(self, event: CDCEvent) -> bool:
        """Apply DELETE operation (tombstone)."""
        data = event.get_data()
        if not data:
            return False
        
        try:
            # Write tombstone record
            tombstone_file = self.tombstone_dir / f"{event.table}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
            tombstone = {
                "table": event.table,
                "deleted_record": data,
                "deletion_timestamp": datetime.now().isoformat(),
                "cdc_operation": "DELETE",
            }
            
            with open(tombstone_file, "w") as f:
                json.dump(tombstone, f, indent=2, default=str)
            
            return True
            
        except Exception as e:
            logger.error(f"Delete failed for {event.table}: {e}")
            return False
    
    def apply_truncate(self, event: CDCEvent) -> bool:
        """Handle TRUNCATE operation."""
        logger.warning(f"⚠️  TRUNCATE operation on {event.table} - marking for full reload")
        
        truncate_file = self.base_dir / "truncate_markers" / f"{event.table}.marker"
        truncate_file.parent.mkdir(exist_ok=True)
        truncate_file.touch()
        
        return True
    
    def _get_changed_fields(self, before: Dict, after: Dict) -> List[str]:
        """Identify changed fields between before and after images."""
        changed = []
        all_keys = set(list(before.keys()) + list(after.keys()))
        
        for key in all_keys:
            if key in ["updated_at", "modified_at", "last_modified"]:
                continue
            if before.get(key) != after.get(key):
                changed.append(key)
        
        return changed


class CDCConsumer:
    """CDC event consumer with idempotent processing."""
    
    def __init__(self, config: Dict = None):
        self.config = config or KAFKA_CONFIG
        self.consumer = Consumer(self.config)
        self.tracker = CDCMetadataTracker()
        self.store = CDCStore()
        self.running = True
        self.stats = {
            "inserts": 0,
            "updates": 0,
            "deletes": 0,
            "truncates": 0,
            "duplicates": 0,
            "errors": 0,
        }
    
    def subscribe(self) -> None:
        """Subscribe to CDC topics."""
        self.consumer.subscribe(CDC_TOPICS)
        logger.info(f"Subscribed to CDC topics: {CDC_TOPICS}")
    
    def process_event(self, raw_message: Dict) -> bool:
        """Process a single CDC event."""
        try:
            event = CDCEvent(raw_message)
            
            # Deduplication check
            if self.tracker.is_duplicate(event.key):
                self.stats["duplicates"] += 1
                logger.debug(f"Skipping duplicate: {event.key}")
                return True
            
            # Apply operation
            success = False
            
            if event.is_insert:
                success = self.store.apply_insert(event)
                if success:
                    self.stats["inserts"] += 1
                    
            elif event.is_update:
                success = self.store.apply_update(event)
                if success:
                    self.stats["updates"] += 1
                    
            elif event.is_delete:
                success = self.store.apply_delete(event)
                if success:
                    self.stats["deletes"] += 1
                    
            elif event.op == CDCOperation.TRUNCATE:
                success = self.store.apply_truncate(event)
                if success:
                    self.stats["truncates"] += 1
            
            if success:
                self.tracker.record_transaction(event.key, "success")
            else:
                self.tracker.record_transaction(event.key, "failed")
                self.stats["errors"] += 1
            
            return success
            
        except Exception as e:
            logger.error(f"Event processing failed: {e}")
            self.stats["errors"] += 1
            return False
    
    def commit_offsets(self) -> None:
        """Commit offsets and save metadata."""
        try:
            self.consumer.commit(asynchronous=False)
            self.tracker.save()
        except Exception as e:
            logger.error(f"Commit failed: {e}")
    
    def shutdown(self) -> None:
        """Graceful shutdown."""
        logger.info("Shutting down CDC consumer...")
        self.running = False
        self.commit_offsets()
        self.consumer.close()
        self._print_stats()
    
    def _print_stats(self) -> None:
        """Print processing statistics."""
        total = sum([
            self.stats["inserts"],
            self.stats["updates"],
            self.stats["deletes"],
        ])
        
        print("\n" + "=" * 60)
        print("📊 CDC CONSUMER STATISTICS")
        print("=" * 60)
        print(f"  Inserts:    {self.stats['inserts']:,}")
        print(f"  Updates:    {self.stats['updates']:,}")
        print(f"  Deletes:    {self.stats['deletes']:,}")
        print(f"  Truncates:  {self.stats['truncates']}")
        print(f"  Duplicates: {self.stats['duplicates']}")
        print(f"  Errors:     {self.stats['errors']}")
        print(f"  Total:      {total:,}")
        print("=" * 60)
    
    def run(self) -> None:
        """Main consumer loop."""
        self.subscribe()
        
        logger.info("=" * 60)
        logger.info("🔄 CDC CONSUMER STARTED")
        logger.info("=" * 60)
        
        signal.signal(signal.SIGINT, lambda s, f: self.shutdown())
        signal.signal(signal.SIGTERM, lambda s, f: self.shutdown())
        
        last_commit = time.time()
        messages_since_commit = 0
        
        try:
            while self.running:
                msg = self.consumer.poll(timeout=1.0)
                
                if msg is None:
                    continue
                
                if msg.error():
                    if msg.error().code() != KafkaError._PARTITION_EOF:
                        logger.error(f"Kafka error: {msg.error()}")
                    continue
                
                try:
                    raw_message = json.loads(msg.value().decode("utf-8"))
                    self.process_event(raw_message)
                    messages_since_commit += 1
                    
                    # Commit periodically
                    if time.time() - last_commit > 30 or messages_since_commit >= 1000:
                        self.commit_offsets()
                        last_commit = time.time()
                        messages_since_commit = 0
                        
                        total = sum([self.stats["inserts"], self.stats["updates"], self.stats["deletes"]])
                        logger.info(f"📊 CDC Events: {total:,} total "
                                   f"(I:{self.stats['inserts']} U:{self.stats['updates']} D:{self.stats['deletes']})")
                
                except json.JSONDecodeError:
                    logger.error("JSON decode error in CDC message")
                    self.stats["errors"] += 1
                    
        except Exception as e:
            logger.error(f"Consumer error: {e}")
        finally:
            self.shutdown()


def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax CDC Consumer")
    parser.add_argument("--group", type=str, help="Consumer group ID")
    parser.add_argument("--topics", nargs="+", help="CDC topics to consume")
    args = parser.parse_args()
    
    config = KAFKA_CONFIG.copy()
    if args.group:
        config["group.id"] = args.group
    
    consumer = CDCConsumer(config=config)
    consumer.run()


if __name__ == "__main__":
    main()