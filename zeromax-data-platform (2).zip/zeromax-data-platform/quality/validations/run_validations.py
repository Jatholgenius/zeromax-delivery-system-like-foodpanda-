"""
================================================================================
ZEROMAX LOGISTICS - VALIDATION RUNNER
================================================================================
Centralized validation runner for all data quality checks.
Runs Bronze → Silver → Gold validations sequentially.

Usage:
    python run_validations.py
    python run_validations.py --layer gold
    python run_validations.py --all --strict --report
================================================================================
"""

import os
import sys
import json
import logging
import argparse
from datetime import datetime
from typing import Dict, List, Optional
from pathlib import Path

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

from quality.checkpoints.checkpoint_bronze import BronzeLayerValidator
from quality.checkpoints.checkpoint_silver import SilverLayerValidator
from quality.checkpoints.checkpoint_gold import GoldLayerValidator

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/validations.log"),
    ],
)
logger = logging.getLogger(__name__)


class ValidationRunner:
    """
    Orchestrates data quality validations across all layers.
    Supports selective layer validation and reporting.
    """
    
    def __init__(self):
        self.results: Dict[str, Dict] = {}
        self.start_time = datetime.now()
        self.bronze_validator = None
        self.silver_validator = None
        self.gold_validator = None
    
    def run_bronze(self) -> Dict:
        """Run Bronze layer validation."""
        logger.info("=" * 60)
        logger.info("🔍 RUNNING BRONZE LAYER VALIDATION")
        logger.info("=" * 60)
        
        try:
            self.bronze_validator = BronzeLayerValidator(context=None)
            result = self.bronze_validator.validate_all()
            self.bronze_validator.print_summary()
            self.results["bronze"] = result
            return result
        except Exception as e:
            logger.error(f"Bronze validation failed: {e}")
            self.results["bronze"] = {
                "layer": "BRONZE",
                "overall_status": "ERROR",
                "error": str(e),
            }
            return self.results["bronze"]
    
    def run_silver(self) -> Dict:
        """Run Silver layer validation."""
        logger.info("=" * 60)
        logger.info("🔍 RUNNING SILVER LAYER VALIDATION")
        logger.info("=" * 60)
        
        try:
            self.silver_validator = SilverLayerValidator()
            result = self.silver_validator.validate_all()
            self.silver_validator.print_summary()
            self.results["silver"] = result
            return result
        except Exception as e:
            logger.error(f"Silver validation failed: {e}")
            self.results["silver"] = {
                "layer": "SILVER",
                "overall_status": "ERROR",
                "error": str(e),
            }
            return self.results["silver"]
    
    def run_gold(self) -> Dict:
        """Run Gold layer validation."""
        logger.info("=" * 60)
        logger.info("🔍 RUNNING GOLD LAYER VALIDATION")
        logger.info("=" * 60)
        
        try:
            from great_expectations.data_context import BaseDataContext
            context = BaseDataContext(project_root_dir=".")
            self.gold_validator = GoldLayerValidator(context)
            result = self.gold_validator.validate_all_tables()
            self.gold_validator.print_summary()
            self.results["gold"] = result
            return result
        except Exception as e:
            logger.error(f"Gold validation failed: {e}")
            self.results["gold"] = {
                "layer": "GOLD",
                "overall_status": "ERROR",
                "error": str(e),
            }
            return self.results["gold"]
    
    def run_all(self) -> Dict:
        """
        Run all layer validations in sequence.
        Each layer depends on the previous one passing.
        """
        logger.info("=" * 70)
        logger.info("🏁 ZEROMAX FULL DATA QUALITY VALIDATION")
        logger.info(f"   Start Time: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        logger.info("=" * 70)
        
        # Bronze first
        bronze_result = self.run_bronze()
        
        if bronze_result.get("overall_status") == "ERROR":
            logger.error("❌ Bronze validation failed. Stopping pipeline.")
            self._generate_final_report()
            return self.results
        
        # Silver next (requires Bronze to pass)
        if bronze_result.get("overall_status") == "PASS":
            silver_result = self.run_silver()
        else:
            logger.warning("⚠️  Bronze has failures. Running Silver anyway...")
            silver_result = self.run_silver()
        
        # Gold last (requires Silver to pass)
        if silver_result.get("overall_status") == "PASS":
            self.run_gold()
        else:
            logger.warning("⚠️  Silver has failures. Running Gold anyway...")
            self.run_gold()
        
        # Generate final report
        report = self._generate_final_report()
        
        return report
    
    def _generate_final_report(self) -> Dict:
        """Generate comprehensive validation report."""
        end_time = datetime.now()
        duration = (end_time - self.start_time).total_seconds()
        
        # Calculate overall metrics
        total_checks = 0
        total_passed = 0
        total_failed = 0
        
        for layer, result in self.results.items():
            if isinstance(result, dict):
                total_checks += result.get("total_checks", result.get("summary", {}).get("total_checks", 0))
                total_passed += result.get("passed", result.get("summary", {}).get("passed", 0))
                total_failed += result.get("failed", result.get("summary", {}).get("failed", 0))
        
        # Determine overall status
        bronze_status = self.results.get("bronze", {}).get("overall_status", "UNKNOWN")
        silver_status = self.results.get("silver", {}).get("overall_status", "UNKNOWN")
        gold_status = self.results.get("gold", {}).get("overall_status", "UNKNOWN")
        
        if "FAIL" in [bronze_status, silver_status, gold_status] or "ERROR" in [bronze_status, silver_status, gold_status]:
            overall_status = "FAILED"
        elif "WARN" in [bronze_status, silver_status, gold_status]:
            overall_status = "WARNING"
        else:
            overall_status = "PASSED"
        
        report = {
            "pipeline": "ZeroMax Data Quality Validation",
            "timestamp": datetime.now().isoformat(),
            "duration_seconds": round(duration, 1),
            "overall_status": overall_status,
            "layers": {
                "bronze": bronze_status,
                "silver": silver_status,
                "gold": gold_status,
            },
            "summary": {
                "total_checks": total_checks,
                "passed": total_passed,
                "failed": total_failed,
                "pass_rate_pct": round((total_passed / total_checks) * 100, 1) if total_checks > 0 else 0,
            },
            "details": self.results,
        }
        
        # Save report
        self.save_report(report)
        
        # Print final summary
        self._print_final_summary(report)
        
        return report
    
    def _print_final_summary(self, report: Dict) -> None:
        """Print final validation summary."""
        summary = report["summary"]
        
        print("\n" + "=" * 70)
        print("🏆 FINAL VALIDATION REPORT")
        print("=" * 70)
        print(f"  Overall Status: {report['overall_status']}")
        print(f"  Duration:       {report['duration_seconds']}s")
        print(f"")
        print(f"  Layers:")
        print(f"    Bronze: {report['layers']['bronze']}")
        print(f"    Silver: {report['layers']['silver']}")
        print(f"    Gold:   {report['layers']['gold']}")
        print(f"")
        print(f"  Checks Summary:")
        print(f"    Total:  {summary['total_checks']}")
        print(f"    Passed: {summary['passed']} ✅")
        print(f"    Failed: {summary['failed']} ❌")
        print(f"    Rate:   {summary['pass_rate_pct']}%")
        print("=" * 70)
        
        if report["overall_status"] == "FAILED":
            print("\n🚨 ACTION REQUIRED: Review failures before loading to Power BI!")
        elif report["overall_status"] == "WARNING":
            print("\n⚠️  WARNING: Minor issues detected. Review recommended.")
        else:
            print("\n✅ All validations passed. Data is ready for consumption!")
    
    def save_report(self, report: Dict, filename: str = None) -> str:
        """Save validation report to JSON."""
        os.makedirs("reports", exist_ok=True)
        
        if filename is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"reports/validation_report_{timestamp}.json"
        
        with open(filename, "w") as f:
            json.dump(report, f, indent=2, default=str)
        
        logger.info(f"📄 Full report saved: {filename}")
        return filename
    
    def export_for_slack(self) -> Dict:
        """Export summary for Slack notification."""
        summary = {}
        
        if "summary" in self.results.get("gold", {}):
            summary = self.results["gold"]["summary"]
        elif "summary" in self.results.get("silver", {}):
            summary = self.results["silver"]["summary"]
        else:
            summary = {
                "total_checks": 0,
                "passed": 0,
                "failed": 0,
                "pass_rate": "N/A",
            }
        
        return {
            "bronze": self.results.get("bronze", {}).get("overall_status", "SKIPPED"),
            "silver": self.results.get("silver", {}).get("overall_status", "SKIPPED"),
            "gold": self.results.get("gold", {}).get("overall_status", "SKIPPED"),
            "checks_passed": summary.get("passed", 0),
            "checks_total": summary.get("total_checks", 0),
            "pass_rate": summary.get("pass_rate", "N/A"),
        }
    
    def should_block_pipeline(self) -> bool:
        """
        Determine if pipeline should be blocked based on validation results.
        
        Returns:
            True if pipeline should be blocked
        """
        # Block if Bronze has critical failures
        bronze = self.results.get("bronze", {})
        if bronze.get("overall_status") in ["ERROR", "FAIL"]:
            logger.error("Pipeline blocked: Bronze layer validation failed")
            return True
        
        # Block if Gold has critical failures
        gold = self.results.get("gold", {})
        if gold.get("overall_status") == "ERROR":
            logger.error("Pipeline blocked: Gold layer validation failed")
            return True
        
        return False


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="ZeroMax Data Quality Validation Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python run_validations.py                    # Run all layers
  python run_validations.py --layer bronze     # Run Bronze only
  python run_validations.py --layer gold       # Run Gold only
  python run_validations.py --all --strict     # All layers, exit on failure
  python run_validations.py --report-only      # Generate report from last run
        """,
    )
    
    parser.add_argument(
        "--layer",
        type=str,
        choices=["bronze", "silver", "gold"],
        help="Run specific layer only",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        default=True,
        help="Run all layers (default)",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Exit with error code on validation failure",
    )
    parser.add_argument(
        "--report",
        action="store_true",
        help="Generate detailed JSON report",
    )
    parser.add_argument(
        "--slack",
        action="store_true",
        help="Send summary to Slack",
    )
    parser.add_argument(
        "--block-on-failure",
        action="store_true",
        help="Return non-zero exit code if validation fails",
    )
    
    args = parser.parse_args()
    
    runner = ValidationRunner()
    
    # Run specified layer or all
    if args.layer == "bronze":
        runner.run_bronze()
    elif args.layer == "silver":
        runner.run_silver()
    elif args.layer == "gold":
        runner.run_gold()
    else:
        runner.run_all()
    
    # Generate report
    if args.report:
        runner.save_report(runner.results)
    
    # Send to Slack
    if args.slack:
        slack_summary = runner.export_for_slack()
        logger.info(f"Slack summary: {json.dumps(slack_summary, indent=2)}")
        # Actual Slack sending would use SlackAPIPostOperator or webhook
    
    # Exit with error if strict mode and validation failed
    if args.strict or args.block_on_failure:
        if runner.should_block_pipeline():
            logger.error("❌ Validation failed. Exiting with error.")
            sys.exit(1)
    
    logger.info("✅ Validation runner completed successfully")
    sys.exit(0)


if __name__ == "__main__":
    main()