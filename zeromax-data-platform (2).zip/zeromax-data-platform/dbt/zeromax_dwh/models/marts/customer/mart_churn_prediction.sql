{{
  config(
    materialized='table',
    cluster_by=['churn_risk_score'],
    tags=['gold', 'customer', 'churn', 'ml_based', 'restricted'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE marketing_analyst",
      "GRANT SELECT ON {{ this }} TO ROLE executive"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: MART_CHURN_PREDICTION
-- ============================================================
-- Customer churn prediction using behavioral signals.
-- Identifies at-risk customers for retention campaigns.
-- ============================================================

WITH customer_behavior AS (
    SELECT
        customer_sk,
        customer_id,
        customer_name,
        loyalty_tier,
        total_deliveries,
        total_spent,
        avg_rating_given,
        days_since_last_order,
        first_order_date,
        last_order_date,
        customer_lifespan_days,
        avg_orders_per_month,
        on_time_count,
        late_count,
        failed_count,
        favorite_cuisine,
        preferred_time_period,
        
        -- Calculate churn signals
        CASE WHEN days_since_last_order > 90 THEN 30 ELSE 0 END AS inactivity_score,
        CASE WHEN avg_rating_given < 3.0 THEN 25 ELSE 0 END AS dissatisfaction_score,
        CASE WHEN failed_count * 1.0 / NULLIF(total_deliveries, 0) > 0.15 THEN 20 ELSE 0 END AS failure_experience_score,
        CASE WHEN avg_orders_per_month < 2 AND total_deliveries > 5 THEN 15 ELSE 0 END AS declining_usage_score,
        CASE WHEN total_deliveries <= 3 AND days_since_last_order > 30 THEN 10 ELSE 0 END AS new_user_dormancy_score
        
    FROM {{ ref('mart_customer_360') }}
),

churn_scores AS (
    SELECT
        *,
        
        -- Total churn risk score (0-100)
        inactivity_score + dissatisfaction_score + failure_experience_score + 
        declining_usage_score + new_user_dormancy_score AS churn_risk_score,
        
        -- Churn probability tier
        CASE
            WHEN churn_risk_score >= 50 THEN 'Very High'
            WHEN churn_risk_score >= 30 THEN 'High'
            WHEN churn_risk_score >= 15 THEN 'Medium'
            WHEN churn_risk_score >= 5 THEN 'Low'
            ELSE 'Very Low'
        END AS churn_risk_tier
        
    FROM customer_behavior
)

SELECT
    *,
    
    -- Predicted churn within 30 days
    CASE WHEN churn_risk_score >= 30 THEN TRUE ELSE FALSE END AS predicted_churn_30d,
    
    -- Predicted churn within 90 days
    CASE WHEN churn_risk_score >= 15 THEN TRUE ELSE FALSE END AS predicted_churn_90d,
    
    -- Retention priority
    CASE
        WHEN churn_risk_tier IN ('Very High', 'High') AND total_spent > 25000 THEN 'P1 - Immediate Action'
        WHEN churn_risk_tier IN ('Very High', 'High') THEN 'P2 - High Priority'
        WHEN churn_risk_tier = 'Medium' THEN 'P3 - Monitor'
        ELSE 'P4 - Standard'
    END AS retention_priority,
    
    -- Recommended incentive
    CASE
        WHEN churn_risk_tier = 'Very High' AND total_spent > 25000 THEN 'Personal Call + 30% Discount'
        WHEN churn_risk_tier = 'Very High' THEN '25% Discount Coupon'
        WHEN churn_risk_tier = 'High' THEN '15% Discount Coupon'
        WHEN churn_risk_tier = 'Medium' THEN 'Free Delivery Next Order'
        ELSE 'Loyalty Points Bonus'
    END AS recommended_incentive,
    
    -- Estimated retention value
    ROUND(total_spent * 1.0 / NULLIF(GREATEST(total_deliveries, 1), 0) * 
        CASE 
            WHEN churn_risk_tier = 'Very High' THEN 2
            WHEN churn_risk_tier = 'High' THEN 5
            WHEN churn_risk_tier = 'Medium' THEN 10
            ELSE 20
        END, 0) AS estimated_future_value_pkr,
    
    -- Churn signals summary
    TRIM(
        CASE WHEN inactivity_score > 0 THEN 'Inactive ' ELSE '' END ||
        CASE WHEN dissatisfaction_score > 0 THEN 'Dissatisfied ' ELSE '' END ||
        CASE WHEN failure_experience_score > 0 THEN 'PoorExperience ' ELSE '' END ||
        CASE WHEN declining_usage_score > 0 THEN 'Declining ' ELSE '' END ||
        CASE WHEN new_user_dormancy_score > 0 THEN 'NewUserDormant ' ELSE '' END
    ) AS churn_signals,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'mart_churn_prediction' AS dw_source

FROM churn_scores
ORDER BY churn_risk_score DESC