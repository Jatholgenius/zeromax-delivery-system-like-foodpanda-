{{
  config(
    materialized='table',
    tags=['gold', 'dimension', 'traffic', 'reference'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: DIM_TRAFFIC
-- ============================================================
-- Traffic congestion reference dimension.
-- Maps traffic levels to delay factors and severity.
-- ============================================================

WITH traffic_levels AS (
    SELECT * FROM (VALUES
        ('Low', 1, 1.00, '10:00-12:00, 21:00-06:00', 'Free flowing traffic'),
        ('Low-Medium', 2, 1.15, '12:00-14:00', 'Slight congestion'),
        ('Medium', 2, 1.30, '14:00-17:00', 'Moderate traffic, some delays'),
        ('High', 3, 1.60, '08:00-10:00, 17:00-20:00', 'Heavy traffic, significant delays'),
        ('Severe', 4, 2.00, '08:00-10:00, 18:00-19:00', 'Severe congestion, major delays'),
        ('Gridlock', 5, 2.50, 'Rush hours + rain/events', 'Complete standstill')
    ) AS t(level, severity, delay_factor, typical_times, description)
)

SELECT
    -- Surrogate Key
    ROW_NUMBER() OVER (ORDER BY severity) AS traffic_sk,
    
    -- Traffic Attributes
    level AS traffic_level,
    severity AS traffic_severity,
    delay_factor AS traffic_delay_factor,
    typical_times,
    description AS traffic_description,
    
    -- Severity Classification
    CASE
        WHEN severity <= 2 THEN 'Manageable'
        WHEN severity = 3 THEN 'Heavy'
        WHEN severity >= 4 THEN 'Critical'
    END AS severity_category,
    
    -- Delay Impact
    CASE
        WHEN delay_factor <= 1.15 THEN 'Minimal'
        WHEN delay_factor <= 1.30 THEN 'Moderate'
        WHEN delay_factor <= 1.60 THEN 'Significant'
        WHEN delay_factor <= 2.00 THEN 'Severe'
        ELSE 'Extreme'
    END AS delay_impact,
    
    -- Is Rush Hour
    CASE WHEN level IN ('High', 'Severe', 'Gridlock') THEN TRUE ELSE FALSE END AS is_rush_level,
    
    -- Estimated Speed Reduction
    CASE
        WHEN delay_factor = 1.00 THEN 0
        WHEN delay_factor <= 1.15 THEN 15
        WHEN delay_factor <= 1.30 THEN 25
        WHEN delay_factor <= 1.60 THEN 40
        WHEN delay_factor <= 2.00 THEN 55
        ELSE 70
    END AS speed_reduction_pct,
    
    -- Recommended Strategy
    CASE
        WHEN severity <= 2 THEN 'Normal Routing'
        WHEN severity = 3 THEN 'Alternate Routes Recommended'
        WHEN severity = 4 THEN 'Dynamic Rerouting Required'
        ELSE 'Suspend or Delay Deliveries'
    END AS routing_strategy,
    
    -- Surge Pricing Recommended
    CASE WHEN severity >= 3 THEN TRUE ELSE FALSE END AS surge_pricing_recommended,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'dim_traffic' AS dw_source

FROM traffic_levels