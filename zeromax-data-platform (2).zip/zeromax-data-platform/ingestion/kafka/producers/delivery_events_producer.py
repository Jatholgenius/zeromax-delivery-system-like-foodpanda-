"""
================================================================================
ZEROMAX LOGISTICS - DELIVERY EVENTS KAFKA PRODUCER
================================================================================
Produces simulated delivery events to Kafka topics.
Simulates real-time order flow for the delivery pipeline.

Usage:
    python delivery_events_producer.py
    python delivery_events_producer.py --rate 100  # events per second
================================================================================
"""

import os
import sys
import json
import time
import random
import logging
from datetime import datetime, timedelta
from typing import Dict, Optional

import numpy as np
from confluent_kafka import Producer
from dotenv import load_dotenv

load_dotenv()

# ============================================
# CONFIGURATION
# ============================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

KAFKA_CONFIG = {
    "bootstrap.servers": os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"),
    "client.id": "zeromax-delivery-producer",
    "acks": "all",
    "retries": 3,
    "compression.type": "snappy",
    "linger.ms": 5,
    "batch.size": 16384,
}

TOPICS = {
    "orders": "zeromax.orders",
    "status": "zeromax.order_status",
    "gps": "zeromax.gps_tracking",
}

# Karachi zones with coordinates
ZONES = {
    "ZN001": {"name": "North Karachi", "lat": 24.9500, "lon": 67.0500},
    "ZN002": {"name": "South Karachi", "lat": 24.8100, "lon": 67.0300},
    "ZN003": {"name": "East Karachi", "lat": 24.9000, "lon": 67.1000},
    "ZN004": {"name": "West Karachi", "lat": 24.9200, "lon": 66.9800},
    "ZN005": {"name": "Central Karachi", "lat": 24.8800, "lon": 67.0450},
}

RESTAURANT_TYPES = [
    "Fast Food", "Desi/Pakistani", "BBQ/Grill", "Chinese/Asian",
    "Continental", "Cafe/Bakery", "Biryani/Pulao", "Street Food",
    "Fine Dining", "Seafood",
]

VEHICLE_TYPES = ["Bike-125cc", "Bike-150cc", "Car-Sedan", "Rickshaw"]
PAYMENT_METHODS = ["Credit Card", "Cash on Delivery", "JazzCash", "Easypaisa"]
STATUSES = ["order_placed", "preparing", "ready_for_pickup", "picked_up", "in_transit", "delivered", "cancelled"]


class DeliveryEventProducer:
    """Produces simulated delivery events to Kafka."""
    
    def __init__(self):
        self.producer = Producer(KAFKA_CONFIG)
        self.order_counter = 0
        self.driver_counter = 0
        self.customer_counter = 0
        self.restaurant_counter = 0
        
    def delivery_callback(self, err, msg):
        """Callback for message delivery confirmation."""
        if err:
            logger.error(f"Delivery failed: {err}")
        else:
            logger.debug(f"Message delivered to {msg.topic()} [{msg.partition()}]")
    
    def generate_order(self) -> Dict:
        """Generate a random order event."""
        self.order_counter += 1
        
        zone_id = random.choice(list(ZONES.keys()))
        zone = ZONES[zone_id]
        
        # Customer location (near zone center)
        cust_lat = zone["lat"] + random.uniform(-0.03, 0.03)
        cust_lon = zone["lon"] + random.uniform(-0.03, 0.03)
        
        # Restaurant location (same zone or adjacent)
        rest_lat = zone["lat"] + random.uniform(-0.05, 0.05)
        rest_lon = zone["lon"] + random.uniform(-0.05, 0.05)
        
        order = {
            "delivery_id": f"DLV{self.order_counter:06d}",
            "order_id": f"ORD{self.order_counter:06d}",
            "driver_id": f"DRV{random.randint(1, 150):04d}",
            "customer_id": f"CUST{random.randint(1, 5000):05d}",
            "restaurant_id": f"RES{random.randint(1, 115):04d}",
            "zone_id": zone_id,
            "event_type": "order_placed",
            "order_datetime": datetime.now().isoformat(),
            "order_date": datetime.now().strftime("%Y-%m-%d"),
            "date_key": datetime.now().timetuple().tm_yday,
            "time_key": datetime.now().hour + 1,
            "cust_lat": round(cust_lat, 6),
            "cust_lon": round(cust_lon, 6),
            "rest_lat": round(rest_lat, 6),
            "rest_lon": round(rest_lon, 6),
            "restaurant_type": random.choice(RESTAURANT_TYPES),
            "vehicle_type": random.choice(VEHICLE_TYPES),
            "payment_method": random.choice(PAYMENT_METHODS),
            "estimated_distance_km": round(random.uniform(0.8, 12.0), 1),
            "status": "order_placed",
            "event_timestamp": datetime.now().isoformat(),
        }
        
        return order
    
    def generate_status_update(self, delivery_id: str) -> Dict:
        """Generate a status update for an existing delivery."""
        return {
            "delivery_id": delivery_id,
            "status": random.choice(STATUSES[1:]),  # Skip 'order_placed'
            "latitude": round(24.8 + random.uniform(-0.1, 0.1), 6),
            "longitude": round(67.0 + random.uniform(-0.1, 0.1), 6),
            "speed_kmh": round(random.uniform(0, 50), 1),
            "battery_pct": random.randint(20, 100),
            "event_timestamp": datetime.now().isoformat(),
        }
    
    def produce_order(self) -> str:
        """Produce a new order event to Kafka."""
        order = self.generate_order()
        delivery_id = order["delivery_id"]
        
        # Produce to orders topic
        self.producer.produce(
            topic=TOPICS["orders"],
            key=delivery_id.encode("utf-8"),
            value=json.dumps(order).encode("utf-8"),
            callback=self.delivery_callback,
        )
        
        # Also send initial status
        status = {
            "delivery_id": delivery_id,
            "status": "order_placed",
            "event_timestamp": datetime.now().isoformat(),
        }
        self.producer.produce(
            topic=TOPICS["status"],
            key=delivery_id.encode("utf-8"),
            value=json.dumps(status).encode("utf-8"),
            callback=self.delivery_callback,
        )
        
        return delivery_id
    
    def produce_status_update(self, delivery_id: str) -> None:
        """Produce status update for a delivery."""
        status = self.generate_status_update(delivery_id)
        
        self.producer.produce(
            topic=TOPICS["status"],
            key=delivery_id.encode("utf-8"),
            value=json.dumps(status).encode("utf-8"),
            callback=self.delivery_callback,
        )
        
        # If in_transit, also send GPS ping
        if status["status"] == "in_transit":
            self.producer.produce(
                topic=TOPICS["gps"],
                key=delivery_id.encode("utf-8"),
                value=json.dumps(status).encode("utf-8"),
                callback=self.delivery_callback,
            )
    
    def flush(self):
        """Flush all pending messages."""
        self.producer.flush()
        logger.debug("All messages flushed to Kafka")


def main():
    """Main producer loop."""
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Delivery Events Producer")
    parser.add_argument("--rate", type=int, default=10, help="Events per second")
    parser.add_argument("--duration", type=int, default=0, help="Duration in seconds (0=infinite)")
    args = parser.parse_args()
    
    producer = DeliveryEventProducer()
    active_deliveries = []
    
    logger.info(f"Starting producer: {args.rate} events/sec")
    logger.info(f"Topics: {list(TOPICS.values())}")
    logger.info("Press Ctrl+C to stop")
    
    start_time = time.time()
    orders_produced = 0
    statuses_produced = 0
    
    try:
        while True:
            # Produce new orders (70% of events)
            if random.random() < 0.7:
                delivery_id = producer.produce_order()
                active_deliveries.append(delivery_id)
                orders_produced += 1
                
                # Keep active deliveries manageable
                if len(active_deliveries) > 1000:
                    active_deliveries = active_deliveries[-500:]
            
            # Update existing deliveries (30% of events)
            elif active_deliveries:
                delivery_id = random.choice(active_deliveries)
                producer.produce_status_update(delivery_id)
                statuses_produced += 1
            
            # Flush batch
            if (orders_produced + statuses_produced) % 50 == 0:
                producer.flush()
                
                elapsed = time.time() - start_time
                rate = (orders_produced + statuses_produced) / elapsed if elapsed > 0 else 0
                logger.info(f"📊 Produced: {orders_produced} orders, {statuses_produced} statuses "
                           f"({rate:.1f} events/sec)")
            
            # Check duration
            if args.duration > 0 and (time.time() - start_time) > args.duration:
                logger.info(f"Duration limit reached ({args.duration}s)")
                break
            
            # Rate limiting
            time.sleep(1.0 / args.rate)
            
    except KeyboardInterrupt:
        logger.info("\nShutting down...")
    finally:
        producer.flush()
        elapsed = time.time() - start_time
        logger.info(f"✅ Total: {orders_produced} orders, {statuses_produced} statuses in {elapsed:.1f}s")


if __name__ == "__main__":
    main()