#!/bin/bash
# ============================================================
# ZEROMAX LOGISTICS - DEVELOPMENT ENVIRONMENT SETUP
# ============================================================
# Sets up the complete development environment.
# Usage: bash scripts/setup_dev_environment.sh
# ============================================================

set -e  # Exit on error
set -u  # Exit on undefined variable

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# ============================================
# UTILITY FUNCTIONS
# ============================================

print_header() {
    echo ""
    echo -e "${CYAN}============================================${NC}"
    echo -e "${CYAN}  $1${NC}"
    echo -e "${CYAN}============================================${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

check_command() {
    if command -v "$1" &> /dev/null; then
        print_success "$1 is installed: $($1 --version 2>&1 | head -1)"
        return 0
    else
        print_warning "$1 is NOT installed"
        return 1
    fi
}

# ============================================
# 1. SYSTEM CHECK
# ============================================

print_header "1. CHECKING SYSTEM REQUIREMENTS"

echo "Operating System: $(uname -s)"
echo "Architecture: $(uname -m)"
echo ""

MISSING_TOOLS=()

echo "Checking required tools..."
check_command python3 || MISSING_TOOLS+=("python3")
check_command pip || MISSING_TOOLS+=("pip")
check_command docker || MISSING_TOOLS+=("docker")
check_command git || MISSING_TOOLS+=("git")

if [ ${#MISSING_TOOLS[@]} -gt 0 ]; then
    print_error "Missing tools: ${MISSING_TOOLS[*]}"
    echo "Please install missing tools and re-run this script."
    exit 1
fi

echo ""
echo "Checking optional tools..."
check_command psql || print_warning "PostgreSQL client not found (optional)"
check_command snowsql || print_warning "SnowSQL not found (optional)"
check_command terraform || print_warning "Terraform not found (optional)"

# ============================================
# 2. PYTHON SETUP
# ============================================

print_header "2. SETTING UP PYTHON ENVIRONMENT"

# Create virtual environment
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
    print_success "Virtual environment created"
else
    print_warning "Virtual environment already exists"
fi

# Activate virtual environment
echo "Activating virtual environment..."
source venv/bin/activate
print_success "Virtual environment activated"

# Upgrade pip
echo "Upgrading pip..."
pip install --upgrade pip --quiet
print_success "pip upgraded"

# Install dependencies
echo "Installing Python dependencies..."
pip install -e ".[dev,spark]" --quiet
print_success "Python dependencies installed"

# ============================================
# 3. ENVIRONMENT VARIABLES
# ============================================

print_header "3. CONFIGURING ENVIRONMENT"

if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        echo "Creating .env from .env.example..."
        cp .env.example .env
        print_success ".env file created from template"
        print_warning "Please edit .env with your actual credentials"
    else
        print_error ".env.example not found"
    fi
else
    print_warning ".env file already exists"
fi

# Load environment variables
set -a
source .env 2>/dev/null || print_warning "Could not load .env file"
set +a

# ============================================
# 4. DBT SETUP
# ============================================

print_header "4. SETTING UP DBT"

if [ -d "dbt/zeromax_dwh" ]; then
    cd dbt/zeromax_dwh
    
    echo "Installing dbt packages..."
    dbt deps
    print_success "dbt packages installed"
    
    echo "Testing dbt connection..."
    dbt debug --profiles-dir . 2>/dev/null && print_success "dbt connection OK" || print_warning "dbt connection failed (check credentials)"
    
    cd ../..
else
    print_error "dbt project directory not found"
fi

# ============================================
# 5. DOCKER SETUP
# ============================================

print_header "5. SETTING UP DOCKER SERVICES"

if [ -f "docker/docker-compose.yml" ]; then
    echo "Starting Docker services..."
    docker-compose -f docker/docker-compose.yml up -d 2>/dev/null || print_warning "Docker Compose failed (Docker may not be running)"
    
    echo "Waiting for services to be healthy..."
    sleep 10
    
    # Check services
    echo "Checking services..."
    curl -s http://localhost:8080/health > /dev/null 2>&1 && print_success "Airflow is running" || print_warning "Airflow not responding"
    curl -s http://localhost:5000/health > /dev/null 2>&1 && print_success "MLflow is running" || print_warning "MLflow not responding"
    curl -s http://localhost:9200 > /dev/null 2>&1 && print_success "Elasticsearch is running" || print_warning "Elasticsearch not responding"
else
    print_error "docker-compose.yml not found"
fi

# ============================================
# 6. PRE-COMMIT HOOKS
# ============================================

print_header "6. SETTING UP PRE-COMMIT HOOKS"

if [ -f ".pre-commit-config.yaml" ]; then
    echo "Installing pre-commit hooks..."
    pre-commit install
    pre-commit install --hook-type commit-msg
    pre-commit install --hook-type pre-push
    print_success "Pre-commit hooks installed"
else
    print_warning "No pre-commit config found"
fi

# ============================================
# 7. DIRECTORIES & PERMISSIONS
# ============================================

print_header "7. CREATING REQUIRED DIRECTORIES"

mkdir -p data/bronze data/silver data/gold
mkdir -p logs reports
mkdir -p quality/uncommitted/validations
mkdir -p quality/uncommitted/data_docs

print_success "Directories created"

# ============================================
# 8. DATA GENERATION
# ============================================

print_header "8. GENERATING SAMPLE DATA"

if [ -f "scripts/generate_dataset.py" ]; then
    echo "Generating ZeroMax sample dataset..."
    python scripts/generate_dataset.py
    print_success "Sample data generated"
else
    print_warning "Dataset generator not found (skip)"
fi

# ============================================
# 9. VERIFY SETUP
# ============================================

print_header "9. VERIFYING SETUP"

CHECKS_PASSED=0
CHECKS_TOTAL=5

# Check Python packages
python -c "import pandas, numpy, dbt, airflow, great_expectations" 2>/dev/null && {
    print_success "Python packages OK"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
} || print_warning "Some Python packages missing"

# Check dbt
cd dbt/zeromax_dwh && dbt --version > /dev/null 2>&1 && {
    print_success "dbt CLI OK"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
} || print_warning "dbt CLI not working"
cd ../..

# Check Docker
docker info > /dev/null 2>&1 && {
    print_success "Docker OK"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
} || print_warning "Docker not running"

# Check environment variables
[ -n "${SNOWFLAKE_ACCOUNT:-}" ] && {
    print_success "Snowflake config OK"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
} || print_warning "Snowflake not configured"

# Check project structure
[ -d "dbt" ] && [ -d "orchestration" ] && [ -d "quality" ] && {
    print_success "Project structure OK"
    CHECKS_PASSED=$((CHECKS_PASSED + 1))
} || print_warning "Project structure incomplete"

# ============================================
# 10. SUMMARY
# ============================================

print_header "SETUP COMPLETE"

echo ""
echo -e "${GREEN}╔════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║   ZEROMAX DEV ENVIRONMENT READY! 🚀    ║${NC}"
echo -e "${GREEN}╚════════════════════════════════════════╝${NC}"
echo ""
echo -e "  Checks Passed: ${GREEN}${CHECKS_PASSED}/${CHECKS_TOTAL}${NC}"
echo ""
echo -e "  Next Steps:"
echo -e "  1. Edit ${YELLOW}.env${NC} with your credentials"
echo -e "  2. Run ${YELLOW}make run-pipeline${NC} to start"
echo -e "  3. Visit ${BLUE}http://localhost:8080${NC} for Airflow"
echo -e "  4. Visit ${BLUE}http://localhost:3000${NC} for Grafana"
echo ""
echo -e "  Quick Commands:"
echo -e "  • ${YELLOW}make help${NC}          - Show all commands"
echo -e "  • ${YELLOW}make run-pipeline${NC} - Run delivery pipeline"
echo -e "  • ${YELLOW}make dbt-run${NC}      - Run dbt models"
echo -e "  • ${YELLOW}make test${NC}         - Run all tests"
echo ""