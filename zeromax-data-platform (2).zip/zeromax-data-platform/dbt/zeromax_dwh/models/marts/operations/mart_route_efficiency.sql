{{
  config(
    materialized='table',
    cluster_by=['zone_name', 'distance_category'],
    tags=['gold', 'operations', 'route', 'efficiency'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter",
      "GRANT SELECT ON {{ this }} TO ROLE analyst"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: MART_ROUTE_EFFICIENCY
-- ============================================================
-- Route efficiency analysis by zone, distance, vehicle, and time.
-- Identifies optimization opportunities for delivery routes.
-- ============================================================

WITH route_base AS (
    SELECT
        -- Zone
        dz.zone_name,
        dz.zone_id,
        
        -- Distance category
        fd.distance_category,
        fd.distance_km,
        
        -- Vehicle
        dv.vehicle_type,
        dv.vehicle_category,
        dv.speed_kmh,
        dv.cost_per_km,
        
        -- Time
        dt.period,
        dt.is_peak_hour,
        
        -- Route metrics
        fd.route_efficiency_pct,
        fd.optimal_distance_km,
        fd.distance_km AS actual_distance_km,
        (fd.distance_km - fd.optimal_distance_km) AS excess_distance_km,
        
        -- Time metrics
        fd.travel_time_base_min,
        fd.travel_time_actual_min,
        fd.delivery_duration_min,
        fd.delay_min,
        
        -- Cost
        fd.driver_cost_pkr,
        fd.profit_pkr,
        fd.delivery_fee_pkr,
        
        -- Count
        1 AS delivery_count
        
    FROM {{ ref('fct_delivery') }} fd
    INNER JOIN {{ ref('dim_zone') }} dz
        ON fd.zone_key = dz.zone_sk
    INNER JOIN {{ ref('dim_vehicle') }} dv
        ON fd.vehicle_key = dv.vehicle_sk
    INNER JOIN {{ ref('dim_time') }} dt
        ON fd.time_key = dt.time_sk
    WHERE fd.delivery_status != 'Failed'
      AND fd.order_datetime >= DATEADD(month, -3, CURRENT_DATE())
)

SELECT
    zone_name,
    zone_id,
    distance_category,
    vehicle_type,
    vehicle_category,
    period,
    is_peak_hour,
    
    -- Volume
    SUM(delivery_count) AS total_deliveries,
    
    -- Route Efficiency
    ROUND(AVG(route_efficiency_pct), 1) AS avg_route_efficiency_pct,
    ROUND(AVG(excess_distance_km), 2) AS avg_excess_distance_km,
    ROUND(AVG(actual_distance_km), 2) AS avg_distance_km,
    ROUND(AVG(optimal_distance_km), 2) AS avg_optimal_distance_km,
    
    -- Efficiency Distribution
    COUNT(CASE WHEN route_efficiency_pct >= 90 THEN 1 END) AS efficient_routes,
    COUNT(CASE WHEN route_efficiency_pct BETWEEN 70 AND 90 THEN 1 END) AS moderate_routes,
    COUNT(CASE WHEN route_efficiency_pct < 70 THEN 1 END) AS inefficient_routes,
    
    -- Time Impact
    ROUND(AVG(travel_time_actual_min), 1) AS avg_travel_time_min,
    ROUND(AVG(travel_time_base_min), 1) AS avg_base_travel_time_min,
    ROUND(AVG(travel_time_actual_min - travel_time_base_min), 1) AS avg_excess_travel_time_min,
    ROUND(AVG(delay_min), 1) AS avg_delay_min,
    
    -- Cost Impact
    ROUND(AVG(driver_cost_pkr), 0) AS avg_driver_cost,
    ROUND(AVG(profit_pkr), 0) AS avg_profit,
    ROUND(AVG(delivery_fee_pkr), 0) AS avg_revenue,
    
    -- Efficiency vs Cost Correlation
    ROUND(AVG(CASE WHEN route_efficiency_pct >= 90 THEN profit_pkr END), 0) AS avg_profit_efficient,
    ROUND(AVG(CASE WHEN route_efficiency_pct < 70 THEN profit_pkr END), 0) AS avg_profit_inefficient,
    
    -- Total Excess Cost
    ROUND(SUM(excess_distance_km * cost_per_km), 0) AS total_excess_cost_pkr,
    
    -- Potential Savings (if all routes were 90%+ efficient)
    ROUND(
        SUM(CASE WHEN route_efficiency_pct < 90 
            THEN (actual_distance_km * 0.9 - optimal_distance_km) * cost_per_km 
            ELSE 0 END), 0
    ) AS potential_savings_pkr,
    
    -- Efficiency Rate
    ROUND((efficient_routes * 100.0 / NULLIF(SUM(delivery_count), 0)), 1) AS efficiency_rate_pct,
    ROUND((inefficient_routes * 100.0 / NULLIF(SUM(delivery_count), 0)), 1) AS inefficiency_rate_pct,
    
    -- Optimization Priority Score (higher = needs more attention)
    ROUND(
        (inefficiency_rate_pct * 0.4) +
        (AVG(excess_distance_km) * 10 * 0.3) +
        (AVG(delay_min) * 0.3)
    , 1) AS optimization_priority_score,
    
    -- Recommended Action
    CASE
        WHEN inefficiency_rate_pct > 30 THEN 'Urgent Route Optimization Needed'
        WHEN inefficiency_rate_pct > 15 THEN 'Route Review Recommended'
        WHEN avg_route_efficiency_pct < 80 THEN 'Minor Adjustments'
        ELSE 'Routes Optimal'
    END AS optimization_recommendation,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'mart_route_efficiency' AS dw_source

FROM route_base
GROUP BY 
    zone_name, zone_id, distance_category,
    vehicle_type, vehicle_category, period, is_peak_hour