"""
================================================================================
ZEROMAX LOGISTICS - WEATHER API KAFKA PRODUCER
================================================================================
Fetches weather data from OpenWeatherMap API and produces to Kafka.
Provides real-time weather context for delivery operations.

Usage:
    python weather_api_producer.py
    python weather_api_producer.py --interval 300  # 5 minutes
================================================================================
"""

import os
import sys
import json
import time
import logging
from datetime import datetime
from typing import Dict, List, Optional

import requests
from confluent_kafka import Producer
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

KAFKA_CONFIG = {
    "bootstrap.servers": os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"),
    "client.id": "zeromax-weather-producer",
    "acks": 1,
}

WEATHER_TOPIC = "zeromax.weather"
API_KEY = os.getenv("OPENWEATHER_API_KEY", "demo")
BASE_URL = "https://api.openweathermap.org/data/2.5"

# Karachi zones with coordinates
ZONES = {
    "ZN001": {"name": "North Karachi", "lat": 24.9500, "lon": 67.0500},
    "ZN002": {"name": "South Karachi", "lat": 24.8100, "lon": 67.0300},
    "ZN003": {"name": "East Karachi", "lat": 24.9000, "lon": 67.1000},
    "ZN004": {"name": "West Karachi", "lat": 24.9200, "lon": 66.9800},
    "ZN005": {"name": "Central Karachi", "lat": 24.8800, "lon": 67.0450},
    "ZN006": {"name": "Malir", "lat": 24.8600, "lon": 67.2000},
    "ZN007": {"name": "Korangi", "lat": 24.8200, "lon": 67.1350},
    "ZN008": {"name": "Gulshan", "lat": 24.8950, "lon": 67.0800},
    "ZN009": {"name": "Shah Faisal", "lat": 24.8800, "lon": 67.1200},
    "ZN010": {"name": "Lyari", "lat": 24.8600, "lon": 67.0100},
}

# Weather condition mapping
WEATHER_CONDITIONS = {
    "Clear": {"severity": 1, "delay": 1.00},
    "Clouds": {"severity": 1, "delay": 1.05},
    "Drizzle": {"severity": 2, "delay": 1.15},
    "Rain": {"severity": 3, "delay": 1.35},
    "Thunderstorm": {"severity": 4, "delay": 1.70},
    "Fog": {"severity": 3, "delay": 1.50},
    "Dust": {"severity": 3, "delay": 1.40},
    "Haze": {"severity": 2, "delay": 1.10},
}


class WeatherAPIProducer:
    """Fetches weather data and produces to Kafka."""
    
    def __init__(self, api_key: str = None):
        self.producer = Producer(KAFKA_CONFIG)
        self.api_key = api_key or API_KEY
        self.session = requests.Session()
        self.call_count = 0
        
    def fetch_current_weather(self, lat: float, lon: float) -> Optional[Dict]:
        """
        Fetch current weather for coordinates.
        
        Args:
            lat: Latitude
            lon: Longitude
            
        Returns:
            Weather data dict or None on failure
        """
        try:
            params = {
                "lat": lat,
                "lon": lon,
                "appid": self.api_key,
                "units": "metric",
            }
            
            response = self.session.get(
                f"{BASE_URL}/weather",
                params=params,
                timeout=10,
            )
            
            self.call_count += 1
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 429:
                logger.warning("API rate limit reached")
                return None
            else:
                logger.error(f"API error: {response.status_code}")
                return None
                
        except requests.RequestException as e:
            logger.error(f"Request failed: {e}")
            return None
    
    def fetch_forecast(self, lat: float, lon: float) -> Optional[Dict]:
        """Fetch 5-day forecast for coordinates."""
        try:
            params = {
                "lat": lat,
                "lon": lon,
                "appid": self.api_key,
                "units": "metric",
                "cnt": 8,  # 24 hours (3-hour intervals)
            }
            
            response = self.session.get(
                f"{BASE_URL}/forecast",
                params=params,
                timeout=10,
            )
            
            self.call_count += 1
            
            if response.status_code == 200:
                return response.json()
            return None
            
        except requests.RequestException as e:
            logger.error(f"Forecast request failed: {e}")
            return None
    
    def transform_weather_data(self, raw_data: Dict, zone_id: str) -> Dict:
        """
        Transform raw API response to standardized format.
        
        Args:
            raw_data: Raw OpenWeatherMap response
            zone_id: Zone identifier
            
        Returns:
            Transformed weather event
        """
        weather_main = raw_data.get("weather", [{}])[0].get("main", "Clear")
        weather_desc = raw_data.get("weather", [{}])[0].get("description", "")
        
        condition_config = WEATHER_CONDITIONS.get(weather_main, {"severity": 1, "delay": 1.0})
        
        event = {
            "weather_id": f"WTH{int(time.time())}{zone_id[-3:]}",
            "zone_id": zone_id,
            "zone_name": ZONES[zone_id]["name"],
            "observation_timestamp": datetime.now().isoformat(),
            "weather_date": datetime.now().strftime("%Y-%m-%d"),
            "observation_hour": datetime.now().hour,
            "city": "Karachi",
            "country_code": "PK",
            "latitude": raw_data.get("coord", {}).get("lat"),
            "longitude": raw_data.get("coord", {}).get("lon"),
            "weather_condition": weather_main,
            "weather_description": weather_desc,
            "weather_icon_code": raw_data.get("weather", [{}])[0].get("icon", ""),
            "temperature_c": round(raw_data.get("main", {}).get("temp", 25), 1),
            "feels_like_c": round(raw_data.get("main", {}).get("feels_like", 25), 1),
            "temp_min_c": round(raw_data.get("main", {}).get("temp_min", 25), 1),
            "temp_max_c": round(raw_data.get("main", {}).get("temp_max", 25), 1),
            "humidity_pct": raw_data.get("main", {}).get("humidity", 50),
            "pressure_hpa": raw_data.get("main", {}).get("pressure", 1013),
            "wind_speed_kmh": round(raw_data.get("wind", {}).get("speed", 0) * 3.6, 1),
            "wind_gust_kmh": round(raw_data.get("wind", {}).get("gust", 0) * 3.6, 1) if raw_data.get("wind", {}).get("gust") else 0,
            "wind_direction_deg": raw_data.get("wind", {}).get("deg", 0),
            "visibility_km": round(raw_data.get("visibility", 10000) / 1000, 1),
            "cloud_coverage_pct": raw_data.get("clouds", {}).get("all", 0),
            "rain_mm": raw_data.get("rain", {}).get("1h", 0),
            "snow_mm": raw_data.get("snow", {}).get("1h", 0),
            "severity_level": condition_config["severity"],
            "delay_multiplier": condition_config["delay"],
            "is_extreme_weather": condition_config["severity"] >= 4,
            "sunrise_time": datetime.fromtimestamp(raw_data.get("sys", {}).get("sunrise", 0)).isoformat(),
            "sunset_time": datetime.fromtimestamp(raw_data.get("sys", {}).get("sunset", 0)).isoformat(),
            "ingestion_timestamp": datetime.now().isoformat(),
        }
        
        return event
    
    def produce_weather(self) -> int:
        """Fetch weather for all zones and produce to Kafka."""
        events_produced = 0
        
        for zone_id, zone_data in ZONES.items():
            raw_data = self.fetch_current_weather(zone_data["lat"], zone_data["lon"])
            
            if raw_data:
                event = self.transform_weather_data(raw_data, zone_id)
                
                self.producer.produce(
                    topic=WEATHER_TOPIC,
                    key=zone_id.encode("utf-8"),
                    value=json.dumps(event).encode("utf-8"),
                    callback=lambda err, msg: logger.error(f"Failed: {err}") if err else None,
                )
                events_produced += 1
            
            # Rate limiting for free API tier (60 calls/min)
            time.sleep(1)
        
        self.producer.poll(0)
        return events_produced
    
    def produce_simulated_weather(self) -> int:
        """
        Produce simulated weather data (for development/testing).
        No API calls needed.
        """
        import random
        
        conditions = list(WEATHER_CONDITIONS.keys())
        weights = [0.40, 0.15, 0.05, 0.05, 0.02, 0.03, 0.10, 0.20]  # Karachi-typical
        
        events_produced = 0
        
        for zone_id, zone_data in ZONES.items():
            condition = random.choices(conditions, weights=weights, k=1)[0]
            config = WEATHER_CONDITIONS[condition]
            
            temp = round(random.uniform(18, 38), 1)
            humidity = random.randint(30, 90)
            
            event = {
                "weather_id": f"WTH{int(time.time())}{zone_id[-3:]}",
                "zone_id": zone_id,
                "zone_name": zone_data["name"],
                "observation_timestamp": datetime.now().isoformat(),
                "weather_date": datetime.now().strftime("%Y-%m-%d"),
                "observation_hour": datetime.now().hour,
                "city": "Karachi",
                "country_code": "PK",
                "latitude": zone_data["lat"],
                "longitude": zone_data["lon"],
                "weather_condition": condition,
                "weather_description": f"Simulated {condition.lower()} conditions",
                "temperature_c": temp,
                "feels_like_c": round(temp + random.uniform(-3, 3), 1),
                "humidity_pct": humidity,
                "wind_speed_kmh": round(random.uniform(5, 40), 1),
                "severity_level": config["severity"],
                "delay_multiplier": config["delay"],
                "is_extreme_weather": config["severity"] >= 4,
                "ingestion_timestamp": datetime.now().isoformat(),
            }
            
            self.producer.produce(
                topic=WEATHER_TOPIC,
                key=zone_id.encode("utf-8"),
                value=json.dumps(event).encode("utf-8"),
            )
            events_produced += 1
        
        self.producer.poll(0)
        return events_produced
    
    def flush(self):
        self.producer.flush()


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Weather API Producer")
    parser.add_argument("--interval", type=int, default=1800, help="Fetch interval in seconds (default: 30 min)")
    parser.add_argument("--simulated", action="store_true", help="Use simulated data (no API key needed)")
    parser.add_argument("--duration", type=int, default=0, help="Duration in seconds (0=infinite)")
    args = parser.parse_args()
    
    producer = WeatherAPIProducer()
    
    if args.simulated:
        logger.info("Using SIMULATED weather data")
    else:
        if API_KEY == "demo":
            logger.warning("No API key found - using simulated data")
            args.simulated = True
        else:
            logger.info("Using OpenWeatherMap API")
    
    logger.info(f"Fetch interval: {args.interval}s")
    logger.info("Press Ctrl+C to stop")
    
    start_time = time.time()
    events_total = 0
    rounds = 0
    
    try:
        while True:
            if args.simulated:
                events = producer.produce_simulated_weather()
            else:
                events = producer.produce_weather()
            
            events_total += events
            rounds += 1
            
            producer.flush()
            logger.info(f"🌤️  Round {rounds}: {events} weather events (total: {events_total})")
            
            if args.duration > 0 and (time.time() - start_time) > args.duration:
                break
            
            time.sleep(args.interval)
            
    except KeyboardInterrupt:
        logger.info("\nShutting down...")
    finally:
        producer.flush()
        logger.info(f"✅ Total: {events_total} weather events in {rounds} rounds")


if __name__ == "__main__":
    main()