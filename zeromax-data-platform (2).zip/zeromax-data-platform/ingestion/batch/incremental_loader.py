"""
================================================================================
ZEROMAX LOGISTICS - INCREMENTAL DATA LOADER
================================================================================
Loads incremental/delta data from source systems to Bronze layer.
Handles CDC (Change Data Capture) and daily delta loads.

Usage:
    python incremental_loader.py
    python incremental_loader.py --since 2024-12-01
    python incremental_loader.py --lookback-hours 6
================================================================================
"""

import os
import sys
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from pathlib import Path

import pandas as pd
import numpy as np
from dotenv import load_dotenv

load_dotenv()

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/incremental_loader.log"),
    ],
)
logger = logging.getLogger(__name__)

# ============================================
# CONFIGURATION
# ============================================

DATA_DIR = os.getenv("DATA_DIR", "data")
BRONZE_DIR = os.path.join(DATA_DIR, "bronze")
CHECKPOINT_DIR = os.path.join(DATA_DIR, "checkpoints")

# Watermark file tracks last load timestamp
WATERMARK_FILE = os.path.join(CHECKPOINT_DIR, "watermark.json")

# Source system configurations
SOURCE_CONFIGS = {
    "delivery_app": {
        "type": "postgresql",
        "tables": ["orders", "deliveries", "driver_assignments"],
        "watermark_column": "updated_at",
    },
    "driver_app": {
        "type": "mongodb",
        "collections": ["driver_locations", "driver_status"],
        "watermark_column": "timestamp",
    },
    "restaurant_db": {
        "type": "mysql",
        "tables": ["restaurant_orders", "menu_updates"],
        "watermark_column": "last_modified",
    },
}


class WatermarkManager:
    """
    Manages incremental load watermarks.
    Tracks last successful load timestamp per source/table.
    """
    
    def __init__(self, checkpoint_dir: str = CHECKPOINT_DIR):
        self.checkpoint_dir = checkpoint_dir
        Path(checkpoint_dir).mkdir(parents=True, exist_ok=True)
        self.watermarks = self._load_watermarks()
    
    def _load_watermarks(self) -> Dict:
        """Load watermark file from disk."""
        if os.path.exists(WATERMARK_FILE):
            with open(WATERMARK_FILE, "r") as f:
                return json.load(f)
        
        # Initialize with default (24 hours ago)
        default_watermark = (datetime.now() - timedelta(hours=24)).isoformat()
        return {
            "default": default_watermark,
            "last_load_timestamp": None,
            "last_load_status": None,
        }
    
    def save_watermarks(self) -> None:
        """Save watermarks to disk."""
        with open(WATERMARK_FILE, "w") as f:
            json.dump(self.watermarks, f, indent=2)
    
    def get_watermark(self, source: str, table: str) -> datetime:
        """
        Get watermark for a source/table combination.
        Falls back to default watermark.
        """
        key = f"{source}.{table}"
        watermark_str = self.watermarks.get(key, self.watermarks.get("default"))
        return datetime.fromisoformat(watermark_str)
    
    def update_watermark(
        self, 
        source: str, 
        table: str, 
        new_watermark: datetime,
        load_status: str = "success",
    ) -> None:
        """Update watermark after successful load."""
        key = f"{source}.{table}"
        self.watermarks[key] = new_watermark.isoformat()
        self.watermarks["last_load_timestamp"] = datetime.now().isoformat()
        self.watermarks["last_load_status"] = load_status
        self.save_watermarks()
    
    def get_all_watermarks(self) -> Dict[str, str]:
        """Get all current watermarks."""
        return {
            k: v for k, v in self.watermarks.items() 
            if k not in ["last_load_timestamp", "last_load_status"]
        }


class IncrementalLoader:
    """
    Incremental data loader for Bronze layer.
    Supports multiple source systems with CDC.
    """
    
    def __init__(self, data_dir: str = None):
        self.data_dir = data_dir or DATA_DIR
        self.watermark_manager = WatermarkManager()
        self.stats = {
            "sources_processed": 0,
            "tables_loaded": 0,
            "total_rows_loaded": 0,
            "total_rows_skipped": 0,
            "errors": [],
            "start_time": datetime.now(),
        }
        
        Path(BRONZE_DIR).mkdir(parents=True, exist_ok=True)
    
    def extract_incremental_data(
        self,
        source: str,
        table: str,
        watermark_column: str,
        since: datetime = None,
        limit: int = None,
    ) -> pd.DataFrame:
        """
        Extract incremental data from source system.
        
        Args:
            source: Source system name
            table: Table/collection name
            watermark_column: Column to filter by
            since: Timestamp to filter from (default: last watermark)
            limit: Max rows to extract
            
        Returns:
            DataFrame with incremental data
        """
        if since is None:
            since = self.watermark_manager.get_watermark(source, table)
        
        logger.info(f"Extracting {source}.{table} since {since.isoformat()}")
        
        # ==========================================
        # SIMULATED EXTRACTION (Replace with real DB connections)
        # ==========================================
        
        # Generate simulated incremental data
        hours_since = (datetime.now() - since).total_seconds() / 3600
        
        if source == "delivery_app":
            df = self._simulate_delivery_data(table, hours_since, limit)
        elif source == "driver_app":
            df = self._simulate_driver_data(table, hours_since, limit)
        elif source == "restaurant_db":
            df = self._simulate_restaurant_data(table, hours_since, limit)
        else:
            df = pd.DataFrame()
        
        if not df.empty:
            logger.info(f"Extracted {len(df):,} rows from {source}.{table}")
        
        return df
    
    def _simulate_delivery_data(self, table: str, hours: float, limit: int = None) -> pd.DataFrame:
        """Simulate delivery data extraction."""
        num_rows = min(int(hours * 50), limit or 10000)
        
        if table == "orders":
            return pd.DataFrame({
                "order_id": [f"ORD{int(datetime.now().timestamp()) + i}" for i in range(num_rows)],
                "customer_id": np.random.randint(1, 5001, num_rows),
                "restaurant_id": np.random.randint(1, 116, num_rows),
                "order_status": np.random.choice(["placed", "confirmed", "preparing"], num_rows),
                "order_amount": np.random.uniform(300, 3000, num_rows).round(0),
                "created_at": [datetime.now() - timedelta(minutes=np.random.randint(0, hours*60)) for _ in range(num_rows)],
                "updated_at": [datetime.now() - timedelta(minutes=np.random.randint(0, 30)) for _ in range(num_rows)],
            })
        elif table == "deliveries":
            return pd.DataFrame({
                "delivery_id": [f"DLV{int(datetime.now().timestamp()) + i}" for i in range(num_rows)],
                "order_id": [f"ORD{np.random.randint(1, 25000)}" for _ in range(num_rows)],
                "driver_id": [f"DRV{np.random.randint(1, 151):04d}" for _ in range(num_rows)],
                "status": np.random.choice(["assigned", "picked_up", "in_transit", "delivered"], num_rows),
                "distance_meters": np.random.randint(500, 15000, num_rows),
                "updated_at": [datetime.now() - timedelta(minutes=np.random.randint(0, 60)) for _ in range(num_rows)],
            })
        
        return pd.DataFrame()
    
    def _simulate_driver_data(self, collection: str, hours: float, limit: int = None) -> pd.DataFrame:
        """Simulate driver app data extraction."""
        num_rows = min(int(hours * 20), limit or 5000)
        
        if collection == "driver_locations":
            return pd.DataFrame({
                "driver_id": [f"DRV{np.random.randint(1, 151):04d}" for _ in range(num_rows)],
                "latitude": np.random.uniform(24.78, 25.02, num_rows).round(6),
                "longitude": np.random.uniform(66.90, 67.25, num_rows).round(6),
                "speed": np.random.uniform(0, 55, num_rows).round(1),
                "accuracy": np.random.choice([5, 10, 15, 20], num_rows),
                "timestamp": [datetime.now() - timedelta(minutes=np.random.randint(0, hours*60)) for _ in range(num_rows)],
            })
        elif collection == "driver_status":
            return pd.DataFrame({
                "driver_id": [f"DRV{np.random.randint(1, 151):04d}" for _ in range(num_rows)],
                "status": np.random.choice(["online", "offline", "on_delivery", "break"], num_rows),
                "battery_pct": np.random.randint(10, 100, num_rows),
                "timestamp": [datetime.now() - timedelta(minutes=np.random.randint(0, 30)) for _ in range(num_rows)],
            })
        
        return pd.DataFrame()
    
    def _simulate_restaurant_data(self, table: str, hours: float, limit: int = None) -> pd.DataFrame:
        """Simulate restaurant data extraction."""
        num_rows = min(int(hours * 30), limit or 5000)
        
        if table == "restaurant_orders":
            return pd.DataFrame({
                "restaurant_order_id": [f"RORD{int(datetime.now().timestamp()) + i}" for i in range(num_rows)],
                "restaurant_id": np.random.randint(1, 116, num_rows),
                "order_id": [f"ORD{np.random.randint(1, 25000)}" for _ in range(num_rows)],
                "status": np.random.choice(["received", "preparing", "ready", "picked_up"], num_rows),
                "prep_time_minutes": np.random.randint(5, 35, num_rows),
                "last_modified": [datetime.now() - timedelta(minutes=np.random.randint(0, hours*60)) for _ in range(num_rows)],
            })
        
        return pd.DataFrame()
    
    def validate_incremental_data(self, df: pd.DataFrame, table: str) -> Tuple[bool, List[str]]:
        """
        Validate extracted data before loading.
        
        Returns:
            Tuple of (is_valid, list_of_warnings)
        """
        warnings = []
        
        if df.empty:
            warnings.append(f"No data extracted for {table}")
            return True, warnings
        
        # Check for nulls in critical columns
        null_threshold = 0.10  # 10% nulls acceptable
        for col in df.columns:
            null_pct = df[col].isnull().mean()
            if null_pct > null_threshold:
                warnings.append(f"High null rate in {table}.{col}: {null_pct:.1%}")
        
        # Check row count
        if len(df) > 100000:
            warnings.append(f"Large batch for {table}: {len(df):,} rows")
        
        # Check for duplicates
        if df.duplicated().sum() > 0:
            warnings.append(f"Found {df.duplicated().sum()} duplicate rows in {table}")
            df = df.drop_duplicates()
        
        return True, warnings
    
    def load_to_bronze(
        self,
        df: pd.DataFrame,
        source: str,
        table: str,
        mode: str = "append",
    ) -> Dict:
        """
        Load incremental data to Bronze layer.
        
        Args:
            df: Data to load
            source: Source system name
            table: Table name
            mode: 'append' or 'overwrite'
            
        Returns:
            Load result dict
        """
        result = {
            "source": source,
            "table": table,
            "status": "pending",
            "rows_loaded": 0,
            "error": None,
        }
        
        try:
            if df.empty:
                result["status"] = "no_data"
                self.stats["total_rows_skipped"] += 1
                return result
            
            # Create Bronze path
            load_date = datetime.now().strftime("%Y%m%d_%H%M%S")
            target_dir = os.path.join(BRONZE_DIR, source, table)
            Path(target_dir).mkdir(parents=True, exist_ok=True)
            
            # Write to Parquet with partition
            df["load_date"] = datetime.now().strftime("%Y-%m-%d")
            df["load_timestamp"] = datetime.now().isoformat()
            
            output_path = os.path.join(target_dir, f"delta_{load_date}.parquet")
            df.to_parquet(output_path, index=False)
            
            # Update watermark
            if "updated_at" in df.columns:
                max_watermark = df["updated_at"].max()
            elif "timestamp" in df.columns:
                max_watermark = df["timestamp"].max()
            elif "last_modified" in df.columns:
                max_watermark = df["last_modified"].max()
            else:
                max_watermark = datetime.now()
            
            self.watermark_manager.update_watermark(
                source, table, 
                pd.to_datetime(max_watermark).to_pydatetime()
            )
            
            result["status"] = "loaded"
            result["rows_loaded"] = len(df)
            result["output_path"] = output_path
            
            self.stats["tables_loaded"] += 1
            self.stats["total_rows_loaded"] += len(df)
            
            logger.info(f"✅ {source}.{table}: {len(df):,} rows → {output_path}")
            
        except Exception as e:
            logger.error(f"❌ Error loading {source}.{table}: {str(e)}")
            result["status"] = "error"
            result["error"] = str(e)
            self.stats["errors"].append(f"{source}.{table}: {str(e)}")
        
        return result
    
    def run_incremental_load(
        self,
        sources: List[str] = None,
        lookback_hours: int = None,
        limit_per_table: int = None,
    ) -> Dict:
        """
        Run full incremental load cycle.
        
        Args:
            sources: List of sources to load (default: all)
            lookback_hours: Override watermark lookback
            limit_per_table: Max rows per table
            
        Returns:
            Statistics dictionary
        """
        if sources is None:
            sources = list(SOURCE_CONFIGS.keys())
        
        if lookback_hours:
            since = datetime.now() - timedelta(hours=lookback_hours)
            logger.info(f"Using lookback: {lookback_hours} hours (since {since.isoformat()})")
        else:
            since = None
            logger.info("Using watermark-based incremental load")
        
        logger.info("=" * 60)
        logger.info("🔄 INCREMENTAL DATA LOAD STARTING")
        logger.info(f"   Sources: {sources}")
        logger.info(f"   Lookback: {lookback_hours or 'watermark'} hours")
        logger.info("=" * 60)
        
        all_results = []
        
        for source in sources:
            source_config = SOURCE_CONFIGS.get(source)
            if not source_config:
                logger.warning(f"Unknown source: {source}")
                continue
            
            tables = source_config.get("tables", source_config.get("collections", []))
            watermark_col = source_config["watermark_column"]
            
            for table in tables:
                # Extract
                df = self.extract_incremental_data(
                    source=source,
                    table=table,
                    watermark_column=watermark_col,
                    since=since,
                    limit=limit_per_table,
                )
                
                # Validate
                is_valid, warnings = self.validate_incremental_data(df, table)
                
                if warnings:
                    for warning in warnings:
                        logger.warning(f"  ⚠️  {warning}")
                
                if not is_valid:
                    logger.error(f"  ❌ Validation failed for {source}.{table}")
                    continue
                
                # Load
                result = self.load_to_bronze(df, source, table)
                all_results.append(result)
            
            self.stats["sources_processed"] += 1
        
        # Generate summary
        self._print_summary()
        
        return self.stats
    
    def _print_summary(self) -> None:
        """Print load summary."""
        elapsed = (datetime.now() - self.stats["start_time"]).total_seconds()
        
        print("\n" + "=" * 60)
        print("📊 INCREMENTAL LOAD SUMMARY")
        print("=" * 60)
        print(f"  Sources Processed: {self.stats['sources_processed']}")
        print(f"  Tables Loaded:     {self.stats['tables_loaded']}")
        print(f"  Rows Loaded:       {self.stats['total_rows_loaded']:,}")
        print(f"  Rows Skipped:      {self.stats['total_rows_skipped']:,}")
        print(f"  Errors:            {len(self.stats['errors'])}")
        print(f"  Duration:          {elapsed:.1f}s")
        print("=" * 60)
        
        # Current watermarks
        watermarks = self.watermark_manager.get_all_watermarks()
        if watermarks:
            print("\n📌 Current Watermarks:")
            for key, value in watermarks.items():
                print(f"  {key}: {value}")
            print("=" * 60)


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Incremental Data Loader")
    parser.add_argument("--since", type=str, help="Load since date (YYYY-MM-DD)")
    parser.add_argument("--lookback-hours", type=int, help="Hours to look back")
    parser.add_argument("--sources", nargs="+", help="Specific sources to load")
    parser.add_argument("--limit", type=int, default=10000, help="Max rows per table")
    parser.add_argument("--data-dir", type=str, default=DATA_DIR, help="Data directory path")
    parser.add_argument("--dry-run", action="store_true", help="Show watermarks without loading")
    args = parser.parse_args()
    
    loader = IncrementalLoader(data_dir=args.data_dir)
    
    if args.dry_run:
        watermarks = loader.watermark_manager.get_all_watermarks()
        print("Current Watermarks:")
        for k, v in watermarks.items():
            print(f"  {k}: {v}")
        return
    
    # Calculate lookback
    lookback = args.lookback_hours
    if args.since:
        since_dt = datetime.fromisoformat(args.since)
        lookback = int((datetime.now() - since_dt).total_seconds() / 3600)
    
    loader.run_incremental_load(
        sources=args.sources,
        lookback_hours=lookback,
        limit_per_table=args.limit,
    )


if __name__ == "__main__":
    main()