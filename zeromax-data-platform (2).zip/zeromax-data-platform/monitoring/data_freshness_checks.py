"""
================================================================================
ZEROMAX LOGISTICS - DATA FRESHNESS MONITORING
================================================================================
Monitors data pipeline freshness, volume, and quality.
Sends alerts to Slack and Datadog when thresholds are breached.

Usage:
    python monitoring/data_freshness_checks.py
    python monitoring/data_freshness_checks.py --alert
================================================================================
"""

import os
import sys
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, asdict

import snowflake.connector
import pandas as pd
import numpy as np
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# ============================================
# CONFIGURATION
# ============================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/freshness_checks.log"),
    ],
)
logger = logging.getLogger(__name__)

# Snowflake connection
SNOWFLAKE_CONFIG = {
    "account": os.getenv("SNOWFLAKE_ACCOUNT"),
    "user": os.getenv("SNOWFLAKE_USER"),
    "password": os.getenv("SNOWFLAKE_PASSWORD"),
    "database": os.getenv("SNOWFLAKE_DATABASE", "ZEROMAX_DWH_PROD"),
    "warehouse": os.getenv("SNOWFLAKE_WAREHOUSE", "MONITORING_WH"),
    "role": os.getenv("SNOWFLAKE_ROLE", "MONITOR"),
}

# Freshness SLA thresholds (hours)
FRESHNESS_SLA = {
    "GOLD.FCT_DELIVERY": {"max_delay_hours": 2, "critical": True},
    "GOLD.MART_DAILY_OPERATIONS": {"max_delay_hours": 6, "critical": False},
    "GOLD.MART_PROFITABILITY": {"max_delay_hours": 6, "critical": False},
    "GOLD.AGG_DRIVER_SUMMARY": {"max_delay_hours": 12, "critical": False},
    "SILVER.STG_DELIVERY": {"max_delay_hours": 1, "critical": True},
}

# Volume thresholds (minimum expected rows)
VOLUME_THRESHOLDS = {
    "GOLD.FCT_DELIVERY": {"min_rows": 20000, "max_rows": 50000},
    "GOLD.MART_DAILY_OPERATIONS": {"min_rows": 300, "max_rows": 5000},
    "GOLD.DIM_DRIVER": {"min_rows": 100, "max_rows": 200},
    "GOLD.DIM_CUSTOMER": {"min_rows": 4000, "max_rows": 6000},
}

# Alert configuration
SLACK_WEBHOOK = os.getenv("SLACK_WEBHOOK_URL")
ALERT_COOLDOWN_MINUTES = 30  # Don't re-alert within 30 minutes


@dataclass
class FreshnessResult:
    """Data freshness check result."""
    table_name: str
    last_updated: Optional[datetime]
    hours_behind: float
    sla_threshold: float
    is_fresh: bool
    severity: str  # 'OK', 'WARNING', 'CRITICAL'
    message: str


@dataclass
class VolumeResult:
    """Data volume check result."""
    table_name: str
    current_rows: int
    min_threshold: int
    max_threshold: int
    is_normal: bool
    severity: str
    message: str


class DataFreshnessMonitor:
    """
    Monitors data freshness, volume, and quality across the data warehouse.
    """
    
    def __init__(self, sf_config: dict):
        """Initialize with Snowflake connection."""
        self.sf_config = sf_config
        self.conn = None
        self.results: Dict[str, List] = {
            "freshness": [],
            "volume": [],
            "quality": [],
        }
        self.last_alert_time: Dict[str, datetime] = {}
    
    def connect(self) -> None:
        """Establish Snowflake connection."""
        try:
            self.conn = snowflake.connector.connect(**self.sf_config)
            logger.info("✅ Connected to Snowflake")
        except Exception as e:
            logger.error(f"❌ Failed to connect to Snowflake: {e}")
            raise
    
    def disconnect(self) -> None:
        """Close Snowflake connection."""
        if self.conn:
            self.conn.close()
            logger.info("Connection closed")
    
    # ==========================================
    # FRESHNESS CHECKS
    # ==========================================
    
    def check_freshness(self, table_name: str, sla_config: dict) -> FreshnessResult:
        """
        Check if table data is within freshness SLA.
        
        Args:
            table_name: Fully qualified table name (e.g., GOLD.FCT_DELIVERY)
            sla_config: SLA configuration for this table
        
        Returns:
            FreshnessResult with check details
        """
        try:
            cursor = self.conn.cursor()
            
            # Get last update timestamp
            query = f"""
                SELECT 
                    MAX(dw_updated_at) as last_updated,
                    DATEDIFF('hour', last_updated, CURRENT_TIMESTAMP()) as hours_behind
                FROM {table_name}
            """
            
            cursor.execute(query)
            result = cursor.fetchone()
            
            last_updated = result[0] if result else None
            hours_behind = result[1] if result[1] is not None else 999
            
            max_delay = sla_config["max_delay_hours"]
            is_critical = sla_config.get("critical", False)
            
            # Determine status
            if hours_behind <= max_delay * 0.5:
                status = "OK"
                message = f"✅ {table_name}: Fresh (last updated {hours_behind:.1f}h ago)"
            elif hours_behind <= max_delay:
                status = "WARNING"
                message = f"⚠️  {table_name}: Approaching SLA (last updated {hours_behind:.1f}h ago, limit {max_delay}h)"
            elif is_critical:
                status = "CRITICAL"
                message = f"🚨 {table_name}: BREACHED SLA (last updated {hours_behind:.1f}h ago, limit {max_delay}h)"
            else:
                status = "WARNING"
                message = f"⚠️  {table_name}: Behind schedule (last updated {hours_behind:.1f}h ago)"
            
            result = FreshnessResult(
                table_name=table_name,
                last_updated=last_updated,
                hours_behind=hours_behind,
                sla_threshold=max_delay,
                is_fresh=(status == "OK"),
                severity=status,
                message=message,
            )
            
            logger.info(message)
            return result
            
        except Exception as e:
            logger.error(f"Error checking freshness for {table_name}: {e}")
            return FreshnessResult(
                table_name=table_name,
                last_updated=None,
                hours_behind=999,
                sla_threshold=sla_config["max_delay_hours"],
                is_fresh=False,
                severity="CRITICAL",
                message=f"❌ {table_name}: Error checking freshness - {str(e)}",
            )
    
    def check_all_freshness(self) -> List[FreshnessResult]:
        """Check freshness for all configured tables."""
        logger.info("=" * 60)
        logger.info("CHECKING DATA FRESHNESS")
        logger.info("=" * 60)
        
        results = []
        for table_name, sla_config in FRESHNESS_SLA.items():
            result = self.check_freshness(table_name, sla_config)
            results.append(result)
            self.results["freshness"].append(asdict(result))
        
        return results
    
    # ==========================================
    # VOLUME CHECKS
    # ==========================================
    
    def check_volume(self, table_name: str, threshold: dict) -> VolumeResult:
        """
        Check if table row count is within expected range.
        
        Args:
            table_name: Table to check
            threshold: Min/max row thresholds
        
        Returns:
            VolumeResult with check details
        """
        try:
            cursor = self.conn.cursor()
            
            query = f"SELECT COUNT(*) FROM {table_name}"
            cursor.execute(query)
            row_count = cursor.fetchone()[0]
            
            min_rows = threshold["min_rows"]
            max_rows = threshold["max_rows"]
            
            if min_rows <= row_count <= max_rows:
                status = "OK"
                message = f"✅ {table_name}: Volume normal ({row_count:,} rows)"
            elif row_count < min_rows * 0.5:
                status = "CRITICAL"
                message = f"🚨 {table_name}: Volume critically low ({row_count:,} rows, min {min_rows:,})"
            elif row_count < min_rows:
                status = "WARNING"
                message = f"⚠️  {table_name}: Volume below threshold ({row_count:,} rows, min {min_rows:,})"
            elif row_count > max_rows * 1.5:
                status = "WARNING"
                message = f"⚠️  {table_name}: Volume spike ({row_count:,} rows, max {max_rows:,})"
            else:
                status = "OK"
                message = f"✅ {table_name}: Volume acceptable ({row_count:,} rows)"
            
            result = VolumeResult(
                table_name=table_name,
                current_rows=row_count,
                min_threshold=min_rows,
                max_threshold=max_rows,
                is_normal=(status == "OK"),
                severity=status,
                message=message,
            )
            
            logger.info(message)
            return result
            
        except Exception as e:
            logger.error(f"Error checking volume for {table_name}: {e}")
            return VolumeResult(
                table_name=table_name,
                current_rows=0,
                min_threshold=threshold["min_rows"],
                max_threshold=threshold["max_rows"],
                is_normal=False,
                severity="CRITICAL",
                message=f"❌ {table_name}: Error checking volume - {str(e)}",
            )
    
    def check_all_volumes(self) -> List[VolumeResult]:
        """Check volume for all configured tables."""
        logger.info("=" * 60)
        logger.info("CHECKING DATA VOLUMES")
        logger.info("=" * 60)
        
        results = []
        for table_name, threshold in VOLUME_THRESHOLDS.items():
            result = self.check_volume(table_name, threshold)
            results.append(result)
            self.results["volume"].append(asdict(result))
        
        return results
    
    # ==========================================
    # QUALITY METRIC CHECKS
    # ==========================================
    
    def check_null_rates(self) -> dict:
        """Check null rates for critical columns."""
        logger.info("=" * 60)
        logger.info("CHECKING NULL RATES")
        logger.info("=" * 60)
        
        null_checks = [
            ("GOLD.FCT_DELIVERY", "delivery_sk", 0.0),
            ("GOLD.FCT_DELIVERY", "driver_sk", 0.01),
            ("GOLD.FCT_DELIVERY", "customer_sk", 0.01),
            ("GOLD.FCT_DELIVERY", "profit_pkr", 0.0),
            ("GOLD.DIM_DRIVER", "driver_sk", 0.0),
            ("GOLD.DIM_CUSTOMER", "customer_sk", 0.0),
        ]
        
        results = []
        for table, column, max_null_rate in null_checks:
            cursor = self.conn.cursor()
            cursor.execute(f"""
                SELECT 
                    COUNT_IF({column} IS NULL) * 100.0 / COUNT(*) as null_rate
                FROM {table}
            """)
            null_rate = cursor.fetchone()[0]
            
            status = "OK" if null_rate <= max_null_rate else "WARNING"
            logger.info(f"  {table}.{column}: {null_rate:.2f}% null (max {max_null_rate:.1%})")
            
            results.append({
                "table": table,
                "column": column,
                "null_rate": null_rate,
                "threshold": max_null_rate,
                "status": status,
            })
        
        self.results["quality"].extend(results)
        return results
    
    # ==========================================
    # REPORTING
    # ==========================================
    
    def generate_report(self) -> dict:
        """Generate comprehensive freshness report."""
        freshness_results = self.results["freshness"]
        volume_results = self.results["volume"]
        
        critical_count = sum(
            1 for r in freshness_results if r["severity"] == "CRITICAL"
        )
        warning_count = sum(
            1 for r in freshness_results if r["severity"] == "WARNING"
        )
        
        report = {
            "timestamp": datetime.now().isoformat(),
            "overall_status": "HEALTHY" if critical_count == 0 else "DEGRADED" if critical_count < 2 else "CRITICAL",
            "summary": {
                "tables_checked": len(freshness_results),
                "tables_fresh": sum(1 for r in freshness_results if r["is_fresh"]),
                "tables_stale": sum(1 for r in freshness_results if not r["is_fresh"]),
                "critical_alerts": critical_count,
                "warnings": warning_count,
            },
            "details": {
                "freshness": freshness_results,
                "volume": volume_results,
            },
        }
        
        return report
    
    def save_report(self, report: dict, filename: str = None) -> str:
        """Save report to JSON file."""
        if filename is None:
            filename = f"reports/freshness_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        os.makedirs(os.path.dirname(filename), exist_ok=True)
        
        with open(filename, "w") as f:
            json.dump(report, f, indent=2, default=str)
        
        logger.info(f"📄 Report saved to {filename}")
        return filename
    
    def send_slack_alert(self, report: dict) -> None:
        """Send alert to Slack for critical issues."""
        if report["summary"]["critical_alerts"] == 0:
            return
        
        # Check cooldown
        now = datetime.now()
        if "slack" in self.last_alert_time:
            if (now - self.last_alert_time["slack"]).seconds < ALERT_COOLDOWN_MINUTES * 60:
                logger.info("Alert cooldown active, skipping Slack notification")
                return
        
        import requests
        
        critical_items = [
            r for r in report["details"]["freshness"] 
            if r["severity"] == "CRITICAL"
        ]
        
        message = "🚨 *ZeroMax Data Freshness Alert*\n\n"
        message += f"Critical Issues: {len(critical_items)}\n\n"
        
        for item in critical_items[:5]:  # Limit to 5 items
            message += f"• {item['table_name']}: {item['hours_behind']:.1f}h behind\n"
        
        message += f"\n📊 Full report: {report['summary']}"
        
        try:
            response = requests.post(
                SLACK_WEBHOOK,
                json={"text": message, "username": "Freshness Bot", "icon_emoji": ":warning:"},
                timeout=10,
            )
            
            if response.status_code == 200:
                self.last_alert_time["slack"] = now
                logger.info("✅ Slack alert sent")
            else:
                logger.error(f"Failed to send Slack alert: {response.status_code}")
        except Exception as e:
            logger.error(f"Error sending Slack alert: {e}")
    
    def run_all_checks(self) -> dict:
        """Run all freshness, volume, and quality checks."""
        self.connect()
        
        try:
            self.check_all_freshness()
            self.check_all_volumes()
            self.check_null_rates()
            
            report = self.generate_report()
            self.save_report(report)
            
            if report["summary"]["critical_alerts"] > 0:
                self.send_slack_alert(report)
            
            return report
        finally:
            self.disconnect()


# ============================================
# MAIN EXECUTION
# ============================================

def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Data Freshness Monitor")
    parser.add_argument(
        "--alert",
        action="store_true",
        help="Send Slack alerts for critical issues",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Output report file path",
    )
    args = parser.parse_args()
    
    monitor = DataFreshnessMonitor(SNOWFLAKE_CONFIG)
    report = monitor.run_all_checks()
    
    # Print summary
    print("\n" + "=" * 60)
    print("📊 FRESHNESS CHECK SUMMARY")
    print("=" * 60)
    print(f"Status: {report['overall_status']}")
    print(f"Tables Fresh: {report['summary']['tables_fresh']}/{report['summary']['tables_checked']}")
    print(f"Critical Alerts: {report['summary']['critical_alerts']}")
    print(f"Warnings: {report['summary']['warnings']}")
    print("=" * 60)
    
    # Exit with error code if critical issues
    if report["summary"]["critical_alerts"] > 0:
        sys.exit(1)
    else:
        sys.exit(0)


if __name__ == "__main__":
    main()