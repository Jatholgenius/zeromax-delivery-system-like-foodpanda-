{{
  config(
    materialized='table',
    tags=['ml', 'feature_store', 'demand_forecast'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE ml_engineer"
    ]
  )
}}

-- ============================================================
-- ML FEATURE STORE: FEATURES_DEMAND_FORECAST
-- ============================================================
-- Feature engineering for demand forecasting model.
-- Target: Hourly order count by zone (time series forecasting)
-- ============================================================

WITH hourly_demand AS (
    SELECT
        fd.date_key,
        dd.full_date,
        dd.year,
        dd.month_num,
        dd.week_num,
        dd.day_of_week,
        dd.day_name,
        dd.is_weekend,
        dd.is_holiday,
        dd.is_ramadan,
        dd.is_eid,
        dd.is_friday,
        dd.demand_multiplier,
        
        fd.time_key,
        dt.hour,
        dt.period,
        dt.is_peak_hour,
        dt.is_night,
        dt.rush_multiplier,
        
        fd.zone_key,
        dz.zone_name,
        dz.traffic_factor,
        
        -- Weather
        dw.weather_condition,
        dw.weather_severity,
        dw.temperature_c,
        dw.is_extreme_weather,
        
        -- Demand metrics
        COUNT(DISTINCT fd.delivery_sk) AS order_count,
        COUNT(DISTINCT fd.customer_sk) AS unique_customers,
        COUNT(DISTINCT fd.driver_sk) AS unique_drivers,
        SUM(fd.delivery_fee_pkr) AS total_revenue
        
    FROM {{ ref('fct_delivery') }} fd
    INNER JOIN {{ ref('dim_date') }} dd ON fd.date_key = dd.date_sk
    INNER JOIN {{ ref('dim_time') }} dt ON fd.time_key = dt.time_sk
    INNER JOIN {{ ref('dim_zone') }} dz ON fd.zone_key = dz.zone_sk
    LEFT JOIN {{ ref('dim_weather') }} dw ON fd.weather_key = dw.weather_sk
    
    WHERE fd.order_datetime >= DATEADD(month, -12, CURRENT_DATE())
    
    GROUP BY 
        fd.date_key, dd.full_date, dd.year, dd.month_num, dd.week_num,
        dd.day_of_week, dd.day_name, dd.is_weekend, dd.is_holiday,
        dd.is_ramadan, dd.is_eid, dd.is_friday, dd.demand_multiplier,
        fd.time_key, dt.hour, dt.period, dt.is_peak_hour, dt.is_night,
        dt.rush_multiplier,
        fd.zone_key, dz.zone_name, dz.traffic_factor,
        dw.weather_condition, dw.weather_severity, dw.temperature_c,
        dw.is_extreme_weather
)

SELECT
    *,
    
    -- ==========================================
    -- TARGET VARIABLE
    -- ==========================================
    order_count AS target_order_count,
    
    -- ==========================================
    -- LAG FEATURES (Previous demand patterns)
    -- ==========================================
    
    -- Same hour previous day
    LAG(order_count, 24) OVER (
        PARTITION BY zone_key 
        ORDER BY full_date, hour
    ) AS orders_same_hour_prev_day,
    
    -- Same hour previous week
    LAG(order_count, 168) OVER (
        PARTITION BY zone_key 
        ORDER BY full_date, hour
    ) AS orders_same_hour_prev_week,
    
    -- Previous hour same day
    LAG(order_count, 1) OVER (
        PARTITION BY zone_key 
        ORDER BY full_date, hour
    ) AS orders_prev_hour,
    
    -- ==========================================
    -- ROLLING AVERAGES
    -- ==========================================
    
    -- 7-day rolling average for this hour
    ROUND(AVG(order_count) OVER (
        PARTITION BY zone_key, hour
        ORDER BY full_date
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ), 0) AS rolling_7d_avg,
    
    -- 30-day rolling average for this hour
    ROUND(AVG(order_count) OVER (
        PARTITION BY zone_key, hour
        ORDER BY full_date
        ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
    ), 0) AS rolling_30d_avg,
    
    -- ==========================================
    -- TIME FEATURES
    -- ==========================================
    
    -- Cyclical encoding for hour
    SIN(2 * 3.14159 * hour / 24.0) AS hour_sin,
    COS(2 * 3.14159 * hour / 24.0) AS hour_cos,
    
    -- Cyclical encoding for day of week
    SIN(2 * 3.14159 * day_of_week / 7.0) AS dow_sin,
    COS(2 * 3.14159 * day_of_week / 7.0) AS dow_cos,
    
    -- Cyclical encoding for month
    SIN(2 * 3.14159 * month_num / 12.0) AS month_sin,
    COS(2 * 3.14159 * month_num / 12.0) AS month_cos,
    
    -- ==========================================
    -- WEEKLY PATTERNS
    -- ==========================================
    
    -- Average orders for this hour/day combination
    ROUND(AVG(order_count) OVER (
        PARTITION BY zone_key, hour, day_of_week
    ), 0) AS avg_hour_dow,
    
    -- Ratio vs average
    ROUND(order_count * 1.0 / NULLIF(AVG(order_count) OVER (
        PARTITION BY zone_key, hour, day_of_week
    ), 0), 2) AS demand_vs_avg_ratio,
    
    -- ==========================================
    -- DEMAND CATEGORY
    -- ==========================================
    
    CASE
        WHEN order_count >= 30 THEN 'Very High'
        WHEN order_count >= 20 THEN 'High'
        WHEN order_count >= 10 THEN 'Medium'
        WHEN order_count >= 5 THEN 'Low'
        ELSE 'Very Low'
    END AS demand_category,
    
    -- ==========================================
    -- METADATA
    -- ==========================================
    CURRENT_TIMESTAMP() AS feature_generated_at,
    'features_demand_forecast' AS feature_source

FROM hourly_demand