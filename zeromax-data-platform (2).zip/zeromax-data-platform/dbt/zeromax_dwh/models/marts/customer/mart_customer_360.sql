{{
  config(
    materialized='table',
    cluster_by=['customer_sk'],
    tags=['gold', 'customer', '360', 'pii', 'restricted'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE marketing_analyst",
      "GRANT SELECT ON {{ this }} TO ROLE executive"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: MART_CUSTOMER_360
-- ============================================================
-- Single customer view with all metrics and segments.
-- Used for customer analytics, segmentation, and retention.
-- ============================================================

WITH delivery_stats AS (
    SELECT
        fd.customer_sk,
        
        -- Order metrics
        COUNT(DISTINCT fd.delivery_sk) AS total_deliveries,
        COUNT(DISTINCT DATE_TRUNC('month', fd.order_datetime)) AS active_months,
        MIN(fd.order_datetime) AS first_order_date,
        MAX(fd.order_datetime) AS last_order_date,
        
        -- Frequency
        DATEDIFF('day', MIN(fd.order_datetime), MAX(fd.order_datetime)) AS customer_lifespan_days,
        ROUND(COUNT(*) * 1.0 / NULLIF(COUNT(DISTINCT DATE_TRUNC('month', fd.order_datetime)), 0), 1) 
            AS avg_orders_per_month,
        
        -- Status metrics
        SUM(fd.is_on_time) AS on_time_count,
        SUM(fd.is_late) AS late_count,
        SUM(fd.is_failed) AS failed_count,
        
        -- Financials
        SUM(fd.delivery_fee_pkr) AS total_spent,
        ROUND(AVG(fd.delivery_fee_pkr), 0) AS avg_order_value,
        SUM(fd.profit_pkr) AS total_profit_generated,
        SUM(fd.delay_penalty_pkr) AS total_penalties_incurred,
        
        -- Ratings
        ROUND(AVG(fd.customer_rating), 2) AS avg_rating_given,
        COUNT(CASE WHEN fd.customer_rating >= 4.5 THEN 1 END) AS excellent_ratings,
        COUNT(CASE WHEN fd.customer_rating < 3.0 THEN 1 END) AS poor_ratings,
        
        -- Distance
        ROUND(AVG(fd.distance_km), 2) AS avg_delivery_distance_km,
        SUM(fd.distance_km) AS total_distance_km,
        
        -- Preferences
        MODE() WITHIN GROUP (ORDER BY fd.restaurant_type) AS favorite_cuisine,
        MODE() WITHIN GROUP (ORDER BY fd.payment_method) AS preferred_payment,
        MODE() WITHIN GROUP (ORDER BY fd.delivery_zone) AS primary_zone,
        MODE() WITHIN GROUP (ORDER BY dt.period) AS preferred_time_period,
        
        -- Peak usage day
        MODE() WITHIN GROUP (ORDER BY dd.day_name) AS favorite_day,
        
        -- Time since last order
        DATEDIFF('day', MAX(fd.order_datetime), CURRENT_DATE()) AS days_since_last_order
        
    FROM {{ ref('fct_delivery') }} fd
    INNER JOIN {{ ref('dim_time') }} dt ON fd.time_key = dt.time_sk
    INNER JOIN {{ ref('dim_date') }} dd ON fd.date_key = dd.date_sk
    GROUP BY fd.customer_sk
),

customer_base AS (
    SELECT
        dc.customer_sk,
        dc.customer_id,
        dc.customer_name,
        dc.customer_type,
        dc.loyalty_tier,
        dc.join_date,
        dc.zone_name AS home_zone,
        dc.preferred_payment AS stated_preference,
        
        -- Combine with delivery stats
        COALESCE(ds.total_deliveries, 0) AS total_deliveries,
        COALESCE(ds.total_spent, 0) AS total_spent,
        COALESCE(ds.avg_rating_given, 0) AS avg_rating_given,
        ds.first_order_date,
        ds.last_order_date,
        ds.days_since_last_order,
        ds.customer_lifespan_days,
        ds.favorite_cuisine,
        ds.primary_zone,
        ds.preferred_time_period,
        ds.favorite_day
        
    FROM {{ ref('dim_customer_scd2') }} dc
    LEFT JOIN delivery_stats ds ON dc.customer_sk = ds.customer_sk
    WHERE dc.is_current = TRUE
)

SELECT
    *,
    
    -- ==========================================
    -- CUSTOMER SEGMENTATION
    -- ==========================================
    
    -- Recency Segment
    CASE
        WHEN days_since_last_order <= 7 THEN 'Active (Last 7 days)'
        WHEN days_since_last_order <= 30 THEN 'Recent (Last 30 days)'
        WHEN days_since_last_order <= 90 THEN 'Lapsed (1-3 months)'
        WHEN days_since_last_order <= 180 THEN 'Dormant (3-6 months)'
        ELSE 'Churned (6+ months)'
    END AS recency_segment,
    
    -- Frequency Segment
    CASE
        WHEN total_deliveries >= 100 THEN 'Power User'
        WHEN total_deliveries >= 50 THEN 'Frequent'
        WHEN total_deliveries >= 20 THEN 'Regular'
        WHEN total_deliveries >= 5 THEN 'Occasional'
        WHEN total_deliveries >= 1 THEN 'New/Infrequent'
        ELSE 'Never Ordered'
    END AS frequency_segment,
    
    -- Monetary Segment
    CASE
        WHEN total_spent >= 50000 THEN 'High Value'
        WHEN total_spent >= 25000 THEN 'Medium-High Value'
        WHEN total_spent >= 10000 THEN 'Medium Value'
        WHEN total_spent >= 5000 THEN 'Low-Medium Value'
        WHEN total_spent > 0 THEN 'Low Value'
        ELSE 'No Value'
    END AS monetary_segment,
    
    -- RFM Score (3-15 scale)
    CASE 
        WHEN days_since_last_order <= 7 THEN 5
        WHEN days_since_last_order <= 30 THEN 4
        WHEN days_since_last_order <= 90 THEN 3
        WHEN days_since_last_order <= 180 THEN 2
        ELSE 1
    END +
    CASE 
        WHEN total_deliveries >= 100 THEN 5
        WHEN total_deliveries >= 50 THEN 4
        WHEN total_deliveries >= 20 THEN 3
        WHEN total_deliveries >= 5 THEN 2
        ELSE 1
    END +
    CASE 
        WHEN total_spent >= 50000 THEN 5
        WHEN total_spent >= 25000 THEN 4
        WHEN total_spent >= 10000 THEN 3
        WHEN total_spent >= 5000 THEN 2
        ELSE 1
    END AS rfm_score,
    
    -- Customer Health
    CASE
        WHEN days_since_last_order > 90 THEN 'At Risk'
        WHEN avg_rating_given < 3.0 THEN 'Dissatisfied'
        WHEN rfm_score >= 12 THEN 'Champion'
        WHEN rfm_score >= 9 THEN 'Loyal'
        WHEN rfm_score >= 6 THEN 'Potential'
        ELSE 'Needs Attention'
    END AS customer_health,
    
    -- Churn Risk
    CASE
        WHEN days_since_last_order > 90 THEN 'High Risk'
        WHEN days_since_last_order > 60 THEN 'Medium Risk'
        WHEN days_since_last_order > 30 AND avg_rating_given < 3.5 THEN 'Low Risk'
        ELSE 'Healthy'
    END AS churn_risk,
    
    -- On-Time Rate
    ROUND((on_time_count * 100.0 / NULLIF(total_deliveries, 0)), 1) AS on_time_rate_pct,
    
    -- Failure Rate
    ROUND((failed_count * 100.0 / NULLIF(total_deliveries, 0)), 1) AS failure_rate_pct,
    
    -- Avg Order Value Tier
    CASE
        WHEN avg_order_value >= 400 THEN 'Premium'
        WHEN avg_order_value >= 250 THEN 'Standard'
        ELSE 'Budget'
    END AS spending_tier,
    
    -- Profitability Tier
    CASE
        WHEN total_profit_generated >= 10000 THEN 'Highly Profitable'
        WHEN total_profit_generated >= 5000 THEN 'Profitable'
        WHEN total_profit_generated >= 0 THEN 'Break-Even'
        ELSE 'Loss-Making'
    END AS profitability_tier,
    
    -- Retention Action
    CASE
        WHEN churn_risk = 'High Risk' AND monetary_segment = 'High Value' THEN 'Immediate Outreach'
        WHEN churn_risk = 'High Risk' THEN 'Win-Back Campaign'
        WHEN churn_risk = 'Medium Risk' THEN 'Engagement Campaign'
        WHEN customer_health = 'Champion' THEN 'Loyalty Rewards'
        ELSE 'Standard Nurture'
    END AS retention_action,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'mart_customer_360' AS dw_source

FROM customer_base