"""
================================================================================
ZEROMAX LOGISTICS - SLACK ALERTING SYSTEM
================================================================================
Centralized alerting for pipeline failures, data quality issues,
cost anomalies, and system health.

Usage:
    python monitoring/slack_alerts.py
    python monitoring/slack_alerts.py --test
================================================================================
"""

import os
import sys
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum

import requests
import snowflake.connector
import pandas as pd
from dotenv import load_dotenv

load_dotenv()

# ============================================
# CONFIGURATION
# ============================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/slack_alerts.log"),
    ],
)
logger = logging.getLogger(__name__)

# Slack Configuration
SLACK_BOT_TOKEN = os.getenv("SLACK_BOT_TOKEN")
SLACK_WEBHOOK_URL = os.getenv("SLACK_WEBHOOK_URL")
SLACK_CHANNEL_ALERTS = os.getenv("SLACK_CHANNEL_ALERTS", "#data-pipeline-alerts")
SLACK_CHANNEL_RELEASES = os.getenv("SLACK_CHANNEL_RELEASES", "#data-releases")
SLACK_CHANNEL_COST = os.getenv("SLACK_CHANNEL_COST", "#data-cost-alerts")

# Snowflake Configuration
SNOWFLAKE_CONFIG = {
    "account": os.getenv("SNOWFLAKE_ACCOUNT"),
    "user": os.getenv("SNOWFLAKE_USER"),
    "password": os.getenv("SNOWFLAKE_PASSWORD"),
    "database": "ZEROMAX_DWH_PROD",
    "warehouse": "MONITORING_WH",
    "role": "MONITOR",
}


class AlertSeverity(Enum):
    """Alert severity levels."""
    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"
    SUCCESS = "success"


class AlertCategory(Enum):
    """Categories of alerts."""
    PIPELINE = "Pipeline"
    DATA_QUALITY = "Data Quality"
    COST = "Cost"
    PERFORMANCE = "Performance"
    SECURITY = "Security"
    SYSTEM = "System"


@dataclass
class Alert:
    """Alert data structure."""
    title: str
    message: str
    severity: AlertSeverity
    category: AlertCategory
    timestamp: datetime = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()
        if self.metadata is None:
            self.metadata = {}


class SlackAlertManager:
    """
    Manages Slack alerts for the ZeroMax data platform.
    Handles routing, formatting, and rate limiting.
    """
    
    def __init__(self):
        self.webhook_url = SLACK_WEBHOOK_URL
        self.bot_token = SLACK_BOT_TOKEN
        self.alert_history: List[Alert] = []
        self.alert_counts: Dict[str, int] = {}
        self.last_alert_time: Dict[str, datetime] = {}
        self.rate_limit_seconds = 60  # Minimum seconds between same-type alerts
    
    # ==========================================
    # COLOR MAPPING
    # ==========================================
    
    @staticmethod
    def _severity_color(severity: AlertSeverity) -> str:
        """Map severity to Slack message color."""
        return {
            AlertSeverity.INFO: "#3498db",      # Blue
            AlertSeverity.WARNING: "#f39c12",    # Orange
            AlertSeverity.CRITICAL: "#e74c3c",   # Red
            AlertSeverity.SUCCESS: "#2ecc71",    # Green
        }.get(severity, "#95a5a6")
    
    @staticmethod
    def _severity_emoji(severity: AlertSeverity) -> str:
        """Map severity to emoji."""
        return {
            AlertSeverity.INFO: ":information_source:",
            AlertSeverity.WARNING: ":warning:",
            AlertSeverity.CRITICAL: ":rotating_light:",
            AlertSeverity.SUCCESS: ":white_check_mark:",
        }.get(severity, ":bell:")
    
    # ==========================================
    # RATE LIMITING
    # ==========================================
    
    def _is_rate_limited(self, alert_key: str) -> bool:
        """Check if alert should be rate limited."""
        if alert_key in self.last_alert_time:
            elapsed = (datetime.now() - self.last_alert_time[alert_key]).total_seconds()
            if elapsed < self.rate_limit_seconds:
                logger.info(f"Rate limiting alert: {alert_key} ({elapsed:.0f}s since last)")
                return True
        return False
    
    def _update_rate_limit(self, alert_key: str) -> None:
        """Update last alert time for rate limiting."""
        self.last_alert_time[alert_key] = datetime.now()
    
    # ==========================================
    # ALERT FORMATTING
    # ==========================================
    
    def _format_alert(self, alert: Alert) -> dict:
        """Format alert as Slack message payload."""
        
        # Build message blocks
        blocks = [
            {
                "type": "header",
                "text": {
                    "type": "plain_text",
                    "text": f"{self._severity_emoji(alert.severity)} {alert.title}",
                }
            },
            {"type": "divider"},
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": alert.message,
                }
            },
            {
                "type": "context",
                "elements": [
                    {
                        "type": "mrkdwn",
                        "text": f"*Category:* {alert.category.value} | *Time:* {alert.timestamp.strftime('%Y-%m-%d %H:%M:%S')} | *Severity:* {alert.severity.value.upper()}"
                    }
                ]
            }
        ]
        
        # Add metadata if present
        if alert.metadata:
            meta_text = "\n".join([
                f"• *{k}:* {v}" for k, v in alert.metadata.items()
            ])
            blocks.append({
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"*Details:*\n{meta_text}"
                }
            })
        
        payload = {
            "attachments": [
                {
                    "color": self._severity_color(alert.severity),
                    "blocks": blocks,
                    "footer": "ZeroMax Data Platform Monitor",
                    "footer_icon": "https://img.icons8.com/color/48/000000/delivery--v1.png",
                    "ts": int(alert.timestamp.timestamp()),
                }
            ]
        }
        
        return payload
    
    # ==========================================
    # SENDING ALERTS
    # ==========================================
    
    def send_alert(
        self,
        title: str,
        message: str,
        severity: AlertSeverity = AlertSeverity.INFO,
        category: AlertCategory = AlertCategory.SYSTEM,
        channel: str = None,
        metadata: Dict = None,
    ) -> bool:
        """
        Send alert to Slack.
        
        Args:
            title: Alert title
            message: Alert message body
            severity: Alert severity level
            category: Alert category
            channel: Slack channel override
            metadata: Additional metadata
        
        Returns:
            True if sent successfully
        """
        # Rate limit check
        alert_key = f"{category.value}:{severity.value}:{title}"
        if severity != AlertSeverity.CRITICAL and self._is_rate_limited(alert_key):
            return False
        
        # Create alert
        alert = Alert(
            title=title,
            message=message,
            severity=severity,
            category=category,
            metadata=metadata,
        )
        
        # Format payload
        payload = self._format_alert(alert)
        
        if channel:
            payload["channel"] = channel
        
        # Send to Slack
        try:
            response = requests.post(
                self.webhook_url,
                json=payload,
                headers={"Content-Type": "application/json"},
                timeout=10,
            )
            
            if response.status_code == 200:
                logger.info(f"Alert sent: {title}")
                self.alert_history.append(alert)
                self._update_rate_limit(alert_key)
                
                # Track counts
                key = f"{category.value}:{severity.value}"
                self.alert_counts[key] = self.alert_counts.get(key, 0) + 1
                
                return True
            else:
                logger.error(f"Slack API error: {response.status_code} - {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Failed to send alert: {e}")
            return False
    
    # ==========================================
    # PREDEFINED ALERTS
    # ==========================================
    
    def alert_pipeline_failure(self, dag_id: str, task_id: str, error: str) -> bool:
        """Alert on pipeline failure."""
        return self.send_alert(
            title=f"🚨 Pipeline Failed: {dag_id}",
            message=f"Task `{task_id}` failed in DAG `{dag_id}`.\n\n```{error[:500]}```",
            severity=AlertSeverity.CRITICAL,
            category=AlertCategory.PIPELINE,
            channel=SLACK_CHANNEL_ALERTS,
            metadata={
                "DAG": dag_id,
                "Task": task_id,
                "Error": error[:200],
            }
        )
    
    def alert_data_quality_issue(
        self, table: str, check_name: str, failed_count: int, total_count: int
    ) -> bool:
        """Alert on data quality failure."""
        failed_pct = (failed_count / total_count * 100) if total_count > 0 else 0
        
        severity = AlertSeverity.CRITICAL if failed_pct > 10 else AlertSeverity.WARNING
        
        return self.send_alert(
            title=f"Data Quality Issue: {table}",
            message=f"Check `{check_name}` failed.\n"
                    f"• Failed: {failed_count:,} rows\n"
                    f"• Total: {total_count:,} rows\n"
                    f"• Failure Rate: {failed_pct:.2f}%",
            severity=severity,
            category=AlertCategory.DATA_QUALITY,
            channel=SLACK_CHANNEL_ALERTS,
            metadata={
                "Table": table,
                "Check": check_name,
                "Failure Rate": f"{failed_pct:.2f}%",
            }
        )
    
    def alert_cost_spike(
        self, service: str, current_cost: float, avg_cost: float, pct_increase: float
    ) -> bool:
        """Alert on unexpected cost increase."""
        return self.send_alert(
            title=f"💰 Cost Spike Detected: {service}",
            message=f"Current cost is {pct_increase:.0f}% above average.\n"
                    f"• Current: ${current_cost:,.2f}\n"
                    f"• Average: ${avg_cost:,.2f}\n"
                    f"• Increase: ${current_cost - avg_cost:,.2f}",
            severity=AlertSeverity.WARNING if pct_increase < 50 else AlertSeverity.CRITICAL,
            category=AlertCategory.COST,
            channel=SLACK_CHANNEL_COST,
            metadata={
                "Service": service,
                "Current Cost": f"${current_cost:,.2f}",
                "Average Cost": f"${avg_cost:,.2f}",
                "Increase %": f"{pct_increase:.0f}%",
            }
        )
    
    def alert_pipeline_success(self, dag_id: str, records_processed: int, duration: float) -> bool:
        """Send success notification."""
        return self.send_alert(
            title=f"✅ Pipeline Complete: {dag_id}",
            message=f"Pipeline completed successfully.\n"
                    f"• Records: {records_processed:,}\n"
                    f"• Duration: {duration:.1f}s",
            severity=AlertSeverity.SUCCESS,
            category=AlertCategory.PIPELINE,
            channel=SLACK_CHANNEL_RELEASES,
            metadata={
                "DAG": dag_id,
                "Records": f"{records_processed:,}",
                "Duration": f"{duration:.1f}s",
            }
        )
    
    def alert_system_health(self, component: str, status: str, metrics: Dict = None) -> bool:
        """Alert on system health changes."""
        severity = {
            "healthy": AlertSeverity.SUCCESS,
            "degraded": AlertSeverity.WARNING,
            "down": AlertSeverity.CRITICAL,
        }.get(status, AlertSeverity.INFO)
        
        return self.send_alert(
            title=f"System Health: {component}",
            message=f"Component `{component}` is *{status.upper()}*.",
            severity=severity,
            category=AlertCategory.SYSTEM,
            channel=SLACK_CHANNEL_ALERTS,
            metadata=metrics or {"Status": status},
        )
    
    # ==========================================
    # DAILY SUMMARY
    # ==========================================
    
    def send_daily_summary(self) -> bool:
        """Send daily summary of all alerts and pipeline status."""
        
        # Get pipeline stats from Snowflake
        pipeline_stats = self._get_pipeline_stats()
        quality_stats = self._get_quality_stats()
        cost_stats = self._get_cost_stats()
        
        summary = f"""
📊 *ZeroMax Daily Pipeline Summary*
📅 {datetime.now().strftime('%Y-%m-%d')}

*Pipeline Status:*
• Total Runs: {pipeline_stats.get('total_runs', 'N/A')}
• Successful: {pipeline_stats.get('successful', 'N/A')}
• Failed: {pipeline_stats.get('failed', 'N/A')}
• Avg Duration: {pipeline_stats.get('avg_duration', 'N/A')}

*Data Quality:*
• Checks Passed: {quality_stats.get('passed', 'N/A')}
• Checks Failed: {quality_stats.get('failed', 'N/A')}
• Overall Score: {quality_stats.get('score', 'N/A')}%

*Cost Summary:*
• Snowflake Credits: {cost_stats.get('credits', 'N/A')}
• Estimated Cost: ${cost_stats.get('cost', 'N/A')}

*Alert Summary (24h):*
• Critical: {self.alert_counts.get('CRITICAL', 0)}
• Warnings: {self.alert_counts.get('WARNING', 0)}
• Info: {self.alert_counts.get('INFO', 0)}
        """
        
        return self.send_alert(
            title="Daily Summary Report",
            message=summary,
            severity=AlertSeverity.INFO,
            category=AlertCategory.SYSTEM,
            channel=SLACK_CHANNEL_RELEASES,
        )
    
    def _get_pipeline_stats(self) -> Dict:
        """Get pipeline statistics from Snowflake."""
        try:
            conn = snowflake.connector.connect(**SNOWFLAKE_CONFIG)
            cursor = conn.cursor()
            cursor.execute("""
                SELECT 
                    COUNT(*) as total_runs,
                    SUM(CASE WHEN status = 'success' THEN 1 ELSE 0 END) as successful,
                    SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed,
                    ROUND(AVG(duration_seconds), 1) as avg_duration
                FROM pipeline_run_history
                WHERE run_date = CURRENT_DATE()
            """)
            result = cursor.fetchone()
            conn.close()
            
            return {
                "total_runs": result[0],
                "successful": result[1],
                "failed": result[2],
                "avg_duration": f"{result[3]}s",
            }
        except Exception as e:
            logger.error(f"Error getting pipeline stats: {e}")
            return {}
    
    def _get_quality_stats(self) -> Dict:
        """Get data quality statistics."""
        return {"passed": "150/155", "failed": "5/155", "score": "96.8"}
    
    def _get_cost_stats(self) -> Dict:
        """Get cost statistics."""
        return {"credits": "245.3", "cost": "735.90"}
    
    # ==========================================
    # ALERT STATISTICS
    # ==========================================
    
    def get_alert_stats(self) -> Dict:
        """Get alert statistics for monitoring dashboard."""
        return {
            "total_alerts_24h": len([
                a for a in self.alert_history
                if a.timestamp > datetime.now() - timedelta(hours=24)
            ]),
            "by_severity": self.alert_counts,
            "by_category": {},
            "last_alert_time": max(self.last_alert_time.values()).isoformat() if self.last_alert_time else None,
        }


# ============================================
# MAIN EXECUTION
# ============================================

def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Slack Alert Manager")
    parser.add_argument("--test", action="store_true", help="Send test alert")
    parser.add_argument("--daily", action="store_true", help="Send daily summary")
    parser.add_argument("--pipeline-failure", action="store_true", help="Test pipeline failure alert")
    parser.add_argument("--cost-spike", action="store_true", help="Test cost spike alert")
    args = parser.parse_args()
    
    alert_manager = SlackAlertManager()
    
    if args.test:
        alert_manager.send_alert(
            title="Test Alert",
            message="This is a test alert from ZeroMax monitoring system.",
            severity=AlertSeverity.INFO,
            category=AlertCategory.SYSTEM,
        )
        print("✅ Test alert sent")
    
    elif args.daily:
        alert_manager.send_daily_summary()
        print("✅ Daily summary sent")
    
    elif args.pipeline_failure:
        alert_manager.alert_pipeline_failure(
            dag_id="zeromax_delivery_pipeline",
            task_id="ingest_kafka_to_bronze",
            error="ConnectionError: Failed to connect to Kafka broker at localhost:9092",
        )
        print("✅ Pipeline failure alert sent")
    
    elif args.cost_spike:
        alert_manager.alert_cost_spike(
            service="Snowflake",
            current_cost=1250.00,
            avg_cost=750.00,
            pct_increase=66.7,
        )
        print("✅ Cost spike alert sent")
    
    else:
        # Default: show stats
        stats = alert_manager.get_alert_stats()
        print(json.dumps(stats, indent=2, default=str))


if __name__ == "__main__":
    main()