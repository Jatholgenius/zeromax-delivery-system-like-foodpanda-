{{
  config(
    materialized='table',
    cluster_by=['order_datetime', 'zone_id'],
    tags=['intermediate', 'silver', 'enriched']
  )
}}

-- ============================================================
-- INTERMEDIATE: INT_DELIVERY_ENRICHED
-- ============================================================
-- Enriches delivery data with calculated metrics and joins
-- to reference tables. Prepares data for Gold layer.
-- ============================================================

WITH delivery AS (
    SELECT * FROM {{ ref('stg_delivery') }}
),

driver AS (
    SELECT * FROM {{ ref('stg_driver') }}
),

customer AS (
    SELECT * FROM {{ ref('stg_customer') }}
),

restaurant AS (
    SELECT * FROM {{ ref('stg_restaurant') }}
),

weather AS (
    SELECT * FROM {{ ref('stg_weather') }}
),

traffic AS (
    SELECT * FROM {{ ref('stg_traffic') }}
),

-- Join all sources
enriched AS (
    SELECT
        -- ==========================================
        -- DELIVERY KEYS
        -- ==========================================
        d.delivery_id,
        d.order_id,
        d.driver_id,
        d.customer_id,
        d.restaurant_id,
        d.zone_id,
        
        -- ==========================================
        -- TEMPORAL
        -- ==========================================
        d.order_datetime,
        d.order_date,
        d.date_key,
        d.time_key,
        EXTRACT(HOUR FROM d.order_datetime) AS order_hour,
        EXTRACT(DOW FROM d.order_datetime) AS order_day_of_week,
        EXTRACT(MONTH FROM d.order_datetime) AS order_month,
        EXTRACT(QUARTER FROM d.order_datetime) AS order_quarter,
        EXTRACT(YEAR FROM d.order_datetime) AS order_year,
        
        -- ==========================================
        -- COORDINATES
        -- ==========================================
        d.cust_lat,
        d.cust_lon,
        d.rest_lat,
        d.rest_lon,
        
        -- ==========================================
        -- DISTANCE METRICS
        -- ==========================================
        d.distance_km,
        d.optimal_distance_km,
        d.route_efficiency_pct,
        
        -- Distance validation
        {{ haversine_distance('d.rest_lat', 'd.rest_lon', 'd.cust_lat', 'd.cust_lon') }} AS calculated_distance_km,
        
        -- Distance category
        CASE
            WHEN d.distance_km <= 2 THEN 'Very Short (0-2 km)'
            WHEN d.distance_km <= 4 THEN 'Short (2-4 km)'
            WHEN d.distance_km <= 6 THEN 'Medium (4-6 km)'
            WHEN d.distance_km <= 8 THEN 'Long (6-8 km)'
            WHEN d.distance_km <= 10 THEN 'Very Long (8-10 km)'
            WHEN d.distance_km <= 12 THEN 'Extended (10-12 km)'
            ELSE 'Extreme (12+ km)'
        END AS distance_category,
        
        -- ==========================================
        -- TIME METRICS
        -- ==========================================
        d.preparation_time_min,
        d.pickup_delay_min,
        d.travel_time_base_min,
        d.travel_time_actual_min,
        d.delivery_duration_min,
        d.expected_duration_min,
        d.promised_duration_min,
        d.delay_min,
        
        -- Time breakdown percentages
        CASE 
            WHEN d.delivery_duration_min > 0 
            THEN ROUND((d.preparation_time_min * 100.0 / d.delivery_duration_min), 1)
            ELSE 0 
        END AS prep_time_pct,
        
        CASE 
            WHEN d.delivery_duration_min > 0 
            THEN ROUND((d.travel_time_actual_min * 100.0 / d.delivery_duration_min), 1)
            ELSE 0 
        END AS travel_time_pct,
        
        CASE 
            WHEN d.delivery_duration_min > 0 
            THEN ROUND((d.pickup_delay_min * 100.0 / d.delivery_duration_min), 1)
            ELSE 0 
        END AS pickup_delay_pct,
        
        -- ==========================================
        -- DELIVERY STATUS
        -- ==========================================
        d.delivery_status,
        d.delay_category,
        
        -- SLA breach flag
        CASE WHEN d.delay_min > {{ var('on_time_threshold_minutes', 5) }} THEN TRUE ELSE FALSE END AS is_sla_breach,
        
        -- ==========================================
        -- CUSTOMER RATING
        -- ==========================================
        d.customer_rating,
        
        CASE
            WHEN d.customer_rating IS NULL THEN 'Not Rated'
            WHEN d.customer_rating >= 4.5 THEN 'Excellent'
            WHEN d.customer_rating >= 4.0 THEN 'Good'
            WHEN d.customer_rating >= 3.0 THEN 'Average'
            WHEN d.customer_rating >= 2.0 THEN 'Poor'
            ELSE 'Very Poor'
        END AS rating_category,
        
        -- ==========================================
        -- FINANCIALS
        -- ==========================================
        d.delivery_fee_pkr,
        d.driver_cost_pkr,
        d.platform_fee_pkr,
        d.delay_penalty_pkr,
        d.profit_pkr,
        
        -- Profit margin
        CASE 
            WHEN d.delivery_fee_pkr > 0 
            THEN ROUND((d.profit_pkr * 100.0 / d.delivery_fee_pkr), 2)
            ELSE 0 
        END AS profit_margin_pct,
        
        -- Revenue per km
        CASE 
            WHEN d.distance_km > 0 
            THEN ROUND((d.delivery_fee_pkr / d.distance_km), 2)
            ELSE 0 
        END AS revenue_per_km,
        
        -- ==========================================
        -- DRIVER ATTRIBUTES
        -- ==========================================
        drv.driver_name,
        drv.experience_years,
        drv.experience_level,
        drv.vehicle_type,
        drv.home_zone AS driver_home_zone,
        drv.base_rating AS driver_base_rating,
        drv.speed_factor,
        drv.efficiency_score,
        drv.status AS driver_status,
        
        -- Driver experience category
        CASE 
            WHEN drv.experience_years < 1 THEN 'Novice'
            WHEN drv.experience_years < 3 THEN 'Intermediate'
            WHEN drv.experience_years < 5 THEN 'Experienced'
            ELSE 'Veteran'
        END AS driver_experience_category,
        
        -- ==========================================
        -- CUSTOMER ATTRIBUTES
        -- ==========================================
        cust.customer_name,
        cust.customer_type,
        cust.loyalty_tier AS customer_loyalty_tier,
        cust.join_date AS customer_join_date,
        cust.total_orders_lifetime AS customer_lifetime_orders,
        
        -- Customer tenure at time of order
        DATEDIFF('day', cust.join_date, d.order_datetime) AS customer_tenure_days,
        
        -- ==========================================
        -- RESTAURANT ATTRIBUTES
        -- ==========================================
        rest.restaurant_name,
        rest.cuisine_type AS restaurant_type,
        rest.avg_prep_time_min AS restaurant_avg_prep_time,
        rest.avg_rating AS restaurant_avg_rating,
        rest.price_tier AS restaurant_price_tier,
        rest.partnership_tier AS restaurant_partnership_tier,
        
        -- ==========================================
        -- WEATHER CONTEXT
        -- ==========================================
        w.weather_condition,
        w.temperature_c,
        w.humidity_pct,
        w.wind_speed_kmh,
        w.severity_level AS weather_severity,
        w.delay_multiplier AS weather_delay_multiplier,
        w.is_extreme_weather,
        w.temperature_category,
        
        -- ==========================================
        -- TRAFFIC CONTEXT
        -- ==========================================
        t.traffic_level,
        t.traffic_score,
        t.congestion_pct,
        t.avg_speed_kmh AS traffic_avg_speed,
        t.severity_level AS traffic_severity,
        t.delay_factor AS traffic_delay_factor,
        t.peak_period AS traffic_peak_period,
        t.is_peak_hour,
        t.active_incidents AS traffic_incidents,
        
        -- ==========================================
        -- COMBINED ENVIRONMENTAL FACTORS
        -- ==========================================
        (w.severity_level + t.severity_level) AS combined_severity,
        (w.delay_multiplier * t.delay_factor) AS combined_delay_multiplier,
        
        -- ==========================================
        -- DIMENSION KEYS
        -- ==========================================
        d.weather_key,
        d.traffic_key,
        d.vehicle_key,
        d.payment_key,
        d.cancel_key,
        
        -- ==========================================
        -- FLAGS
        -- ==========================================
        d.is_ramadan,
        d.is_eid,
        d.is_eid_adha,
        d.is_holiday,
        d.is_peak_hour,
        d.fatigue_factor,
        
        -- ==========================================
        -- METADATA
        -- ==========================================
        d.dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'int_delivery_enriched' AS dw_source
        
    FROM delivery d
    
    LEFT JOIN driver drv
        ON d.driver_id = drv.driver_id
    
    LEFT JOIN customer cust
        ON d.customer_id = cust.customer_id
    
    LEFT JOIN restaurant rest
        ON d.restaurant_id = rest.restaurant_id
    
    LEFT JOIN weather w
        ON d.weather_key = w.weather_id
        AND d.order_date = w.weather_date
        AND EXTRACT(HOUR FROM d.order_datetime) = w.observation_hour
    
    LEFT JOIN traffic t
        ON d.traffic_key = t.traffic_id
        AND d.order_date = t.traffic_date
        AND EXTRACT(HOUR FROM d.order_datetime) = t.traffic_hour
)

SELECT * FROM enriched