"""
================================================================================
ZEROMAX LOGISTICS - DATA QUALITY DAG
================================================================================
Automated data quality checks across all medallion layers.
Runs every 6 hours with Great Expectations suites.

Schedule: 0 */6 * * *
================================================================================
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.decorators import task, task_group
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.slack import SlackAPIPostOperator
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from airflow.utils.trigger_rule import TriggerRule
from airflow.models.param import Param
import json

default_args = {
    "owner": "data_quality_team",
    "depends_on_past": False,
    "email_on_failure": True,
    "email": ["data-quality@zeromax.com"],
    "retries": 1,
    "retry_delay": timedelta(minutes=10),
    "start_date": datetime(2024, 1, 1),
}

with DAG(
    dag_id="zeromax_data_quality",
    default_args=default_args,
    description="Data quality checks: Bronze → Silver → Gold",
    schedule_interval="0 */6 * * *",
    catchup=False,
    max_active_runs=1,
    max_active_tasks=8,
    tags=["zeromax", "quality", "monitoring"],
    params={
        "full_scan": Param(False, type="boolean", description="Full table scan"),
        "alert_on_warning": Param(True, type="boolean"),
    },
) as dag:

    # ============================================
    # TASK GROUP 1: BRONZE LAYER CHECKS
    # ============================================
    @task_group(group_id="bronze_quality_checks")
    def bronze_checks():
        
        @task(task_id="check_bronze_freshness")
        def check_bronze_freshness(**context):
            """Check data arrival in Bronze layer."""
            checks = {
                "delivery_events": {"last_arrival": "2 min ago", "status": "FRESH"},
                "gps_tracking": {"last_arrival": "30 sec ago", "status": "FRESH"},
                "weather_api": {"last_arrival": "15 min ago", "status": "FRESH"},
                "traffic_api": {"last_arrival": "10 min ago", "status": "FRESH"},
            }
            
            stale_count = sum(1 for v in checks.values() if v["status"] != "FRESH")
            
            if stale_count > 0:
                raise ValueError(f"{stale_count} sources are stale!")
            
            return checks
        
        @task(task_id="check_bronze_row_counts")
        def check_bronze_row_counts(**context):
            """Verify row counts in Bronze tables."""
            expected = {
                "delivery_events": (20000, 50000),
                "gps_tracking": (100000, 500000),
                "weather_api": (50, 500),
            }
            
            actual = {
                "delivery_events": 25000,
                "gps_tracking": 150000,
                "weather_api": 120,
            }
            
            results = {}
            for table, (min_val, max_val) in expected.items():
                count = actual.get(table, 0)
                status = "PASS" if min_val <= count <= max_val else "FAIL"
                results[table] = {"count": count, "min": min_val, "max": max_val, "status": status}
            
            return results
        
        @task(task_id="check_bronze_schema")
        def check_bronze_schema(**context):
            """Validate schema compliance."""
            return {"schemas_validated": 5, "schema_changes": 0, "status": "PASS"}
        
        return [
            check_bronze_freshness(),
            check_bronze_row_counts(),
            check_bronze_schema(),
        ]

    # ============================================
    # TASK GROUP 2: SILVER LAYER CHECKS
    # ============================================
    @task_group(group_id="silver_quality_checks")
    def silver_checks():
        
        run_silver_ge_suite = SnowflakeOperator(
            task_id="run_silver_ge_suite",
            snowflake_conn_id="snowflake_default",
            warehouse="VALIDATION_WH",
            sql="""
                CALL great_expectations.run_checkpoint('silver_checkpoint');
                
                SELECT 
                    suite_name,
                    total_expectations,
                    successful_expectations,
                    failed_expectations,
                    overall_status
                FROM VALIDATION_RESULTS
                WHERE run_time >= DATEADD(hour, -1, CURRENT_TIMESTAMP());
            """,
        )
        
        @task(task_id="check_referential_integrity")
        def check_referential_integrity(**context):
            """Check FK relationships in Silver layer."""
            orphan_checks = [
                {"table": "STG_DELIVERY", "fk": "driver_id", "ref": "STG_DRIVER", "orphans": 5},
                {"table": "STG_DELIVERY", "fk": "customer_id", "ref": "STG_CUSTOMER", "orphans": 2},
                {"table": "STG_DELIVERY", "fk": "restaurant_id", "ref": "STG_RESTAURANT", "orphans": 0},
            ]
            
            critical = [c for c in orphan_checks if c["orphans"] > 10]
            if critical:
                raise ValueError(f"Critical orphan records found: {len(critical)}")
            
            return orphan_checks
        
        @task(task_id="check_duplicates")
        def check_duplicates(**context):
            """Check for duplicate records."""
            return {
                "STG_DELIVERY": {"duplicates": 0, "status": "PASS"},
                "STG_DRIVER": {"duplicates": 2, "status": "WARN"},
                "STG_CUSTOMER": {"duplicates": 0, "status": "PASS"},
            }
        
        return [run_silver_ge_suite, check_referential_integrity(), check_duplicates()]

    # ============================================
    # TASK GROUP 3: GOLD LAYER CHECKS
    # ============================================
    @task_group(group_id="gold_quality_checks")
    def gold_checks():
        
        run_gold_ge_suite = SnowflakeOperator(
            task_id="run_gold_ge_suite",
            snowflake_conn_id="snowflake_default",
            warehouse="VALIDATION_WH",
            sql="""
                CALL great_expectations.run_checkpoint('gold_checkpoint');
            """,
        )
        
        @task(task_id="check_kpi_accuracy")
        def check_kpi_accuracy(**context):
            """Validate KPI calculations."""
            kpi_checks = {
                "on_time_rate": {"calculated": 78.5, "expected_range": (70, 90), "status": "PASS"},
                "avg_delivery_time": {"calculated": 32.3, "expected_range": (25, 45), "status": "PASS"},
                "profit_margin": {"calculated": 18.5, "expected_range": (10, 30), "status": "PASS"},
                "customer_rating": {"calculated": 4.2, "expected_range": (3.5, 5.0), "status": "PASS"},
            }
            
            failures = [k for k, v in kpi_checks.items() if v["status"] == "FAIL"]
            
            return {
                "kpis_checked": len(kpi_checks),
                "failures": len(failures),
                "details": kpi_checks,
            }
        
        @task(task_id="check_financial_reconciliation")
        def check_financial_reconciliation(**context):
            """Reconcile financial metrics."""
            reconciliation = {
                "revenue_sum": 5000000,
                "revenue_calculated": 5000123,
                "variance_pct": 0.002,
                "status": "PASS" if 0.002 < 0.01 else "FAIL",
            }
            return reconciliation
        
        @task(task_id="check_scd_type2_validity")
        def check_scd_type2_validity(**context):
            """Validate SCD Type 2 dimensions."""
            scd_checks = {
                "DIM_DRIVER": {
                    "overlapping_periods": 0,
                    "validity_gaps": 0,
                    "multiple_current": 0,
                    "status": "PASS",
                },
                "DIM_CUSTOMER": {
                    "overlapping_periods": 1,
                    "validity_gaps": 0,
                    "multiple_current": 0,
                    "status": "WARN",
                },
            }
            return scd_checks
        
        return [
            run_gold_ge_suite,
            check_kpi_accuracy(),
            check_financial_reconciliation(),
            check_scd_type2_validity(),
        ]

    # ============================================
    # TASK 4: ANOMALY DETECTION
    # ============================================
    @task(task_id="anomaly_detection")
    def detect_anomalies(**context):
        """Detect statistical anomalies in metrics."""
        import numpy as np
        
        # Simulated metric history
        metrics_history = {
            "daily_deliveries": {
                "current": 2500,
                "mean_7d": 2400,
                "std_7d": 150,
                "z_score": 0.67,
                "is_anomaly": False,
            },
            "on_time_rate": {
                "current": 78.5,
                "mean_7d": 80.2,
                "std_7d": 2.5,
                "z_score": -0.68,
                "is_anomaly": False,
            },
            "avg_rating": {
                "current": 3.8,
                "mean_7d": 4.2,
                "std_7d": 0.3,
                "z_score": -1.33,
                "is_anomaly": False,
            },
        }
        
        anomalies = [k for k, v in metrics_history.items() if v["is_anomaly"]]
        
        if anomalies:
            print(f"⚠️  Anomalies detected: {anomalies}")
        else:
            print("✅ No anomalies detected")
        
        return metrics_history

    # ============================================
    # TASK 5: QUALITY SCORE CALCULATION
    # ============================================
    @task(task_id="calculate_quality_score")
    def calculate_quality_score(**context):
        """Calculate overall data quality score."""
        
        scores = {
            "bronze": {"score": 95.0, "weight": 0.2},
            "silver": {"score": 92.0, "weight": 0.3},
            "gold": {"score": 88.0, "weight": 0.5},
        }
        
        weighted_score = sum(s["score"] * s["weight"] for s in scores.values())
        
        quality_tier = (
            "Excellent" if weighted_score >= 95 else
            "Good" if weighted_score >= 85 else
            "Fair" if weighted_score >= 70 else
            "Poor"
        )
        
        result = {
            "overall_score": round(weighted_score, 1),
            "tier": quality_tier,
            "breakdown": scores,
            "timestamp": datetime.now().isoformat(),
        }
        
        print(f"📊 Data Quality Score: {weighted_score:.1f} ({quality_tier})")
        return result

    # ============================================
    # TASK 6: DECISION BRANCH
    # ============================================
    @task(task_id="quality_decision", trigger_rule=TriggerRule.ALL_DONE)
    def quality_decision(**context):
        """Decide whether to alert or continue based on quality score."""
        ti = context["task_instance"]
        quality_result = ti.xcom_pull(task_ids="calculate_quality_score")
        
        if not quality_result:
            return "send_critical_alert"
        
        score = quality_result.get("overall_score", 0)
        
        if score < 70:
            return "send_critical_alert"
        elif score < 85:
            return "send_warning_alert"
        else:
            return "quality_passed"

    # ============================================
    # TASK 7: ALERTS
    # ============================================
    send_critical_alert = SlackAPIPostOperator(
        task_id="send_critical_alert",
        slack_conn_id="slack_default",
        channel="#data-alerts",
        text="""
        🚨 *CRITICAL DATA QUALITY ALERT*
        
        Overall Score: {{ ti.xcom_pull(task_ids='calculate_quality_score')['overall_score'] }}%
        Tier: {{ ti.xcom_pull(task_ids='calculate_quality_score')['tier'] }}
        
        Immediate investigation required!
        Runbook: https://docs.zeromax.com/runbooks/data-quality
        """,
        username="DQ Monitor",
        icon_emoji=":rotating_light:",
    )

    send_warning_alert = SlackAPIPostOperator(
        task_id="send_warning_alert",
        slack_conn_id="slack_default",
        channel="#data-alerts",
        text="""
        ⚠️ *Data Quality Warning*
        
        Overall Score: {{ ti.xcom_pull(task_ids='calculate_quality_score')['overall_score'] }}%
        Tier: {{ ti.xcom_pull(task_ids='calculate_quality_score')['tier'] }}
        
        Review quality dashboard: https://zeromax.com/quality
        """,
        username="DQ Monitor",
        icon_emoji=":warning:",
    )

    quality_passed = SlackAPIPostOperator(
        task_id="quality_passed",
        slack_conn_id="slack_default",
        channel="#data-monitoring",
        text="✅ Data quality check passed: {{ ti.xcom_pull(task_ids='calculate_quality_score')['overall_score'] }}%",
        username="DQ Monitor",
        icon_emoji=":white_check_mark:",
    )

    # ============================================
    # DAG STRUCTURE
    # ============================================
    bronze = bronze_checks()
    silver = silver_checks()
    gold = gold_checks()
    anomalies = detect_anomalies()
    quality_score = calculate_quality_score()
    decision = quality_decision()

 #   bronze >> silver >> gold >> anomalies >> quality_score >> decision
  #  decision >> [send_critical_alert, send_warning_alert, quality_passed]