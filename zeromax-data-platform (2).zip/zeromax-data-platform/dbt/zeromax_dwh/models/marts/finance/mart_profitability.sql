{{
  config(
    materialized='table',
    cluster_by=['month', 'zone_name'],
    tags=['gold', 'finance', 'profitability', 'sensitive'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE finance_analyst",
      "GRANT SELECT ON {{ this }} TO ROLE executive"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: MART_PROFITABILITY
-- ============================================================
-- Financial performance analysis mart.
-- Granularity: Monthly by zone, vehicle type, payment method.
-- ============================================================

WITH financial_base AS (
    SELECT
        -- Time dimensions
        DATE_TRUNC('month', fd.order_datetime) AS month,
        EXTRACT(YEAR FROM fd.order_datetime) AS year,
        EXTRACT(MONTH FROM fd.order_datetime) AS month_num,
        
        -- Zone
        dz.zone_name,
        dz.zone_id,
        
        -- Vehicle
        dv.vehicle_category,
        dv.vehicle_type,
        
        -- Payment
        dp.payment_method,
        dp.is_cod,
        
        -- Distance buckets
        {{ distance_category('fd.distance_km') }} AS distance_bucket,
        
        -- Delivery status
        fd.delivery_status,
        
        -- Aggregation
        COUNT(DISTINCT fd.delivery_sk) AS total_orders,
        
        -- Revenue breakdown
        SUM(fd.delivery_fee_pkr) AS gross_revenue,
        SUM(fd.driver_cost_pkr) AS driver_costs,
        SUM(fd.platform_fee_pkr) AS platform_fees,
        SUM(fd.delay_penalty_pkr) AS delay_penalties,
        
        -- Net profit
        SUM(fd.profit_pkr) AS net_profit,
        
        -- Averages
        ROUND(AVG(fd.delivery_fee_pkr), 0) AS avg_order_value,
        ROUND(AVG(fd.profit_pkr), 0) AS avg_profit_per_order,
        ROUND(AVG(fd.distance_km), 2) AS avg_distance_km,
        
        -- Distance totals
        SUM(fd.distance_km) AS total_distance_km,
        
        -- Time metrics
        ROUND(AVG(fd.delivery_duration_min), 1) AS avg_delivery_time_min,
        
        -- Rating
        ROUND(AVG(fd.customer_rating), 2) AS avg_rating,
        
        -- Metadata
        MAX(fd.dw_created_at) AS last_updated
        
    FROM {{ ref('fct_delivery') }} fd
    INNER JOIN {{ ref('dim_zone') }} dz
        ON fd.zone_key = dz.zone_key
    INNER JOIN {{ ref('dim_vehicle') }} dv
        ON fd.vehicle_key = dv.vehicle_key
    INNER JOIN {{ ref('dim_payment') }} dp
        ON fd.payment_key = dp.payment_key
    
    WHERE fd.order_datetime >= DATEADD(year, -2, CURRENT_DATE())
    
    GROUP BY 
        DATE_TRUNC('month', fd.order_datetime),
        EXTRACT(YEAR FROM fd.order_datetime),
        EXTRACT(MONTH FROM fd.order_datetime),
        dz.zone_name, dz.zone_id,
        dv.vehicle_category, dv.vehicle_type,
        dp.payment_method, dp.is_cod,
        distance_bucket,
        fd.delivery_status
)

SELECT
    *,
    
    -- ==========================================
    -- PROFITABILITY METRICS
    -- ==========================================
    
    -- Profit Margin (%)
    ROUND(
        (net_profit * 100.0 / NULLIF(gross_revenue, 0)), 2
    ) AS profit_margin_pct,
    
    -- Cost Ratio
    ROUND(
        ((driver_costs + platform_fees + delay_penalties) * 100.0 / NULLIF(gross_revenue, 0)), 2
    ) AS cost_ratio_pct,
    
    -- Revenue per KM
    ROUND(
        (gross_revenue * 1.0 / NULLIF(total_distance_km, 0)), 2
    ) AS revenue_per_km,
    
    -- Profit per KM
    ROUND(
        (net_profit * 1.0 / NULLIF(total_distance_km, 0)), 2
    ) AS profit_per_km,
    
    -- Driver cost ratio
    ROUND(
        (driver_costs * 100.0 / NULLIF(gross_revenue, 0)), 2
    ) AS driver_cost_pct,
    
    -- Platform fee ratio
    ROUND(
        (platform_fees * 100.0 / NULLIF(gross_revenue, 0)), 2
    ) AS platform_fee_pct,
    
    -- Penalty ratio
    ROUND(
        (delay_penalties * 100.0 / NULLIF(gross_revenue, 0)), 2
    ) AS penalty_pct,
    
    -- ==========================================
    -- RANKINGS & COMPARISONS
    -- ==========================================
    
    -- Zone ranking by profit
    RANK() OVER (
        PARTITION BY month 
        ORDER BY net_profit DESC
    ) AS zone_profit_rank,
    
    -- Zone ranking by margin
    RANK() OVER (
        PARTITION BY month 
        ORDER BY profit_margin_pct DESC
    ) AS zone_margin_rank,
    
    -- Vehicle ranking by profit
    RANK() OVER (
        PARTITION BY month 
        ORDER BY net_profit DESC
    ) AS vehicle_profit_rank,
    
    -- ==========================================
    -- GROWTH METRICS
    -- ==========================================
    
    -- Month over Month profit growth
    ROUND(
        ((net_profit - LAG(net_profit) OVER (
            PARTITION BY zone_id, vehicle_category, payment_method 
            ORDER BY month
        )) * 100.0 / NULLIF(LAG(net_profit) OVER (
            PARTITION BY zone_id, vehicle_category, payment_method 
            ORDER BY month
        ), 0)), 2
    ) AS mom_profit_growth_pct,
    
    -- Month over Month revenue growth
    ROUND(
        ((gross_revenue - LAG(gross_revenue) OVER (
            PARTITION BY zone_id, vehicle_category, payment_method 
            ORDER BY month
        )) * 100.0 / NULLIF(LAG(gross_revenue) OVER (
            PARTITION BY zone_id, vehicle_category, payment_method 
            ORDER BY month
        ), 0)), 2
    ) AS mom_revenue_growth_pct,
    
    -- ==========================================
    -- YEAR TO DATE
    -- ==========================================
    
    SUM(net_profit) OVER (
        PARTITION BY year, zone_id, vehicle_category, payment_method
        ORDER BY month
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS ytd_profit,
    
    SUM(gross_revenue) OVER (
        PARTITION BY year, zone_id, vehicle_category, payment_method
        ORDER BY month
        ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
    ) AS ytd_revenue,
    
    -- ==========================================
    -- PROFITABILITY FLAGS
    -- ==========================================
    
    CASE
        WHEN profit_margin_pct >= 25 THEN 'High Margin'
        WHEN profit_margin_pct >= 15 THEN 'Healthy Margin'
        WHEN profit_margin_pct >= 5 THEN 'Low Margin'
        WHEN profit_margin_pct >= 0 THEN 'Marginal'
        ELSE 'Loss Making'
    END AS profitability_category,
    
    -- ==========================================
    -- BREAK-EVEN ANALYSIS
    -- ==========================================
    
    CASE
        WHEN net_profit >= 0 THEN TRUE
        ELSE FALSE
    END AS is_profitable,
    
    -- Break-even distance (approximate)
    ROUND(
        (driver_costs + platform_fees) * 1.0 / NULLIF(total_orders, 0), 0
    ) AS break_even_cost_per_order

FROM financial_base