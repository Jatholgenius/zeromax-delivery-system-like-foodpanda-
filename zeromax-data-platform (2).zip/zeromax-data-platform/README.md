# 🚛 ZeroMax Logistics - Enterprise Data Platform

[![Python](https://img.shields.io/badge/Python-3.11-blue)](https://python.org)
[![dbt](https://img.shields.io/badge/dbt-1.7-orange)](https://dbt.com)
[![Airflow](https://img.shields.io/badge/Airflow-2.8-green)](https://airflow.apache.org)
[![Snowflake](https://img.shields.io/badge/Snowflake-Enterprise-blue)](https://snowflake.com)
[![PowerBI](https://img.shields.io/badge/PowerBI-Premium-yellow)](https://powerbi.microsoft.com)

## 📋 Overview

Enterprise-grade data engineering pipeline for **last-mile delivery optimization** in Karachi, Pakistan. Built with modern data stack (Medallion Architecture) for production-scale analytics and machine learning.

## 🏗️ Architecture

### Tech Stack
| Layer | Technology | Purpose |
|-------|-----------|---------|
| **Ingestion** | Apache Kafka, Airflow | Real-time + batch data ingestion |
| **Data Lake** | Azure Data Lake Gen2 | Raw data storage (Bronze/Silver) |
| **Transform** | dbt, Apache Spark | Data transformation & modeling |
| **Warehouse** | Snowflake | OLAP analytics (Gold Layer) |
| **Orchestration** | Apache Airflow | Pipeline scheduling & monitoring |
| **Quality** | Great Expectations | Data validation & quality checks |
| **ML** | Scikit-learn, Prophet | Delay prediction, demand forecasting |
| **BI** | Power BI Premium | Executive dashboards |
| **IaC** | Terraform | Infrastructure as Code |
| **CI/CD** | GitHub Actions | Automated deployment |
| **Monitoring** | Datadog, Slack | Pipeline observability |

## 📂 Project Structure
zeromax-data-platform/
├── infrastructure/ # Terraform IaC
├── ingestion/ # Kafka producers/consumers
├── orchestration/ # Airflow DAGs
├── dbt/ # Data transformations
├── quality/ # Great Expectations
├── ml/ # Machine Learning models
├── bi/ # Power BI dashboards
├── monitoring/ # Observability
└── docs/ # Documentation


## 🚀 Quick Start

### Prerequisites
```bash
# Install required tools
- Python 3.11+
- Docker Desktop
- Terraform CLI
- Snowflake account
- Azure subscription
# Clone repository
git clone https://github.com/your-org/zeromax-data-platform.git
cd zeromax-data-platform

# Setup virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Initialize dbt
cd dbt/zeromax_dwh
dbt deps

# Start Docker services
docker-compose up -d

# Provision infrastructure
cd infrastructure
terraform init
terraform apply
  

  #Run Pipeline

  # Trigger main DAG
airflow dags trigger zeromax_delivery_pipeline

# Run dbt models
dbt run --target prod

# Check data quality
great_expectations checkpoint run gold_checkpoint

📊 Dashboards
Dashboard	Description
01 Executive Overview	KPI cards, revenue trends, delivery status
02 Operations	Delay heatmaps, zone performance
03 Driver Performance	Driver scorecards, profit contribution
04 Geo Intelligence	Map visuals, zone boundaries
05 Customer Experience	Ratings analysis, churn prediction
06 Financial	Profitability, cost analysis

📈 Data Model
Star Schema
Fact: fct_delivery (25,000 rows)

Dimensions: dim_driver, dim_customer, dim_restaurant, dim_zone, dim_date, dim_time, dim_weather, dim_traffic, dim_vehicle, dim_payment, dim_cancellation

🔍 Data Quality
10+ Great Expectations suites

dbt tests for referential integrity

Anomaly detection with 3-sigma rule

Data freshness monitoring (2hr SLA)

📝 Documentation
Architecture Overview

Data Dictionary

Data Lineage

Incident Response

Disaster Recovery

🤝 Contributing
See CONTRIBUTING.md for development guidelines.

📄 License
MIT License - see LICENSE file.

📧 Contact
Data Engineering Team - data-eng@zeromax.com

