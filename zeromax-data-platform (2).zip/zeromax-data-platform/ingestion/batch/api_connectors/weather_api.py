"""
================================================================================
ZEROMAX LOGISTICS - WEATHER API CONNECTOR
================================================================================
Fetches weather data from OpenWeatherMap API.
Supports current conditions, forecast, and historical data.

Usage:
    python weather_api.py
    python weather_api.py --forecast
    python weather_api.py --historical 2024-01-01 2024-01-31
================================================================================
"""

import os
import sys
import json
import time
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from pathlib import Path

import requests
import pandas as pd
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ============================================
# CONFIGURATION
# ============================================

API_KEY = os.getenv("OPENWEATHER_API_KEY", "")
BASE_URL = "https://api.openweathermap.org/data/2.5"
GEO_URL = "https://api.openweathermap.org/geo/1.0"

KARACHI_COORDS = {"lat": 24.8607, "lon": 67.0011}

ZONES = {
    "ZN001": {"name": "North Karachi", "lat": 24.9500, "lon": 67.0500},
    "ZN002": {"name": "South Karachi", "lat": 24.8100, "lon": 67.0300},
    "ZN003": {"name": "East Karachi", "lat": 24.9000, "lon": 67.1000},
    "ZN004": {"name": "West Karachi", "lat": 24.9200, "lon": 66.9800},
    "ZN005": {"name": "Central Karachi", "lat": 24.8800, "lon": 67.0450},
    "ZN006": {"name": "Malir", "lat": 24.8600, "lon": 67.2000},
    "ZN007": {"name": "Korangi", "lat": 24.8200, "lon": 67.1350},
    "ZN008": {"name": "Gulshan", "lat": 24.8950, "lon": 67.0800},
    "ZN009": {"name": "Shah Faisal", "lat": 24.8800, "lon": 67.1200},
    "ZN010": {"name": "Lyari", "lat": 24.8600, "lon": 67.0100},
}

DATA_DIR = os.getenv("DATA_DIR", "data/bronze/weather_api")


class WeatherAPIConnector:
    """
    Connector for OpenWeatherMap API.
    Handles rate limiting, retries, and data transformation.
    """
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or API_KEY
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "ZeroMax-Data-Platform/1.0"
        })
        self.call_count = 0
        self.last_call_time = 0
        self.rate_limit = 60  # calls per minute (free tier)
        
        if not self.api_key:
            logger.warning("No API key provided. Using simulated data.")
    
    def _rate_limit_check(self) -> None:
        """Enforce API rate limiting."""
        self.call_count += 1
        
        if self.call_count >= self.rate_limit:
            elapsed = time.time() - self.last_call_time
            if elapsed < 60:
                wait_time = 60 - elapsed + 1
                logger.info(f"Rate limit approaching, waiting {wait_time:.0f}s...")
                time.sleep(wait_time)
            
            self.call_count = 0
            self.last_call_time = time.time()
    
    def _make_request(self, endpoint: str, params: Dict) -> Optional[Dict]:
        """
        Make API request with retry logic.
        
        Args:
            endpoint: API endpoint path
            params: Query parameters
            
        Returns:
            JSON response or None
        """
        url = f"{BASE_URL}/{endpoint}"
        params["appid"] = self.api_key
        
        for attempt in range(3):
            try:
                self._rate_limit_check()
                response = self.session.get(url, params=params, timeout=15)
                
                if response.status_code == 200:
                    return response.json()
                elif response.status_code == 429:
                    wait = (attempt + 1) * 30
                    logger.warning(f"Rate limited, waiting {wait}s...")
                    time.sleep(wait)
                elif response.status_code == 401:
                    logger.error("Invalid API key")
                    return None
                else:
                    logger.error(f"API error {response.status_code}: {response.text[:100]}")
                    
            except requests.RequestException as e:
                logger.error(f"Request failed (attempt {attempt + 1}): {e}")
                time.sleep(5)
        
        return None
    
    def get_current_weather(self, lat: float, lon: float) -> Optional[Dict]:
        """Get current weather for coordinates."""
        params = {
            "lat": lat,
            "lon": lon,
            "units": "metric",
            "lang": "en",
        }
        return self._make_request("weather", params)
    
    def get_forecast(self, lat: float, lon: float, hours: int = 24) -> Optional[Dict]:
        """Get weather forecast."""
        params = {
            "lat": lat,
            "lon": lon,
            "units": "metric",
            "cnt": min(hours // 3, 40),  # 3-hour intervals, max 40
        }
        return self._make_request("forecast", params)
    
    def get_air_pollution(self, lat: float, lon: float) -> Optional[Dict]:
        """Get air pollution data."""
        params = {"lat": lat, "lon": lon}
        return self._make_request("air_pollution", params)
    
    def fetch_all_zones_current(self) -> pd.DataFrame:
        """Fetch current weather for all zones."""
        if not self.api_key:
            return self._generate_simulated_weather()
        
        all_data = []
        
        for zone_id, zone in ZONES.items():
            logger.info(f"Fetching weather for {zone['name']}...")
            data = self.get_current_weather(zone["lat"], zone["lon"])
            
            if data:
                record = self._transform_weather_response(data, zone_id, zone["name"])
                all_data.append(record)
            else:
                # Use last known or simulated
                record = self._generate_zone_weather(zone_id, zone["name"])
                all_data.append(record)
        
        df = pd.DataFrame(all_data)
        return df
    
    def fetch_all_zones_forecast(self) -> pd.DataFrame:
        """Fetch forecast for all zones."""
        all_data = []
        
        for zone_id, zone in ZONES.items():
            data = self.get_forecast(zone["lat"], zone["lon"])
            
            if data and "list" in data:
                for entry in data["list"]:
                    record = self._transform_forecast_entry(entry, zone_id, zone["name"])
                    all_data.append(record)
        
        return pd.DataFrame(all_data)
    
    def _transform_weather_response(self, data: Dict, zone_id: str, zone_name: str) -> Dict:
        """Transform API response to standard format."""
        return {
            "weather_id": f"WTH{int(time.time())}{zone_id[-3:]}",
            "zone_id": zone_id,
            "zone_name": zone_name,
            "observation_timestamp": datetime.now().isoformat(),
            "weather_date": datetime.now().strftime("%Y-%m-%d"),
            "observation_hour": datetime.now().hour,
            "city": "Karachi",
            "country_code": "PK",
            "latitude": data.get("coord", {}).get("lat"),
            "longitude": data.get("coord", {}).get("lon"),
            "weather_condition": data.get("weather", [{}])[0].get("main", "Clear"),
            "weather_description": data.get("weather", [{}])[0].get("description", ""),
            "temperature_c": data.get("main", {}).get("temp"),
            "feels_like_c": data.get("main", {}).get("feels_like"),
            "humidity_pct": data.get("main", {}).get("humidity"),
            "pressure_hpa": data.get("main", {}).get("pressure"),
            "wind_speed_kmh": round(data.get("wind", {}).get("speed", 0) * 3.6, 1),
            "visibility_km": round(data.get("visibility", 10000) / 1000, 1),
            "cloud_coverage_pct": data.get("clouds", {}).get("all", 0),
            "ingestion_timestamp": datetime.now().isoformat(),
        }
    
    def _transform_forecast_entry(self, entry: Dict, zone_id: str, zone_name: str) -> Dict:
        """Transform forecast entry."""
        return {
            "zone_id": zone_id,
            "zone_name": zone_name,
            "forecast_timestamp": entry.get("dt_txt"),
            "weather_condition": entry.get("weather", [{}])[0].get("main"),
            "temperature_c": entry.get("main", {}).get("temp"),
            "humidity_pct": entry.get("main", {}).get("humidity"),
            "wind_speed_kmh": round(entry.get("wind", {}).get("speed", 0) * 3.6, 1),
            "probability_precipitation": entry.get("pop", 0) * 100,
            "ingestion_timestamp": datetime.now().isoformat(),
        }
    
    def _generate_simulated_weather(self) -> pd.DataFrame:
        """Generate simulated weather data for development."""
        import numpy as np
        
        records = []
        conditions = ["Clear", "Clouds", "Haze", "Drizzle", "Rain"]
        weights = [0.50, 0.20, 0.15, 0.10, 0.05]
        
        for zone_id, zone in ZONES.items():
            condition = np.random.choice(conditions, p=weights)
            records.append({
                "weather_id": f"WTH{int(time.time())}{zone_id[-3:]}",
                "zone_id": zone_id,
                "zone_name": zone["name"],
                "observation_timestamp": datetime.now().isoformat(),
                "weather_date": datetime.now().strftime("%Y-%m-%d"),
                "observation_hour": datetime.now().hour,
                "city": "Karachi",
                "country_code": "PK",
                "latitude": zone["lat"],
                "longitude": zone["lon"],
                "weather_condition": condition,
                "weather_description": f"Simulated {condition.lower()}",
                "temperature_c": round(np.random.uniform(18, 38), 1),
                "feels_like_c": round(np.random.uniform(16, 40), 1),
                "humidity_pct": np.random.randint(30, 85),
                "pressure_hpa": np.random.randint(1005, 1020),
                "wind_speed_kmh": round(np.random.uniform(5, 35), 1),
                "visibility_km": round(np.random.uniform(2, 15), 1),
                "cloud_coverage_pct": np.random.randint(0, 100),
                "ingestion_timestamp": datetime.now().isoformat(),
            })
        
        return pd.DataFrame(records)
    
    def save_to_bronze(self, df: pd.DataFrame, data_type: str = "current") -> str:
        """Save weather data to Bronze layer."""
        output_dir = Path(DATA_DIR) / data_type / datetime.now().strftime("%Y/%m/%d")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        output_file = output_dir / f"weather_{datetime.now().strftime('%Y%m%d_%H%M%S')}.parquet"
        df.to_parquet(output_file, index=False)
        
        logger.info(f"✅ Saved {len(df)} records to {output_file}")
        return str(output_file)


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Weather API Connector")
    parser.add_argument("--forecast", action="store_true", help="Fetch forecast data")
    parser.add_argument("--pollution", action="store_true", help="Fetch air pollution data")
    parser.add_argument("--output-dir", type=str, default=DATA_DIR, help="Output directory")
    args = parser.parse_args()
    
    connector = WeatherAPIConnector()
    
    if args.forecast:
        df = connector.fetch_all_zones_forecast()
        connector.save_to_bronze(df, "forecast")
    else:
        df = connector.fetch_all_zones_current()
        connector.save_to_bronze(df, "current")
    
    print(f"\n✅ Weather data fetched: {len(df)} records")


if __name__ == "__main__":
    main()