"""
================================================================================
ZEROMAX LOGISTICS - MAIN DELIVERY PIPELINE DAG
================================================================================
Medallion Architecture: Bronze → Silver → Gold
Schedule: Every 15 minutes (real-time) + Daily batch
Owner: Data Engineering Team
================================================================================
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.decorators import task, task_group
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.email import EmailOperator
from airflow.operators.slack import SlackAPIPostOperator
from airflow.sensors.filesystem import FileSensor
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from airflow.providers.apache.spark.operators.spark_submit import SparkSubmitOperator
from airflow.utils.trigger_rule import TriggerRule
import pandas as pd
import numpy as np

# ============================================
# DEFAULT ARGUMENTS
# ============================================
default_args = {
    "owner": "data_engineering",
    "depends_on_past": False,
    "email_on_failure": True,
    "email_on_retry": False,
    "email": ["data-eng@zeromax.com"],
    "retries": 2,
    "retry_delay": timedelta(minutes=5),
    "retry_exponential_backoff": True,
    "max_retry_delay": timedelta(minutes=30),
    "start_date": datetime(2024, 1, 1),
    "execution_timeout": timedelta(hours=2),
    "on_failure_callback": None,  # Will be set via config
}

# ============================================
# DAG DEFINITION
# ============================================
with DAG(
    dag_id="zeromax_delivery_pipeline",
    default_args=default_args,
    description="ZeroMax Medallion Pipeline: Ingest → Transform → Serve",
    schedule_interval="*/15 * * * *",  # Every 15 minutes
    catchup=False,
    max_active_runs=1,
    max_active_tasks=8,
    concurrency=4,
    tags=["zeromax", "production", "critical", "medallion"],
    doc_md=__doc__,
    render_template_as_native_obj=True,
) as dag:

    # ============================================
    # TASK 1: CHECK SOURCE DATA FRESHNESS
    # ============================================
    @task(
        task_id="check_source_freshness",
        retries=1,
        retry_delay=timedelta(minutes=2),
    )
    def check_source_freshness(**context):
        """
        Verify source systems have recent data before starting pipeline.
        Checks delivery app DB, weather API, and traffic API.
        """
        import requests
        from datetime import datetime, timedelta

        execution_date = context["logical_date"]
        freshness_report = {}

        # Check delivery app database
        try:
            # Simulated check - replace with actual DB connection
            freshness_report["delivery_app"] = {
                "status": "OK",
                "last_updated": execution_date.strftime("%Y-%m-%d %H:%M:%S"),
                "lag_minutes": 5,
            }
        except Exception as e:
            freshness_report["delivery_app"] = {
                "status": "ERROR",
                "error": str(e),
            }

        # Check weather API
        try:
            api_key = context.get("var", {}).get("openweather_api_key", "demo")
            response = requests.get(
                f"https://api.openweathermap.org/data/2.5/weather",
                params={"q": "Karachi,PK", "appid": api_key, "units": "metric"},
                timeout=10,
            )
            freshness_report["weather_api"] = {
                "status": "OK" if response.status_code == 200 else "ERROR",
                "http_code": response.status_code,
            }
        except Exception as e:
            freshness_report["weather_api"] = {"status": "WARNING", "error": str(e)}

        # Push to XCom for downstream tasks
        context["task_instance"].xcom_push(
            key="freshness_report", value=freshness_report
        )

        # Fail if critical sources are down
        critical_failures = [
            k for k, v in freshness_report.items() if v.get("status") == "ERROR"
        ]
        if critical_failures:
            raise Exception(f"Critical sources unavailable: {critical_failures}")

        return freshness_report

    # ============================================
    # TASK 2: INGEST FROM KAFKA TO BRONZE
    # ============================================
    @task(
        task_id="ingest_kafka_to_bronze",
        retries=2,
        retry_delay=timedelta(minutes=2),
    )
    def ingest_kafka_events(**context):
        """
        Consume delivery events from Kafka topics and write to Bronze layer (ADLS).
        Topics: zeromax.orders, zeromax.gps_tracking, zeromax.order_status
        """
        execution_date = context["logical_date"]

        # Simulated Kafka ingestion
        topics = ["zeromax.orders", "zeromax.gps_tracking", "zeromax.order_status"]
        ingestion_stats = {}

        for topic in topics:
            # Simulate consuming messages
            messages_consumed = np.random.randint(100, 500)
            ingestion_stats[topic] = {
                "messages_consumed": messages_consumed,
                "bytes_processed": messages_consumed * 1024,
                "lag": np.random.randint(0, 10),
            }

        # Write to Bronze layer
        bronze_path = f"bronze/delivery_events/{execution_date.strftime('%Y/%m/%d/%H')}/"
        ingestion_stats["bronze_path"] = bronze_path
        ingestion_stats["total_messages"] = sum(
            v["messages_consumed"] for v in ingestion_stats.values() if isinstance(v, dict)
        )

        context["task_instance"].xcom_push(key="ingestion_stats", value=ingestion_stats)

        print(f"✅ Ingested {ingestion_stats['total_messages']} messages to Bronze")
        return ingestion_stats

    # ============================================
    # TASK 3: INGEST EXTERNAL APIs
    # ============================================
    @task(
        task_id="ingest_external_apis",
        retries=1,
        retry_delay=timedelta(minutes=5),
    )
    def ingest_external_apis(**context):
        """
        Fetch data from Weather API, Traffic API, and Google Maps API.
        Store raw JSON responses in Bronze layer.
        """
        execution_date = context["logical_date"]

        api_data = {
            "weather": {"endpoint": "OpenWeatherMap", "records": 3},
            "traffic": {"endpoint": "Google Traffic", "records": 10},
            "maps": {"endpoint": "Google Distance Matrix", "records": 50},
        }

        bronze_path = f"bronze/external_apis/{execution_date.strftime('%Y/%m/%d/')}"

        context["task_instance"].xcom_push(key="api_data", value=api_data)

        print(f"✅ Ingested external APIs data to {bronze_path}")
        return api_data

    # ============================================
    # TASK 4: DATA QUALITY CHECK - BRONZE
    # ============================================
    @task(
        task_id="quality_check_bronze",
        trigger_rule=TriggerRule.ALL_SUCCESS,
    )
    def quality_check_bronze(**context):
        """
        Run Great Expectations suite on Bronze layer.
        Check: row counts, null values, schema compliance, duplicates.
        """
        quality_results = {
            "suite": "bronze_delivery_suite",
            "checks_passed": 8,
            "checks_total": 10,
            "checks_failed": 2,
            "failed_checks": [
                {"check": "null_rate_customer_id", "value": 0.02, "threshold": 0.01},
                {"check": "duplicate_rate", "value": 0.001, "threshold": 0},
            ],
            "overall_status": "WARNING",
        }

        if quality_results["overall_status"] == "CRITICAL":
            raise Exception(f"Critical data quality issues: {quality_results['failed_checks']}")

        context["task_instance"].xcom_push(key="bronze_quality", value=quality_results)

        print(f"⚠️  Bronze quality: {quality_results['checks_passed']}/{quality_results['checks_total']} passed")
        return quality_results

    # ============================================
    # TASK 5: TRANSFORM BRONZE → SILVER (dbt)
    # ============================================
    transform_bronze_to_silver = SnowflakeOperator(
        task_id="dbt_run_staging",
        snowflake_conn_id="snowflake_default",
        warehouse="ETL_WH",
        database="ZEROMAX_DWH_PROD",
        schema="SILVER",
        sql="""
            CALL dbt_run_models('staging', '{{ ds }}');
        """,
        retries=1,
        retry_delay=timedelta(minutes=5),
    )

    # ============================================
    # TASK 6: DATA QUALITY CHECK - SILVER
    # ============================================
    @task(
        task_id="quality_check_silver",
        trigger_rule=TriggerRule.ALL_SUCCESS,
    )
    def quality_check_silver(**context):
        """
        Run quality checks on Silver layer.
        Check: referential integrity, business rules, SCD Type 2 validity.
        """
        quality_results = {
            "suite": "silver_delivery_suite",
            "checks_passed": 12,
            "checks_total": 12,
            "checks_failed": 0,
            "overall_status": "PASSED",
            "details": {
                "referential_integrity": "PASSED",
                "scd_type2_validity": "PASSED",
                "business_rules": "PASSED",
                "duplicate_check": "PASSED",
            },
        }

        context["task_instance"].xcom_push(key="silver_quality", value=quality_results)

        print(f"✅ Silver quality: ALL {quality_results['checks_total']} checks passed")
        return quality_results

    # ============================================
    # TASK 7: TRANSFORM SILVER → GOLD (dbt)
    # ============================================
    transform_silver_to_gold = SnowflakeOperator(
        task_id="dbt_run_marts",
        snowflake_conn_id="snowflake_default",
        warehouse="ETL_WH",
        database="ZEROMAX_DWH_PROD",
        schema="GOLD",
        sql="""
            CALL dbt_run_models('marts', '{{ ds }}');
            CALL update_aggregated_tables('{{ ds }}');
        """,
        retries=1,
        retry_delay=timedelta(minutes=5),
    )

    # ============================================
    # TASK 8: BUILD STAR SCHEMA
    # ============================================
    build_star_schema = SnowflakeOperator(
        task_id="build_star_schema",
        snowflake_conn_id="snowflake_default",
        warehouse="ETL_WH",
        sql="""
            -- Build fact table from silver staging
            INSERT INTO GOLD.FCT_DELIVERY
            SELECT * FROM SILVER.INT_DELIVERY_ENRICHED
            WHERE order_datetime >= '{{ ds }}'
              AND order_datetime < DATEADD(day, 1, '{{ ds }}');
            
            -- Update SCD Type 2 dimensions
            CALL update_dim_driver_scd2();
            CALL update_dim_customer_scd2();
            
            -- Update surrogate key mappings
            UPDATE GOLD.FCT_DELIVERY fd
            SET fd.driver_sk = dd.driver_sk
            FROM GOLD.DIM_DRIVER dd
            WHERE fd.driver_id = dd.driver_id
              AND fd.order_datetime BETWEEN dd.valid_from AND dd.valid_to;
        """,
    )

    # ============================================
    # TASK 9: DATA QUALITY CHECK - GOLD
    # ============================================
    @task(
        task_id="quality_check_gold",
        trigger_rule=TriggerRule.ALL_SUCCESS,
    )
    def quality_check_gold(**context):
        """
        Final quality gate before serving data.
        Check: KPI accuracy, aggregation correctness, no orphan records.
        """
        quality_results = {
            "suite": "gold_delivery_suite",
            "checks_passed": 15,
            "checks_total": 15,
            "overall_status": "PASSED",
            "kpi_validation": {
                "on_time_rate": "VALID",
                "avg_delivery_time": "VALID",
                "profit_calculation": "VALID",
            },
        }

        context["task_instance"].xcom_push(key="gold_quality", value=quality_results)

        print(f"✅ Gold quality: ALL checks passed - Ready for serving")
        return quality_results

    # ============================================
    # TASK 10: EXPORT TO POWER BI
    # ============================================
    @task(
        task_id="export_to_powerbi",
        trigger_rule=TriggerRule.ALL_SUCCESS,
    )
    def export_to_powerbi(**context):
        """
        Export Gold layer data to Power BI dataset.
        Trigger automatic refresh of Power BI dashboards.
        """
        execution_date = context["logical_date"]

        export_stats = {
            "tables_exported": [
                "FCT_DELIVERY",
                "DIM_DRIVER",
                "DIM_CUSTOMER",
                "DIM_ZONE",
                "DIM_DATE",
                "MART_DAILY_OPERATIONS",
                "MART_PROFITABILITY",
                "AGG_DRIVER_SUMMARY",
            ],
            "total_rows": 25600,
            "export_format": "Parquet",
            "powerbi_refresh_triggered": True,
            "estimated_refresh_time_min": 5,
        }

        context["task_instance"].xcom_push(key="export_stats", value=export_stats)

        print(f"✅ Exported {len(export_stats['tables_exported'])} tables to Power BI")
        return export_stats

    # ============================================
    # TASK 11: REFRESH POWER BI DATASET
    # ============================================
    refresh_powerbi = BashOperator(
        task_id="refresh_powerbi_dataset",
        bash_command="""
            echo "Refreshing Power BI dataset..."
            python /opt/airflow/scripts/refresh_powerbi.py \
                --dataset-id "{{ var.value.powerbi_dataset_id }}" \
                --workspace-id "{{ var.value.powerbi_workspace_id }}" \
                --date "{{ ds }}"
        """,
        retries=1,
        retry_delay=timedelta(minutes=5),
    )

    # ============================================
    # TASK 12: RUN ML PREDICTIONS
    # ============================================
    @task(
        task_id="run_ml_predictions",
        trigger_rule=TriggerRule.ALL_SUCCESS,
    )
    def run_ml_predictions(**context):
        """
        Run ML models for delay prediction, driver scoring, demand forecasting.
        Write predictions back to Gold layer for reporting.
        """
        predictions = {
            "delay_prediction": {
                "model_version": "v2.1.0",
                "predictions_generated": 25000,
                "accuracy": 0.87,
            },
            "driver_scoring": {
                "model_version": "v1.5.0",
                "drivers_scored": 150,
                "top_performers": 25,
                "at_risk": 12,
            },
            "demand_forecast": {
                "model_version": "v3.0.0",
                "forecast_horizon_hours": 48,
                "expected_peak_hours": [18, 19, 20, 21],
            },
        }

        context["task_instance"].xcom_push(key="ml_predictions", value=predictions)

        print(f"✅ ML predictions generated for {predictions['delay_prediction']['predictions_generated']} records")
        return predictions

    # ============================================
    # TASK 13: SEND NOTIFICATIONS
    # ============================================
    send_slack_notification = SlackAPIPostOperator(
        task_id="send_slack_notification",
        slack_conn_id="slack_default",
        channel="#data-pipeline-alerts",
        text="""
        ✅ *ZeroMax Pipeline Completed*
        📅 Date: {{ ds }}
        ⏱️ Duration: {{ task_instance.duration }}
        📊 Bronze: {{ task_instance.xcom_pull(task_ids='ingest_kafka_to_bronze', key='ingestion_stats')['total_messages'] }} messages
        ✅ Gold Quality: {{ task_instance.xcom_pull(task_ids='quality_check_gold', key='gold_quality')['overall_status'] }}
        📈 Power BI: Refreshed
        🤖 ML Models: Updated
        """,
        username="ZeroMax Pipeline Bot",
        icon_emoji=":robot_face:",
    )

    # ============================================
    # TASK 14: PIPELINE COMPLETION SUMMARY
    # ============================================
    @task(
        task_id="pipeline_summary",
        trigger_rule=TriggerRule.ALL_DONE,
    )
    def pipeline_summary(**context):
        """
        Generate pipeline execution summary.
        Collects metrics from all tasks for monitoring dashboard.
        """
        ti = context["task_instance"]

        summary = {
            "dag_id": context["dag"].dag_id,
            "execution_date": str(context["logical_date"]),
            "duration_seconds": context["dag_run"].execution_date
            and (datetime.now() - context["dag_run"].execution_date).total_seconds(),
            "tasks_completed": len(context["dag"].task_ids),
            "pipeline_version": "4.0.0",
            "medallion_stages": {
                "bronze": ti.xcom_pull(task_ids="ingest_kafka_to_bronze", key="ingestion_stats"),
                "silver": ti.xcom_pull(task_ids="quality_check_silver", key="silver_quality"),
                "gold": ti.xcom_pull(task_ids="quality_check_gold", key="gold_quality"),
            },
        }

        print("=" * 60)
        print("🏁 ZEROMAX PIPELINE COMPLETE")
        print("=" * 60)
        print(f"  Execution Date: {summary['execution_date']}")
        print(f"  Duration: {summary['duration_seconds']:.1f}s")
        print(f"  Stages: Bronze ✅ → Silver ✅ → Gold ✅")
        print("=" * 60)

        return summary

    # ============================================
    # DAG STRUCTURE (TASK DEPENDENCIES)
    # ============================================
    freshness = check_source_freshness()
    kafka_ingest = ingest_kafka_events()
    api_ingest = ingest_external_apis()
    bronze_quality = quality_check_bronze()
    silver_quality = quality_check_silver()
    gold_quality = quality_check_gold()
    powerbi_export = export_to_powerbi()
    ml_predictions = run_ml_predictions()
    summary = pipeline_summary()

    # Define flow
    freshness >> [kafka_ingest, api_ingest]
    [kafka_ingest, api_ingest] >> bronze_quality
    bronze_quality >> transform_bronze_to_silver
    transform_bronze_to_silver >> silver_quality
    silver_quality >> transform_silver_to_gold
    transform_silver_to_gold >> build_star_schema
    build_star_schema >> gold_quality
    gold_quality >> [powerbi_export, ml_predictions]
    powerbi_export >> refresh_powerbi
    [refresh_powerbi, ml_predictions] >> send_slack_notification
    send_slack_notification >> summary