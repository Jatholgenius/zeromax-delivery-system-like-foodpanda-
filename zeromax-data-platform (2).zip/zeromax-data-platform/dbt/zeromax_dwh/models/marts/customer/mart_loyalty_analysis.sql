{{
  config(
    materialized='table',
    cluster_by=['loyalty_tier'],
    tags=['gold', 'customer', 'loyalty', 'restricted'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE marketing_analyst",
      "GRANT SELECT ON {{ this }} TO ROLE executive"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: MART_LOYALTY_ANALYSIS
-- ============================================================
-- Loyalty program performance and tier migration analysis.
-- Tracks customer progression through loyalty tiers.
-- ============================================================

WITH customer_base AS (
    SELECT * FROM {{ ref('mart_customer_360') }}
),

tier_stats AS (
    SELECT
        loyalty_tier,
        
        -- Counts
        COUNT(*) AS customer_count,
        COUNT(CASE WHEN total_deliveries > 0 THEN 1 END) AS active_customers,
        
        -- Revenue
        SUM(total_spent) AS total_revenue,
        ROUND(AVG(total_spent), 0) AS avg_revenue_per_customer,
        
        -- Orders
        SUM(total_deliveries) AS total_orders,
        ROUND(AVG(total_deliveries), 1) AS avg_orders_per_customer,
        
        -- Ratings
        ROUND(AVG(avg_rating_given), 2) AS avg_rating,
        
        -- Profitability
        SUM(total_profit_generated) AS total_profit,
        ROUND(AVG(total_profit_generated), 0) AS avg_profit_per_customer,
        
        -- Retention
        ROUND(AVG(customer_lifespan_days), 0) AS avg_lifespan_days,
        COUNT(CASE WHEN days_since_last_order <= 30 THEN 1 END) AS active_last_30d
        
    FROM customer_base
    GROUP BY loyalty_tier
),

tier_comparison AS (
    SELECT
        *,
        
        -- Percentage of total
        ROUND(customer_count * 100.0 / SUM(customer_count) OVER (), 1) AS customer_pct,
        ROUND(total_revenue * 100.0 / SUM(total_revenue) OVER (), 1) AS revenue_pct,
        ROUND(total_profit * 100.0 / SUM(total_profit) OVER (), 1) AS profit_pct,
        
        -- Per customer comparisons
        ROUND(avg_revenue_per_customer / NULLIF(
            AVG(avg_revenue_per_customer) OVER (), 0), 2
        ) AS revenue_index,
        
        -- Retention rate
        ROUND(active_last_30d * 100.0 / NULLIF(active_customers, 0), 1) AS retention_rate_30d,
        
        -- Tier rank
        CASE loyalty_tier
            WHEN 'Platinum' THEN 5
            WHEN 'Gold' THEN 4
            WHEN 'Silver' THEN 3
            WHEN 'Bronze' THEN 2
            ELSE 1
        END AS tier_rank
        
    FROM tier_stats
)

SELECT
    *,
    
    -- Tier health status
    CASE
        WHEN retention_rate_30d >= 80 THEN 'Excellent Retention'
        WHEN retention_rate_30d >= 60 THEN 'Good Retention'
        WHEN retention_rate_30d >= 40 THEN 'Moderate Retention'
        ELSE 'Poor Retention - Needs Attention'
    END AS retention_status,
    
    -- Revenue concentration (Pareto analysis)
    CASE
        WHEN revenue_pct >= 40 THEN 'Dominant Tier'
        WHEN revenue_pct >= 25 THEN 'Major Tier'
        WHEN revenue_pct >= 10 THEN 'Significant Tier'
        ELSE 'Minor Tier'
    END AS revenue_contribution,
    
    -- Tier migration recommendation
    CASE
        WHEN loyalty_tier = 'Platinum' THEN 'VIP Treatment - Exclusive Benefits'
        WHEN loyalty_tier = 'Gold' THEN 'Push to Platinum - Extra Incentives'
        WHEN loyalty_tier = 'Silver' THEN 'Encourage to Gold - Milestone Rewards'
        WHEN loyalty_tier = 'Bronze' THEN 'Onboard to Silver - Welcome Offers'
        ELSE 'Acquisition Focus - First Order Incentive'
    END AS tier_strategy,
    
    -- Avg orders to next tier
    CASE loyalty_tier
        WHEN 'New' THEN 5 - COALESCE(avg_orders_per_customer, 0)
        WHEN 'Bronze' THEN 10 - COALESCE(avg_orders_per_customer, 0)
        WHEN 'Silver' THEN 25 - COALESCE(avg_orders_per_customer, 0)
        WHEN 'Gold' THEN 50 - COALESCE(avg_orders_per_customer, 0)
        ELSE 0
    END AS orders_to_next_tier,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'mart_loyalty_analysis' AS dw_source

FROM tier_comparison
ORDER BY tier_rank DESC