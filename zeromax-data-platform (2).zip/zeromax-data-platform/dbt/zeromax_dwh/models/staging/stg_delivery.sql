{{
  config(
    materialized='incremental',
    unique_key='delivery_id',
    partition_by={
      "field": "order_datetime",
      "data_type": "timestamp",
      "granularity": "day"
    },
    cluster_by=['zone_id', 'date_key'],
    tags=['staging', 'silver', 'delivery'],
    on_schema_change='sync_all_columns'
  )
}}

-- ============================================================
-- STAGING: STG_DELIVERY
-- ============================================================
-- Bronze → Silver transformation for delivery data.
-- Performs:
--   1. Data type casting
--   2. Column renaming (source → standard)
--   3. Null handling
--   4. Basic data validation
--   5. Deduplication
-- ============================================================

WITH raw_delivery AS (
    SELECT *
    FROM {{ source('bronze', 'delivery_events') }}
    {% if is_incremental() %}
    WHERE order_datetime > (SELECT MAX(order_datetime) FROM {{ this }})
    {% endif %}
),

-- Deduplicate by delivery_id (keep latest)
deduped AS (
    SELECT *
    FROM raw_delivery
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY delivery_id 
        ORDER BY event_timestamp DESC
    ) = 1
),

-- Clean and transform
cleaned AS (
    SELECT
        -- Primary Key (Natural)
        delivery_id,
        order_id,
        
        -- Foreign Keys (Natural)
        driver_id,
        customer_id,
        restaurant_id,
        zone_id,
        
        -- Temporal
        CAST(order_datetime AS TIMESTAMP) AS order_datetime,
        CAST(order_date AS DATE) AS order_date,
        CAST(date_key AS INTEGER) AS date_key,
        CAST(time_key AS INTEGER) AS time_key,
        
        -- Coordinates
        CAST(cust_lat AS DECIMAL(10,6)) AS cust_lat,
        CAST(cust_lon AS DECIMAL(10,6)) AS cust_lon,
        CAST(rest_lat AS DECIMAL(10,6)) AS rest_lat,
        CAST(rest_lon AS DECIMAL(10,6)) AS rest_lon,
        
        -- Distance Metrics
        CAST(distance_km AS DECIMAL(8,2)) AS distance_km,
        CAST(optimal_distance_km AS DECIMAL(8,2)) AS optimal_distance_km,
        CAST(route_efficiency_pct AS DECIMAL(5,1)) AS route_efficiency_pct,
        
        -- Time Metrics (Minutes)
        CAST(preparation_time_min AS INTEGER) AS preparation_time_min,
        CAST(pickup_delay_min AS INTEGER) AS pickup_delay_min,
        CAST(travel_time_base_min AS INTEGER) AS travel_time_base_min,
        CAST(travel_time_actual_min AS INTEGER) AS travel_time_actual_min,
        CAST(delivery_duration_min AS INTEGER) AS delivery_duration_min,
        CAST(expected_duration_min AS INTEGER) AS expected_duration_min,
        CAST(promised_duration_min AS INTEGER) AS promised_duration_min,
        CAST(delay_min AS INTEGER) AS delay_min,
        
        -- Status & Quality
        delivery_status,
        delay_category,
        CAST(customer_rating AS DECIMAL(3,1)) AS customer_rating,
        
        -- Financials (PKR)
        CAST(delivery_fee_pkr AS INTEGER) AS delivery_fee_pkr,
        CAST(driver_cost_pkr AS INTEGER) AS driver_cost_pkr,
        CAST(platform_fee_pkr AS INTEGER) AS platform_fee_pkr,
        CAST(delay_penalty_pkr AS INTEGER) AS delay_penalty_pkr,
        CAST(profit_pkr AS INTEGER) AS profit_pkr,
        
        -- Dimension References
        CAST(weather_key AS INTEGER) AS weather_key,
        CAST(traffic_key AS INTEGER) AS traffic_key,
        CAST(vehicle_key AS INTEGER) AS vehicle_key,
        CAST(payment_key AS INTEGER) AS payment_key,
        CAST(cancel_key AS INTEGER) AS cancel_key,
        
        -- Denormalized Attributes
        customer_tenure_days,
        customer_loyalty_tier,
        experience_level,
        CAST(fatigue_factor AS DECIMAL(4,3)) AS fatigue_factor,
        
        -- Weather & Traffic Context
        CAST(weather_severity AS INTEGER) AS weather_severity,
        CAST(traffic_severity AS INTEGER) AS traffic_severity,
        weather_condition,
        traffic_level,
        CAST(traffic_delay_factor AS DECIMAL(4,2)) AS traffic_delay_factor,
        
        -- Temporal Flags
        CAST(is_ramadan AS BOOLEAN) AS is_ramadan,
        CAST(is_eid AS BOOLEAN) AS is_eid,
        CAST(is_eid_adha AS BOOLEAN) AS is_eid_adha,
        CAST(is_holiday AS BOOLEAN) AS is_holiday,
        CAST(is_peak_hour AS BOOLEAN) AS is_peak_hour,
        
        -- Restaurant
        restaurant_type,
        
        -- Metadata
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'stg_delivery' AS dw_source
        
    FROM deduped
),

-- Apply data quality filters
validated AS (
    SELECT *
    FROM cleaned
    WHERE delivery_id IS NOT NULL
      AND order_datetime IS NOT NULL
      -- Valid coordinate range (Karachi)
      AND cust_lat BETWEEN 24.7 AND 25.1
      AND cust_lon BETWEEN 66.8 AND 67.3
      -- Valid distance
      AND distance_km > 0
      AND distance_km <= 20
      -- Valid status
      AND delivery_status IN ('On-Time', 'Late', 'Failed')
      -- Valid rating (when present)
      AND (customer_rating IS NULL OR customer_rating BETWEEN 1.0 AND 5.0)
      -- Valid financials
      AND delivery_fee_pkr >= 0
      AND profit_pkr IS NOT NULL
)

SELECT * FROM validated