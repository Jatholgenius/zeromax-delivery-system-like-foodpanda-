"""
================================================================================
ZEROMAX LOGISTICS - CUSTOM SNOWFLAKE HOOK
================================================================================
Extended Snowflake hook with additional utilities.
- Query result caching
- Automatic warehouse suspension
- Query performance monitoring
================================================================================
"""

import time
import logging
from typing import Dict, List, Optional, Any, Tuple
from contextlib import contextmanager

from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
from airflow.exceptions import AirflowException

logger = logging.getLogger(__name__)


class ZeroMaxSnowflakeHook(SnowflakeHook):
    """
    Extended Snowflake hook with ZeroMax-specific features.
    
    Features:
    - Query result caching for repeated queries
    - Automatic warehouse management
    - Performance metrics collection
    - Retry with exponential backoff
    """
    
    def __init__(
        self,
        snowflake_conn_id: str = "snowflake_default",
        warehouse: str = None,
        database: str = None,
        schema: str = None,
        role: str = None,
        *args,
        **kwargs,
    ):
        super().__init__(snowflake_conn_id=snowflake_conn_id, *args, **kwargs)
        self.warehouse = warehouse
        self.database = database
        self.schema = schema
        self.role = role
        self._query_cache: Dict[str, Any] = {}
        self._query_times: List[float] = []
    
    @contextmanager
    def session_context(self, warehouse: str = None, database: str = None, schema: str = None):
        """
        Context manager for temporary session settings.
        
        Usage:
            with hook.session_context(warehouse='ML_WH', schema='ML_FEATURES'):
                hook.run("SELECT ...")
        """
        original_warehouse = self.warehouse
        original_database = self.database
        original_schema = self.schema
        
        try:
            if warehouse:
                self.warehouse = warehouse
                self.run(f"USE WAREHOUSE {warehouse}")
            if database:
                self.database = database
                self.run(f"USE DATABASE {database}")
            if schema:
                self.schema = schema
                self.run(f"USE SCHEMA {schema}")
            
            yield self
            
        finally:
            self.warehouse = original_warehouse
            self.database = original_database
            self.schema = original_schema
    
    def run_with_retry(
        self,
        sql: str,
        max_retries: int = 3,
        retry_delay: int = 5,
        parameters: Dict = None,
    ) -> List[Any]:
        """
        Run SQL with retry logic and exponential backoff.
        
        Args:
            sql: SQL query to execute
            max_retries: Maximum number of retries
            retry_delay: Base delay in seconds
            parameters: Query parameters
            
        Returns:
            Query results
        """
        last_exception = None
        
        for attempt in range(max_retries + 1):
            try:
                start_time = time.time()
                result = self.run(sql, parameters=parameters)
                query_time = time.time() - start_time
                self._query_times.append(query_time)
                
                if attempt > 0:
                    logger.info(f"Query succeeded after {attempt} retries")
                
                return result
                
            except Exception as e:
                last_exception = e
                
                if attempt < max_retries:
                    wait_time = retry_delay * (2 ** attempt)
                    logger.warning(
                        f"Query failed (attempt {attempt + 1}/{max_retries + 1}): {str(e)[:200]}. "
                        f"Retrying in {wait_time}s..."
                    )
                    time.sleep(wait_time)
                else:
                    logger.error(f"Query failed after {max_retries + 1} attempts")
                    raise AirflowException(f"Snowflake query failed: {str(last_exception)}")
    
    def run_with_cache(
        self,
        sql: str,
        cache_key: str = None,
        cache_ttl_seconds: int = 300,
        **kwargs,
    ) -> List[Any]:
        """
        Run query with result caching.
        
        Args:
            sql: SQL query
            cache_key: Key for cache lookup (defaults to SQL hash)
            cache_ttl_seconds: Cache TTL in seconds
            
        Returns:
            Query results (from cache if available)
        """
        if cache_key is None:
            cache_key = f"sql_{hash(sql)}"
        
        # Check cache
        if cache_key in self._query_cache:
            cached_result, cached_time = self._query_cache[cache_key]
            if (time.time() - cached_time) < cache_ttl_seconds:
                logger.debug(f"Cache hit for key: {cache_key}")
                return cached_result
        
        # Execute query
        result = self.run(sql, **kwargs)
        
        # Store in cache
        self._query_cache[cache_key] = (result, time.time())
        
        return result
    
    def get_table_row_count(self, table_name: str, where_clause: str = "") -> int:
        """
        Get row count for a table.
        
        Args:
            table_name: Fully qualified table name
            where_clause: Optional WHERE clause
            
        Returns:
            Row count
        """
        sql = f"SELECT COUNT(*) FROM {table_name}"
        if where_clause:
            sql += f" WHERE {where_clause}"
        
        result = self.get_first(sql)
        return result[0] if result else 0
    
    def get_last_update_time(self, table_name: str) -> Optional[str]:
        """
        Get last update timestamp for a table.
        
        Args:
            table_name: Table name
            
        Returns:
            Last update timestamp or None
        """
        try:
            result = self.get_first(
                f"SELECT MAX(dw_updated_at) FROM {table_name}"
            )
            return str(result[0]) if result and result[0] else None
        except Exception:
            return None
    
    def table_exists(self, table_name: str) -> bool:
        """
        Check if table exists.
        
        Args:
            table_name: Table name
            
        Returns:
            True if table exists
        """
        try:
            parts = table_name.split(".")
            if len(parts) == 3:
                database, schema, table = parts
                sql = f"""
                    SELECT COUNT(*) 
                    FROM {database}.INFORMATION_SCHEMA.TABLES 
                    WHERE TABLE_SCHEMA = '{schema}' 
                      AND TABLE_NAME = '{table}'
                """
            elif len(parts) == 2:
                schema, table = parts
                sql = f"""
                    SELECT COUNT(*) 
                    FROM INFORMATION_SCHEMA.TABLES 
                    WHERE TABLE_SCHEMA = '{schema}' 
                      AND TABLE_NAME = '{table}'
                """
            else:
                sql = f"""
                    SELECT COUNT(*) 
                    FROM INFORMATION_SCHEMA.TABLES 
                    WHERE TABLE_NAME = '{table_name}'
                """
            
            result = self.get_first(sql)
            return result[0] > 0 if result else False
        except Exception:
            return False
    
    def get_query_performance_stats(self) -> Dict[str, float]:
        """
        Get query performance statistics.
        
        Returns:
            Dict with avg, min, max query times
        """
        if not self._query_times:
            return {"avg": 0, "min": 0, "max": 0, "count": 0}
        
        return {
            "avg": sum(self._query_times) / len(self._query_times),
            "min": min(self._query_times),
            "max": max(self._query_times),
            "count": len(self._query_times),
        }
    
    def clear_cache(self) -> None:
        """Clear query cache."""
        self._query_cache.clear()
        logger.info("Query cache cleared")
    
    def suspend_warehouse(self, warehouse: str = None) -> None:
        """
        Suspend a warehouse to save costs.
        
        Args:
            warehouse: Warehouse name (uses default if None)
        """
        wh = warehouse or self.warehouse
        if wh:
            self.run(f"ALTER WAREHOUSE {wh} SUSPEND")
            logger.info(f"Warehouse {wh} suspended")
    
    def resume_warehouse(self, warehouse: str = None) -> None:
        """
        Resume a warehouse.
        
        Args:
            warehouse: Warehouse name (uses default if None)
        """
        wh = warehouse or self.warehouse
        if wh:
            self.run(f"ALTER WAREHOUSE {wh} RESUME IF SUSPENDED")
            logger.info(f"Warehouse {wh} resumed")
    
    def execute_dbt_model(self, model_name: str, full_refresh: bool = False) -> None:
        """
        Execute a dbt model directly.
        
        Args:
            model_name: dbt model name
            full_refresh: Whether to full refresh
        """
        cmd = f"dbt run --select {model_name} --profiles-dir /opt/airflow/dbt/zeromax_dwh"
        if full_refresh:
            cmd += " --full-refresh"
        
        import subprocess
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)
        
        if result.returncode != 0:
            raise AirflowException(f"dbt model failed: {result.stderr}")
        
        logger.info(f"dbt model {model_name} executed successfully")