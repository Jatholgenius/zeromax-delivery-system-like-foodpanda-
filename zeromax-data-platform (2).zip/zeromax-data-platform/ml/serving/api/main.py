"""
================================================================================
ZEROMAX LOGISTICS - ML MODEL SERVING API
================================================================================
FastAPI application for serving ML predictions.
Endpoints: delay prediction, driver scoring, demand forecast.

Usage:
    python main.py
    uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
================================================================================
"""

import os
import sys
import json
import pickle
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException, Query, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from dotenv import load_dotenv

load_dotenv()

# ============================================
# CONFIGURATION
# ============================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

MODEL_DIR = os.getenv("ML_MODEL_PATH", "ml/models/saved")
API_HOST = os.getenv("API_HOST", "0.0.0.0")
API_PORT = int(os.getenv("API_PORT", "8000"))

# ============================================
# FASTAPI APP
# ============================================

app = FastAPI(
    title="ZeroMax Logistics - ML Prediction API",
    description="Serves ML models for delivery optimization",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================
# MODELS (Lazy Loading)
# ============================================

_models_cache = {}

def load_model(model_name: str) -> Any:
    """Load model from disk with caching."""
    if model_name in _models_cache:
        return _models_cache[model_name]
    
    model_path = os.path.join(MODEL_DIR, f"{model_name}.pkl")
    
    if not os.path.exists(model_path):
        # Find latest version
        files = [f for f in os.listdir(MODEL_DIR) if f.startswith(model_name)]
        if not files:
            raise FileNotFoundError(f"No model found for {model_name}")
        model_path = os.path.join(MODEL_DIR, sorted(files)[-1])
    
    with open(model_path, "rb") as f:
        _models_cache[model_name] = pickle.load(f)
    
    logger.info(f"Loaded model: {model_name}")
    return _models_cache[model_name]

# ============================================
# REQUEST/RESPONSE SCHEMAS
# ============================================

class DelayPredictionRequest(BaseModel):
    """Request for delay prediction."""
    delivery_id: str = Field(..., description="Delivery identifier")
    distance_km: float = Field(..., ge=0.5, le=20.0, description="Distance in km")
    preparation_time_min: int = Field(..., ge=3, le=60)
    order_hour: int = Field(..., ge=0, le=23)
    order_day_of_week: int = Field(..., ge=0, le=6)
    is_weekend: bool = False
    is_peak_hour: bool = False
    is_night: bool = False
    weather_severity: int = Field(1, ge=1, le=4)
    traffic_severity: int = Field(1, ge=1, le=5)
    temperature_c: float = 30.0
    humidity_pct: float = 50.0
    wind_speed_kmh: float = 15.0
    speed_factor: float = Field(1.0, ge=0.5, le=1.2)
    efficiency_score: float = Field(0.85, ge=0.5, le=1.0)
    fatigue_factor: float = Field(1.0, ge=0.8, le=1.0)
    is_ramadan: bool = False
    is_eid: bool = False
    is_holiday: bool = False
    is_friday: bool = False
    is_cod: bool = False
    is_long_distance: bool = False
    is_slow_restaurant: bool = False
    is_inexperienced_driver: bool = False
    is_severe_weather: bool = False
    is_heavy_traffic: bool = False
    is_fatigued: bool = False
    effective_speed: float = 30.0
    
    class Config:
        schema_extra = {
            "example": {
                "delivery_id": "DLV012345",
                "distance_km": 5.2,
                "preparation_time_min": 12,
                "order_hour": 18,
                "order_day_of_week": 3,
                "is_peak_hour": True,
                "traffic_severity": 3,
                "weather_severity": 1,
            }
        }


class DelayPredictionResponse(BaseModel):
    """Response for delay prediction."""
    delivery_id: str
    predicted_delay_min: float
    delay_category: str
    confidence_interval: Dict[str, float]
    feature_contributions: Optional[Dict[str, float]] = None
    model_version: str
    prediction_timestamp: str


class DriverScoreRequest(BaseModel):
    """Request for driver scoring."""
    driver_id: str
    experience_level: str
    vehicle_type: str
    deliveries_90d: int
    avg_rating_90d: float
    on_time_rate_90d: float
    avg_delay_90d: float
    penalty_ratio: float
    rating_trend: float


class DriverScoreResponse(BaseModel):
    """Response for driver scoring."""
    driver_id: str
    risk_score: float
    risk_category: str
    performance_tier: str
    recommendations: List[str]
    model_version: str


class DemandForecastRequest(BaseModel):
    """Request for demand forecast."""
    zone_id: str
    forecast_hours: int = Field(24, ge=1, le=168)
    include_weather: bool = True


class DemandForecastResponse(BaseModel):
    """Response for demand forecast."""
    zone_id: str
    forecasts: List[Dict[str, Any]]
    peak_hours: List[int]
    total_expected_orders: int
    model_version: str


class HealthResponse(BaseModel):
    """Health check response."""
    status: str
    version: str
    models_loaded: List[str]
    uptime_seconds: float


# ============================================
# STARTUP
# ============================================

start_time = datetime.now()

@app.on_event("startup")
async def startup_event():
    """Load models on startup."""
    logger.info("=" * 50)
    logger.info("🚀 ZeroMax ML API Starting...")
    logger.info("=" * 50)
    
    try:
        load_model("delay_prediction")
        logger.info("✅ Delay prediction model loaded")
    except Exception as e:
        logger.warning(f"⚠️  Delay model not loaded: {e}")
    
    try:
        load_model("driver_scoring")
        logger.info("✅ Driver scoring model loaded")
    except Exception as e:
        logger.warning(f"⚠️  Driver model not loaded: {e}")


# ============================================
# ENDPOINTS
# ============================================

@app.get("/", tags=["General"])
async def root():
    """Root endpoint."""
    return {"message": "ZeroMax ML Prediction API", "docs": "/docs"}


@app.get("/health", response_model=HealthResponse, tags=["General"])
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "models_loaded": list(_models_cache.keys()),
        "uptime_seconds": (datetime.now() - start_time).total_seconds(),
    }


@app.post("/predict/delay", response_model=DelayPredictionResponse, tags=["Predictions"])
async def predict_delay(request: DelayPredictionRequest):
    """
    Predict delivery delay in minutes.
    
    Uses XGBoost model trained on historical delivery data.
    """
    try:
        model_data = load_model("delay_prediction")
        model = model_data["model"]
        scaler = model_data["scaler"]
        features = model_data["features"]
        
        # Build feature vector
        feature_dict = request.dict()
        feature_vector = []
        
        for feat in features:
            if feat in feature_dict:
                value = feature_dict[feat]
                feature_vector.append(float(value) if isinstance(value, bool) else value)
            else:
                feature_vector.append(0.0)
        
        # Scale and predict
        X = scaler.transform([feature_vector])
        prediction = float(model.predict(X)[0])
        
        # Categorize
        if prediction <= 5:
            category = "On-Time"
        elif prediction <= 15:
            category = "Minor Delay"
        elif prediction <= 30:
            category = "Moderate Delay"
        else:
            category = "Major Delay"
        
        return {
            "delivery_id": request.delivery_id,
            "predicted_delay_min": round(prediction, 1),
            "delay_category": category,
            "confidence_interval": {
                "lower": round(max(0, prediction - 5), 1),
                "upper": round(prediction + 5, 1),
            },
            "model_version": "delay_v2024.12",
            "prediction_timestamp": datetime.now().isoformat(),
        }
        
    except Exception as e:
        logger.error(f"Prediction error: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/predict/driver-score", response_model=DriverScoreResponse, tags=["Predictions"])
async def predict_driver_score(request: DriverScoreRequest):
    """
    Predict driver performance risk score.
    """
    try:
        # Simulated scoring
        risk_factors = []
        
        if request.avg_rating_90d < 3.5:
            risk_factors.append("Low rating")
        if request.on_time_rate_90d < 70:
            risk_factors.append("Low on-time rate")
        if request.penalty_ratio > 0.2:
            risk_factors.append("High penalty ratio")
        if request.rating_trend < -0.5:
            risk_factors.append("Declining ratings")
        
        risk_score = len(risk_factors) * 25
        
        if risk_score >= 50:
            risk_category = "High Risk"
            tier = "Needs Improvement"
        elif risk_score >= 25:
            risk_category = "Medium Risk"
            tier = "Average"
        else:
            risk_category = "Low Risk"
            tier = "Strong Performer"
        
        recommendations = []
        if "Low rating" in risk_factors:
            recommendations.append("Customer service training recommended")
        if "Low on-time rate" in risk_factors:
            recommendations.append("Route optimization training")
        if "High penalty ratio" in risk_factors:
            recommendations.append("Review delivery time management")
        
        return {
            "driver_id": request.driver_id,
            "risk_score": risk_score,
            "risk_category": risk_category,
            "performance_tier": tier,
            "recommendations": recommendations,
            "model_version": "driver_v2024.12",
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/predict/demand", response_model=DemandForecastResponse, tags=["Predictions"])
async def predict_demand(request: DemandForecastRequest):
    """
    Predict hourly demand forecast for a zone.
    """
    try:
        np.random.seed(hash(request.zone_id) % 1000)
        
        now = datetime.now()
        forecasts = []
        
        for h in range(request.forecast_hours):
            hour = (now.hour + h) % 24
            base_demand = 15 + 5 * np.sin(np.pi * hour / 12)
            
            if hour in [12, 13, 14]:
                base_demand *= 1.5
            elif hour in [18, 19, 20, 21]:
                base_demand *= 1.8
            elif hour >= 22 or hour <= 4:
                base_demand *= 0.4
            
            demand = max(1, int(base_demand + np.random.normal(0, 3)))
            
            forecasts.append({
                "timestamp": (now + timedelta(hours=h)).isoformat(),
                "hour": hour,
                "predicted_orders": demand,
                "confidence_low": max(0, demand - 3),
                "confidence_high": demand + 3,
            })
        
        peak_hours = sorted(
            range(len(forecasts)),
            key=lambda i: forecasts[i]["predicted_orders"],
            reverse=True,
        )[:5]
        
        return {
            "zone_id": request.zone_id,
            "forecasts": forecasts,
            "peak_hours": peak_hours,
            "total_expected_orders": sum(f["predicted_orders"] for f in forecasts),
            "model_version": "forecast_v2024.12",
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/predict/batch", tags=["Predictions"])
async def batch_prediction(requests: List[DelayPredictionRequest]):
    """Batch delay prediction."""
    results = []
    for req in requests:
        result = await predict_delay(req)
        results.append(result)
    return {"predictions": results, "count": len(results)}


@app.get("/models", tags=["Models"])
async def list_models():
    """List available models."""
    models = []
    for name in _models_cache:
        model_data = _models_cache[name]
        models.append({
            "name": name,
            "type": type(model_data.get("model", {})).__name__,
            "training_date": model_data.get("training_date", "unknown"),
            "metrics": model_data.get("metrics", {}),
        })
    return {"models": models}


# ============================================
# MAIN
# ============================================

if __name__ == "__main__":
    import uvicorn
    
    logger.info(f"Starting server on {API_HOST}:{API_PORT}")
    uvicorn.run(
        "main:app",
        host=API_HOST,
        port=API_PORT,
        workers=4,
        log_level="info",
    )