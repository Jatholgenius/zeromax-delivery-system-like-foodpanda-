{#
-- ============================================================
-- SCD TYPE 2 MACRO - Slowly Changing Dimension Type 2
-- ============================================================
-- Tracks historical changes by creating new rows with validity periods.
-- Each change creates a new version while preserving history.
-- 
-- Parameters:
--   source_table      - Source table/view to track changes from
--   natural_key       - Business key column (e.g., driver_id)
--   track_columns     - List of columns to track for changes
--   surrogate_key     - Surrogate key column name (default: sk)
--   valid_from        - Column for row effective start date
--   valid_to          - Column for row effective end date
--   is_current        - Boolean flag for current record
-- ============================================================
#}

{% macro scd_type2(
    source_table,
    natural_key,
    track_columns,
    surrogate_key='surrogate_key',
    valid_from='valid_from',
    valid_to='valid_to',
    is_current='is_current',
    high_date='9999-12-31'
) %}

-- Step 1: Get current data with hash for change detection
WITH current_source AS (
    SELECT 
        *,
        -- Generate hash of tracked columns for change detection
        MD5(
            CONCAT_WS('|',
                {% for col in track_columns %}
                    COALESCE(CAST({{ col }} AS VARCHAR), '##NULL##')
                    {% if not loop.last %}, {% endif %}
                {% endfor %}
            )
        ) AS row_hash,
        CURRENT_TIMESTAMP() AS detected_at
    FROM {{ source_table }}
    WHERE {{ natural_key }} IS NOT NULL
),

-- Step 2: Get existing records from target
existing_dim AS (
    SELECT 
        {{ surrogate_key }},
        {{ natural_key }},
        row_hash,
        {{ valid_from }},
        {{ valid_to }},
        {{ is_current }}
    FROM {{ this }}
    WHERE {{ is_current }} = TRUE
),

-- Step 3: Identify new records (not in dimension yet)
new_records AS (
    SELECT 
        cs.*,
        'INSERT' AS dml_type,
        NULL AS existing_sk
    FROM current_source cs
    LEFT JOIN existing_dim ed 
        ON cs.{{ natural_key }} = ed.{{ natural_key }}
    WHERE ed.{{ natural_key }} IS NULL
),

-- Step 4: Identify changed records (hash doesn't match)
changed_records AS (
    SELECT 
        cs.*,
        'UPDATE' AS dml_type,
        ed.{{ surrogate_key }} AS existing_sk
    FROM current_source cs
    INNER JOIN existing_dim ed 
        ON cs.{{ natural_key }} = ed.{{ natural_key }}
    WHERE cs.row_hash != ed.row_hash
),

-- Step 5: Identify unchanged records (skip these)
unchanged_records AS (
    SELECT 
        cs.{{ natural_key }},
        'SKIP' AS dml_type,
        ed.{{ surrogate_key }} AS existing_sk
    FROM current_source cs
    INNER JOIN existing_dim ed 
        ON cs.{{ natural_key }} = ed.{{ natural_key }}
    WHERE cs.row_hash = ed.row_hash
),

-- Step 6: Combine new and changed records
upsert_records AS (
    SELECT * FROM new_records
    UNION ALL
    SELECT * FROM changed_records
),

-- Step 7: Generate surrogate keys for new records
final_records AS (
    SELECT
        -- Generate new surrogate key for INSERTs, use existing for UPDATEs
        CASE 
            WHEN dml_type = 'INSERT' THEN 
                {{ dbt_utils.generate_surrogate_key([natural_key, 'detected_at']) }}
            ELSE 
                existing_sk
        END AS {{ surrogate_key }},
        
        -- Business key
        {{ natural_key }},
        
        -- Tracked columns from source
        {% for col in track_columns %}
            {{ col }},
        {% endfor %}
        
        -- Change detection
        row_hash,
        
        -- Validity period
        CURRENT_TIMESTAMP() AS {{ valid_from }},
        TO_TIMESTAMP('{{ high_date }}', 'YYYY-MM-DD') AS {{ valid_to }},
        TRUE AS {{ is_current }},
        
        -- Metadata
        dml_type AS change_type,
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'dbt_scd_type2_macro' AS dw_source
        
    FROM upsert_records
)

-- Step 8: Insert new versions
SELECT * FROM final_records

{% endmacro %}


{#
-- ============================================================
-- SCD TYPE 2 UPDATE HELPER
-- ============================================================
-- Expires old records when new versions are inserted.
-- Run this BEFORE inserting new records.
-- ============================================================
#}

{% macro scd_type2_expire_old(
    target_table,
    natural_key,
    valid_to='valid_to',
    is_current='is_current'
) %}

-- Expire old records that have new versions
UPDATE {{ target_table }}
SET 
    {{ valid_to }} = CURRENT_TIMESTAMP(),
    {{ is_current }} = FALSE,
    dw_updated_at = CURRENT_TIMESTAMP()
WHERE {{ natural_key }} IN (
    SELECT DISTINCT cs.{{ natural_key }}
    FROM {{ ref('stg_new_data') }} cs
    INNER JOIN {{ target_table }} ed 
        ON cs.{{ natural_key }} = ed.{{ natural_key }}
    WHERE ed.{{ is_current }} = TRUE
      AND MD5(CONCAT_WS('|', 
            {% for col in var('track_columns', []) %}
                COALESCE(CAST(cs.{{ col }} AS VARCHAR), '##NULL##')
                {% if not loop.last %}, {% endif %}
            {% endfor %}
          )) != ed.row_hash
)
AND {{ is_current }} = TRUE;

{% endmacro %}


{#
-- ============================================================
-- SCD TYPE 2 VALIDATOR
-- ============================================================
-- Validates SCD Type 2 integrity after updates.
-- ============================================================
#}

{% macro validate_scd_type2(table_name, natural_key) %}

-- Check 1: No overlapping validity periods for same natural key
SELECT 
    'OVERLAPPING_PERIODS' AS validation_check,
    COUNT(*) AS violation_count
FROM {{ table_name }} a
INNER JOIN {{ table_name }} b
    ON a.{{ natural_key }} = b.{{ natural_key }}
    AND a.{{ surrogate_key }} != b.{{ surrogate_key }}
    AND a.valid_from < b.valid_to
    AND b.valid_from < a.valid_to
HAVING COUNT(*) > 0

UNION ALL

-- Check 2: No gaps in validity periods
SELECT 
    'VALIDITY_GAPS' AS validation_check,
    COUNT(*) AS violation_count
FROM (
    SELECT 
        {{ natural_key }},
        valid_to AS gap_start,
        LEAD(valid_from) OVER (
            PARTITION BY {{ natural_key }} 
            ORDER BY valid_from
        ) AS next_valid_from
    FROM {{ table_name }}
) gaps
WHERE gap_start < next_valid_from
  AND gap_start != TO_TIMESTAMP('9999-12-31', 'YYYY-MM-DD')
HAVING COUNT(*) > 0

UNION ALL

-- Check 3: Only one current record per natural key
SELECT 
    'MULTIPLE_CURRENT_RECORDS' AS validation_check,
    COUNT(*) AS violation_count
FROM {{ table_name }}
WHERE is_current = TRUE
GROUP BY {{ natural_key }}
HAVING COUNT(*) > 1

UNION ALL

-- Check 4: valid_from is before valid_to
SELECT 
    'INVALID_DATE_RANGE' AS validation_check,
    COUNT(*) AS violation_count
FROM {{ table_name }}
WHERE valid_from >= valid_to
HAVING COUNT(*) > 0;

{% endmacro %}