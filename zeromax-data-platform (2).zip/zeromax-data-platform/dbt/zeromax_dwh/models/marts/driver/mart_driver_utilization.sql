{{
  config(
    materialized='table',
    cluster_by=['driver_sk', 'activity_date'],
    tags=['gold', 'driver', 'utilization', 'operations'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE operations_manager",
      "GRANT SELECT ON {{ this }} TO ROLE executive"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: MART_DRIVER_UTILIZATION
-- ============================================================
-- Driver utilization and shift efficiency analysis.
-- Identifies overworked/underutilized drivers.
-- Granularity: Driver per day.
-- ============================================================

WITH daily_driver_stats AS (
    SELECT
        fd.driver_sk,
        fd.date_key,
        dd.full_date AS activity_date,
        dd.is_weekend,
        dd.is_ramadan,
        
        -- Delivery counts
        COUNT(DISTINCT fd.delivery_sk) AS deliveries_today,
        
        -- Hours active (first to last delivery)
        DATEDIFF('hour', 
            MIN(fd.order_datetime), 
            MAX(fd.order_datetime)
        ) AS hours_active,
        
        -- Distance
        SUM(fd.distance_km) AS total_distance_km,
        
        -- Time metrics
        ROUND(AVG(fd.delivery_duration_min), 1) AS avg_delivery_time_min,
        SUM(fd.delivery_duration_min) AS total_delivery_time_min,
        
        -- Revenue
        SUM(fd.delivery_fee_pkr) AS total_revenue,
        SUM(fd.profit_pkr) AS total_profit,
        
        -- Peak work
        COUNT(CASE WHEN fd.is_peak_hour THEN 1 END) AS peak_deliveries,
        COUNT(CASE WHEN fd.is_night THEN 1 END) AS night_deliveries,
        
        -- Ratings
        ROUND(AVG(fd.customer_rating), 2) AS avg_rating_today,
        
        -- Fatigue indicator
        MAX(fd.deliveries_so_far_today) AS max_concurrent_deliveries,
        
        -- Metadata
        MAX(fd.order_datetime) AS last_delivery_time
        
    FROM {{ ref('fct_delivery') }} fd
    INNER JOIN {{ ref('dim_date') }} dd ON fd.date_key = dd.date_sk
    WHERE fd.order_datetime >= DATEADD(month, -2, CURRENT_DATE())
    GROUP BY fd.driver_sk, fd.date_key, dd.full_date, dd.is_weekend, dd.is_ramadan
),

driver_info AS (
    SELECT
        driver_sk,
        driver_id,
        driver_name,
        experience_level,
        vehicle_type,
        home_zone,
        shift_start_hour,
        shift_end_hour,
        status
    FROM {{ ref('dim_driver_scd2') }}
    WHERE is_current = TRUE
)

SELECT
    di.driver_sk,
    di.driver_id,
    di.driver_name,
    di.experience_level,
    di.vehicle_type,
    di.home_zone,
    di.shift_start_hour,
    di.shift_end_hour,
    di.status,
    
    ds.activity_date,
    ds.is_weekend,
    ds.is_ramadan,
    
    -- Delivery metrics
    ds.deliveries_today,
    ds.hours_active,
    ds.total_distance_km,
    ds.total_delivery_time_min,
    
    -- Calculated utilization
    ROUND(ds.deliveries_today * 1.0 / NULLIF(ds.hours_active, 0), 1) AS deliveries_per_hour,
    ROUND(ds.total_delivery_time_min * 100.0 / NULLIF(ds.hours_active * 60, 0), 1) AS utilization_pct,
    ROUND(ds.total_distance_km * 1.0 / NULLIF(ds.hours_active, 0), 1) AS km_per_hour,
    
    -- Revenue metrics
    ds.total_revenue,
    ds.total_profit,
    ROUND(ds.total_revenue * 1.0 / NULLIF(ds.hours_active, 0), 0) AS revenue_per_hour,
    ROUND(ds.total_profit * 1.0 / NULLIF(ds.hours_active, 0), 0) AS profit_per_hour,
    
    -- Quality
    ds.avg_rating_today,
    ds.peak_deliveries,
    ds.night_deliveries,
    ds.max_concurrent_deliveries,
    ds.last_delivery_time,
    
    -- Shift compliance
    CASE
        WHEN EXTRACT(HOUR FROM ds.last_delivery_time) > di.shift_end_hour THEN 'Overtime'
        WHEN ds.hours_active < (di.shift_end_hour - di.shift_start_hour) * 0.5 THEN 'Underutilized'
        ELSE 'Normal'
    END AS shift_compliance,
    
    -- Fatigue risk
    CASE
        WHEN ds.max_concurrent_deliveries > 12 THEN 'High Fatigue Risk'
        WHEN ds.max_concurrent_deliveries > 8 THEN 'Moderate Fatigue'
        WHEN ds.max_concurrent_deliveries > 5 THEN 'Normal'
        ELSE 'Low Activity'
    END AS fatigue_risk,
    
    -- Efficiency tier for the day
    CASE
        WHEN deliveries_per_hour >= 3 AND avg_rating_today >= 4.5 THEN 'Excellent'
        WHEN deliveries_per_hour >= 2 AND avg_rating_today >= 4.0 THEN 'Good'
        WHEN deliveries_per_hour >= 1.5 THEN 'Average'
        WHEN deliveries_per_hour > 0 THEN 'Below Average'
        ELSE 'No Activity'
    END AS daily_efficiency_tier,
    
    -- Peak hour ratio
    ROUND(ds.peak_deliveries * 100.0 / NULLIF(ds.deliveries_today, 0), 1) AS peak_hour_ratio_pct,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'mart_driver_utilization' AS dw_source

FROM driver_info di
LEFT JOIN daily_driver_stats ds ON di.driver_sk = ds.driver_sk

WHERE ds.activity_date IS NOT NULL
ORDER BY ds.activity_date DESC, ds.deliveries_today DESC