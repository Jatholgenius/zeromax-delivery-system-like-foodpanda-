"""
================================================================================
ZEROMAX LOGISTICS - DELAY PREDICTION MODEL TRAINING
================================================================================
Trains XGBoost model to predict delivery delays.
Features: Temporal, distance, weather, traffic, driver, restaurant

Usage:
    python train.py
    python train.py --model xgboost --tune-hyperparams
    python train.py --export-onnx
================================================================================
"""

import os
import sys
import json
import logging
import pickle
from datetime import datetime
from typing import Dict, Tuple, Optional

import numpy as np
import pandas as pd
from dotenv import load_dotenv

# ML Libraries
from sklearn.model_selection import train_test_split, GridSearchCV, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (
    mean_squared_error, mean_absolute_error, r2_score,
    classification_report, confusion_matrix,
)
import xgboost as xgb
import mlflow
import mlflow.xgboost
import warnings
warnings.filterwarnings("ignore")

load_dotenv()

# ============================================
# CONFIGURATION
# ============================================

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

MLFLOW_TRACKING_URI = os.getenv("MLFLOW_TRACKING_URI", "http://localhost:5000")
EXPERIMENT_NAME = "zeromax-delay-prediction"
MODEL_DIR = os.getenv("ML_MODEL_PATH", "ml/models/saved")

# Features for training
FEATURE_COLUMNS = [
    "distance_km",
    "optimal_distance_km",
    "route_efficiency_pct",
    "preparation_time_min",
    "order_hour",
    "order_day_of_week",
    "is_weekend",
    "is_peak_hour",
    "is_night",
    "weather_severity",
    "traffic_severity",
    "severity_index",
    "temperature_c",
    "humidity_pct",
    "wind_speed_kmh",
    "speed_factor",
    "efficiency_score",
    "fatigue_factor",
    "is_ramadan",
    "is_eid",
    "is_holiday",
    "is_friday",
    "is_cod",
    "is_long_distance",
    "is_slow_restaurant",
    "is_inexperienced_driver",
    "is_severe_weather",
    "is_heavy_traffic",
    "is_fatigued",
    "effective_speed",
]

TARGET_COLUMN = "target_delay_min"


class DelayPredictionModel:
    """
    Delivery delay prediction model using XGBoost.
    """
    
    def __init__(self):
        self.model = None
        self.scaler = StandardScaler()
        self.feature_columns = FEATURE_COLUMNS
        self.target_column = TARGET_COLUMN
        self.label_encoders = {}
        self.metrics = {}
        self.training_date = datetime.now().isoformat()
    
    def load_data(self, query: str = None) -> pd.DataFrame:
        """
        Load training data from feature store.
        
        Args:
            query: SQL query to fetch data (uses default if None)
            
        Returns:
            DataFrame with features and target
        """
        logger.info("Loading training data...")
        
        # Try loading from Snowflake
        try:
            import snowflake.connector
            
            conn = snowflake.connector.connect(
                account=os.getenv("SNOWFLAKE_ACCOUNT"),
                user=os.getenv("SNOWFLAKE_USER"),
                password=os.getenv("SNOWFLAKE_PASSWORD"),
                warehouse="ML_WH",
                database="ZEROMAX_DWH_PROD",
                schema="ML_TRAINING",
            )
            
            if query is None:
                query = "SELECT * FROM ML_TRAINING.delay_prediction_data"
            
            df = pd.read_sql(query, conn)
            conn.close()
            
            logger.info(f"Loaded {len(df):,} rows from Snowflake")
            
        except Exception as e:
            logger.warning(f"Snowflake load failed: {e}. Using simulated data.")
            df = self._generate_simulated_data()
        
        return df
    
    def _generate_simulated_data(self, n_samples: int = 10000) -> pd.DataFrame:
        """Generate simulated training data for development."""
        np.random.seed(42)
        
        data = {
            "distance_km": np.random.uniform(0.5, 15, n_samples),
            "optimal_distance_km": np.random.uniform(0.5, 14, n_samples),
            "route_efficiency_pct": np.random.uniform(60, 100, n_samples),
            "preparation_time_min": np.random.randint(3, 30, n_samples),
            "order_hour": np.random.randint(0, 24, n_samples),
            "order_day_of_week": np.random.randint(0, 7, n_samples),
            "is_weekend": np.random.choice([0, 1], n_samples, p=[0.7, 0.3]),
            "is_peak_hour": np.random.choice([0, 1], n_samples, p=[0.6, 0.4]),
            "is_night": np.random.choice([0, 1], n_samples, p=[0.8, 0.2]),
            "weather_severity": np.random.choice([1, 2, 3, 4], n_samples, p=[0.4, 0.3, 0.2, 0.1]),
            "traffic_severity": np.random.choice([1, 2, 3, 4, 5], n_samples, p=[0.2, 0.25, 0.25, 0.2, 0.1]),
            "severity_index": np.random.randint(1, 20, n_samples),
            "temperature_c": np.random.uniform(15, 42, n_samples),
            "humidity_pct": np.random.uniform(20, 90, n_samples),
            "wind_speed_kmh": np.random.uniform(5, 50, n_samples),
            "speed_factor": np.random.uniform(0.7, 1.1, n_samples),
            "efficiency_score": np.random.uniform(0.6, 1.0, n_samples),
            "fatigue_factor": np.random.uniform(0.9, 1.0, n_samples),
            "is_ramadan": np.random.choice([0, 1], n_samples, p=[0.9, 0.1]),
            "is_eid": np.random.choice([0, 1], n_samples, p=[0.95, 0.05]),
            "is_holiday": np.random.choice([0, 1], n_samples, p=[0.85, 0.15]),
            "is_friday": np.random.choice([0, 1], n_samples, p=[0.85, 0.15]),
            "is_cod": np.random.choice([0, 1], n_samples, p=[0.6, 0.4]),
            "is_long_distance": np.random.choice([0, 1], n_samples, p=[0.7, 0.3]),
            "is_slow_restaurant": np.random.choice([0, 1], n_samples, p=[0.8, 0.2]),
            "is_inexperienced_driver": np.random.choice([0, 1], n_samples, p=[0.75, 0.25]),
            "is_severe_weather": np.random.choice([0, 1], n_samples, p=[0.85, 0.15]),
            "is_heavy_traffic": np.random.choice([0, 1], n_samples, p=[0.65, 0.35]),
            "is_fatigued": np.random.choice([0, 1], n_samples, p=[0.9, 0.1]),
            "effective_speed": np.random.uniform(10, 50, n_samples),
        }
        
        df = pd.DataFrame(data)
        
        # Generate target: delay in minutes
        base_delay = 2
        delay = (
            base_delay +
            df["distance_km"] * 1.5 +
            df["preparation_time_min"] * 0.3 +
            df["is_peak_hour"] * 5 +
            df["is_heavy_traffic"] * 8 +
            df["is_severe_weather"] * 7 +
            df["is_fatigued"] * 3 +
            df["is_inexperienced_driver"] * 4 +
            df["is_long_distance"] * 3 +
            np.random.normal(0, 3, n_samples)
        )
        
        df[TARGET_COLUMN] = np.maximum(0, delay).round(1)
        
        return df
    
    def preprocess(self, df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        Preprocess data for training.
        
        Args:
            df: Raw DataFrame
            
        Returns:
            X (features), y (target)
        """
        logger.info("Preprocessing data...")
        
        # Handle missing values
        df = df.fillna(0)
        
        # Ensure all feature columns exist
        available_features = [col for col in self.feature_columns if col in df.columns]
        if len(available_features) < len(self.feature_columns):
            missing = set(self.feature_columns) - set(available_features)
            logger.warning(f"Missing features: {missing}")
        
        X = df[available_features].values
        y = df[self.target_column].values
        
        # Scale features
        X = self.scaler.fit_transform(X)
        
        logger.info(f"Features shape: {X.shape}, Target shape: {y.shape}")
        
        return X, y
    
    def train(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_val: np.ndarray = None,
        y_val: np.ndarray = None,
        tune_hyperparams: bool = False,
    ) -> Dict:
        """
        Train XGBoost model.
        
        Args:
            X_train: Training features
            y_train: Training target
            X_val: Validation features
            y_val: Validation target
            tune_hyperparams: Whether to perform hyperparameter tuning
            
        Returns:
            Dictionary of training metrics
        """
        logger.info("Training XGBoost model...")
        
        if tune_hyperparams:
            params = self._tune_hyperparameters(X_train, y_train)
        else:
            params = {
                "n_estimators": 200,
                "max_depth": 7,
                "learning_rate": 0.05,
                "subsample": 0.8,
                "colsample_bytree": 0.8,
                "min_child_weight": 3,
                "reg_alpha": 0.1,
                "reg_lambda": 1.0,
                "random_state": 42,
                "n_jobs": -1,
            }
        
        # Create and train model
        self.model = xgb.XGBRegressor(**params)
        
        eval_set = [(X_train, y_train)]
        if X_val is not None and y_val is not None:
            eval_set.append((X_val, y_val))
        
        self.model.fit(
            X_train, y_train,
            eval_set=eval_set,
            verbose=False,
        )
        
        # Calculate metrics
        y_pred_train = self.model.predict(X_train)
        
        self.metrics = {
            "rmse": np.sqrt(mean_squared_error(y_train, y_pred_train)),
            "mae": mean_absolute_error(y_train, y_pred_train),
            "r2_score": r2_score(y_train, y_pred_train),
        }
        
        if X_val is not None and y_val is not None:
            y_pred_val = self.model.predict(X_val)
            self.metrics["val_rmse"] = np.sqrt(mean_squared_error(y_val, y_pred_val))
            self.metrics["val_mae"] = mean_absolute_error(y_val, y_pred_val)
            self.metrics["val_r2"] = r2_score(y_val, y_pred_val)
        
        # Feature importance
        self.metrics["feature_importance"] = dict(
            sorted(
                zip(self.feature_columns[:X_train.shape[1]], 
                    self.model.feature_importances_),
                key=lambda x: x[1],
                reverse=True,
            )[:10]
        )
        
        logger.info(f"Training complete: RMSE={self.metrics['rmse']:.2f}")
        
        return self.metrics
    
    def _tune_hyperparameters(self, X: np.ndarray, y: np.ndarray) -> Dict:
        """Perform hyperparameter tuning."""
        logger.info("Tuning hyperparameters...")
        
        param_grid = {
            "max_depth": [5, 7, 9],
            "learning_rate": [0.01, 0.05, 0.1],
            "n_estimators": [100, 200, 300],
            "subsample": [0.7, 0.8, 0.9],
        }
        
        xgb_model = xgb.XGBRegressor(random_state=42, n_jobs=-1)
        
        grid_search = GridSearchCV(
            xgb_model, param_grid,
            cv=3, scoring="neg_root_mean_squared_error",
            verbose=0, n_jobs=-1,
        )
        
        grid_search.fit(X, y)
        
        logger.info(f"Best params: {grid_search.best_params_}")
        logger.info(f"Best score: {-grid_search.best_score_:.2f}")
        
        return grid_search.best_params_
    
    def evaluate(self, X_test: np.ndarray, y_test: np.ndarray) -> Dict:
        """Evaluate model on test set."""
        y_pred = self.model.predict(X_test)
        
        results = {
            "rmse": np.sqrt(mean_squared_error(y_test, y_pred)),
            "mae": mean_absolute_error(y_test, y_pred),
            "r2_score": r2_score(y_test, y_pred),
        }
        
        logger.info(f"Test RMSE: {results['rmse']:.2f}")
        logger.info(f"Test MAE: {results['mae']:.2f}")
        logger.info(f"Test R²: {results['r2_score']:.3f}")
        
        return results
    
    def save_model(self, version: str = None) -> str:
        """Save model to disk."""
        if version is None:
            version = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        os.makedirs(MODEL_DIR, exist_ok=True)
        
        model_path = os.path.join(MODEL_DIR, f"delay_prediction_{version}.pkl")
        
        with open(model_path, "wb") as f:
            pickle.dump({
                "model": self.model,
                "scaler": self.scaler,
                "features": self.feature_columns,
                "metrics": self.metrics,
                "training_date": self.training_date,
            }, f)
        
        logger.info(f"Model saved to {model_path}")
        return model_path
    
    def log_to_mlflow(self) -> None:
        """Log model and metrics to MLflow."""
        mlflow.set_tracking_uri(MLFLOW_TRACKING_URI)
        mlflow.set_experiment(EXPERIMENT_NAME)
        
        with mlflow.start_run():
            # Log parameters
            mlflow.log_params(self.model.get_params())
            
            # Log metrics
            mlflow.log_metrics(self.metrics)
            
            # Log model
            mlflow.xgboost.log_model(self.model, "model")
            
            logger.info("Model logged to MLflow")


def main():
    """Main training pipeline."""
    import argparse
    
    parser = argparse.ArgumentParser(description="Train delay prediction model")
    parser.add_argument("--tune-hyperparams", action="store_true", help="Tune hyperparameters")
    parser.add_argument("--model", type=str, default="xgboost", help="Model type")
    parser.add_argument("--export-onnx", action="store_true", help="Export to ONNX format")
    parser.add_argument("--skip-mlflow", action="store_true", help="Skip MLflow logging")
    args = parser.parse_args()
    
    logger.info("=" * 60)
    logger.info("🚀 DELAY PREDICTION MODEL TRAINING")
    logger.info("=" * 60)
    
    # Initialize
    trainer = DelayPredictionModel()
    
    # Load data
    df = trainer.load_data()
    
    # Preprocess
    X, y = trainer.preprocess(df)
    
    # Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_train, y_train, test_size=0.15, random_state=42
    )
    
    logger.info(f"Train: {X_train.shape[0]}, Val: {X_val.shape[0]}, Test: {X_test.shape[0]}")
    
    # Train
    metrics = trainer.train(
        X_train, y_train, X_val, y_val,
        tune_hyperparams=args.tune_hyperparams,
    )
    
    # Evaluate
    test_metrics = trainer.evaluate(X_test, y_test)
    
    # Save
    model_path = trainer.save_model()
    
    # Log to MLflow
    if not args.skip_mlflow:
        trainer.log_to_mlflow()
    
    # Print summary
    print("\n" + "=" * 60)
    print("📊 TRAINING SUMMARY")
    print("=" * 60)
    print(f"  Model: XGBoost Regressor")
    print(f"  Train RMSE: {metrics['rmse']:.2f}")
    print(f"  Val RMSE:   {metrics.get('val_rmse', 'N/A')}")
    print(f"  Test RMSE:  {test_metrics['rmse']:.2f}")
    print(f"  Test R²:    {test_metrics['r2_score']:.3f}")
    print(f"  Saved to:   {model_path}")
    print("=" * 60)


if __name__ == "__main__":
    main()