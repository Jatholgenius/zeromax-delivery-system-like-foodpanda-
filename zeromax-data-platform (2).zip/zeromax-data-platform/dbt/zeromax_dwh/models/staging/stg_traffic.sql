{{
  config(
    materialized='table',
    cluster_by=['traffic_date', 'zone_id'],
    tags=['staging', 'silver', 'traffic']
  )
}}

-- ============================================================
-- STAGING: STG_TRAFFIC
-- ============================================================
-- Bronze → Silver transformation for traffic data.
-- Source: Google Maps Traffic API (hourly observations)
-- ============================================================

WITH source AS (
    SELECT * FROM {{ source('bronze', 'traffic_api') }}
),

deduped AS (
    SELECT *
    FROM source
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY observation_timestamp, zone_id 
        ORDER BY ingestion_timestamp DESC
    ) = 1
),

cleaned AS (
    SELECT
        -- Primary Key
        traffic_id,
        
        -- Temporal
        CAST(observation_timestamp AS TIMESTAMP) AS observation_timestamp,
        CAST(observation_timestamp AS DATE) AS traffic_date,
        EXTRACT(HOUR FROM observation_timestamp) AS traffic_hour,
        EXTRACT(DOW FROM observation_timestamp) AS day_of_week,
        
        -- Location
        zone_id,
        zone_name,
        CAST(lat AS DECIMAL(10,6)) AS latitude,
        CAST(lon AS DECIMAL(10,6)) AS longitude,
        
        -- Traffic Metrics
        traffic_level,  -- Low, Low-Medium, Medium, High, Severe, Gridlock
        CAST(traffic_score AS INTEGER) AS traffic_score,  -- 1-10 scale
        CAST(congestion_pct AS DECIMAL(5,1)) AS congestion_pct,
        
        -- Speed
        CAST(avg_speed_kmh AS DECIMAL(5,1)) AS avg_speed_kmh,
        CAST(free_flow_speed_kmh AS DECIMAL(5,1)) AS free_flow_speed_kmh,
        CAST(speed_ratio AS DECIMAL(4,3)) AS speed_ratio,  -- avg/free_flow
        
        -- Travel Time
        CAST(travel_time_min AS INTEGER) AS travel_time_min,
        CAST(base_travel_time_min AS INTEGER) AS base_travel_time_min,
        CAST(delay_min AS INTEGER) AS delay_min,
        
        -- Distance
        CAST(distance_km AS DECIMAL(6,2)) AS distance_km,
        
        -- Incidents
        CAST(active_incidents AS INTEGER) AS active_incidents,
        incident_types,
        is_road_closure,
        is_accident,
        is_construction,
        is_event,
        
        -- Derived: Severity Level (1-5)
        CASE
            WHEN traffic_level = 'Gridlock' THEN 5
            WHEN traffic_level = 'Severe' THEN 4
            WHEN traffic_level = 'High' THEN 3
            WHEN traffic_level = 'Medium' THEN 2
            WHEN traffic_level = 'Low-Medium' THEN 1
            ELSE 0  -- Low
        END AS severity_level,
        
        -- Derived: Delay Factor (multiplier)
        CASE
            WHEN traffic_level = 'Gridlock' THEN 2.50
            WHEN traffic_level = 'Severe' THEN 2.00
            WHEN traffic_level = 'High' THEN 1.60
            WHEN traffic_level = 'Medium' THEN 1.30
            WHEN traffic_level = 'Low-Medium' THEN 1.15
            ELSE 1.00  -- Low
        END AS delay_factor,
        
        -- Derived: Peak Period
        CASE
            WHEN traffic_hour IN (8, 9, 10) THEN 'Morning Rush'
            WHEN traffic_hour IN (17, 18, 19) THEN 'Evening Rush'
            WHEN traffic_hour IN (12, 13, 14) THEN 'Lunch Time'
            WHEN traffic_hour IN (22, 23, 0, 1, 2, 3, 4, 5) THEN 'Night'
            ELSE 'Normal'
        END AS peak_period,
        
        -- Derived: Is Peak Hour
        CASE
            WHEN traffic_hour IN (8, 9, 10, 17, 18, 19) THEN TRUE
            ELSE FALSE
        END AS is_peak_hour,
        
        -- Derived: Route Efficiency
        CASE 
            WHEN avg_speed_kmh > 0 AND free_flow_speed_kmh > 0
            THEN ROUND((avg_speed_kmh / free_flow_speed_kmh) * 100, 1)
            ELSE 100
        END AS route_efficiency_pct,
        
        -- Metadata
        data_provider,
        CAST(ingestion_timestamp AS TIMESTAMP) AS ingested_at,
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'stg_traffic' AS dw_source
        
    FROM deduped
)

SELECT * FROM cleaned
WHERE observation_timestamp IS NOT NULL
  AND zone_id IS NOT NULL
  AND traffic_level IN ('Low', 'Low-Medium', 'Medium', 'High', 'Severe', 'Gridlock')
  AND traffic_score BETWEEN 1 AND 10
  AND congestion_pct BETWEEN 0 AND 100
  AND avg_speed_kmh >= 0