{{
  config(
    materialized='table',
    tags=['gold', 'dimension', 'time', 'static'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: DIM_TIME
-- ============================================================
-- Time dimension (24 hours) with business periods.
-- Used for hour-of-day analysis and peak hour identification.
-- ============================================================

WITH hours AS (
    SELECT ROW_NUMBER() OVER (ORDER BY SEQ4()) - 1 AS hour_num
    FROM TABLE(GENERATOR(ROWCOUNT => 24))
)

SELECT
    -- Surrogate Key
    hour_num + 1 AS time_sk,
    
    -- Time Values
    hour_num AS hour,
    LPAD(hour_num::VARCHAR, 2, '0') || ':00' AS hour_label,
    LPAD(hour_num::VARCHAR, 2, '0') || ':00:00' AS time_value,
    
    -- Period Classification
    CASE
        WHEN hour_num BETWEEN 5 AND 8 THEN 'Early Morning'
        WHEN hour_num BETWEEN 9 AND 11 THEN 'Morning'
        WHEN hour_num BETWEEN 12 AND 15 THEN 'Lunch'
        WHEN hour_num BETWEEN 16 AND 17 THEN 'Afternoon'
        WHEN hour_num BETWEEN 18 AND 21 THEN 'Dinner'
        WHEN hour_num BETWEEN 22 AND 23 THEN 'Evening'
        ELSE 'Late Night'
    END AS period,
    
    -- Peak Status
    CASE
        WHEN hour_num IN (12, 13, 14, 18, 19, 20, 21) THEN 'Peak'
        WHEN hour_num IN (8, 9, 10, 15, 16, 17) THEN 'Moderate'
        ELSE 'Off-Peak'
    END AS peak_status,
    
    -- Boolean Flags
    CASE WHEN hour_num IN (12, 13, 14, 18, 19, 20, 21) THEN TRUE ELSE FALSE END AS is_peak_hour,
    CASE WHEN hour_num >= 22 OR hour_num <= 4 THEN TRUE ELSE FALSE END AS is_night,
    CASE WHEN hour_num BETWEEN 6 AND 18 THEN TRUE ELSE FALSE END AS is_daytime,
    CASE WHEN hour_num IN (12, 13, 14) THEN TRUE ELSE FALSE END AS is_lunch_time,
    CASE WHEN hour_num IN (18, 19, 20, 21) THEN TRUE ELSE FALSE END AS is_dinner_time,
    CASE WHEN hour_num IN (8, 9, 10) THEN TRUE ELSE FALSE END AS is_morning_rush,
    CASE WHEN hour_num IN (17, 18, 19) THEN TRUE ELSE FALSE END AS is_evening_rush,
    
    -- Multipliers
    CASE
        WHEN hour_num IN (12, 13, 14) THEN 1.25
        WHEN hour_num IN (18, 19, 20, 21) THEN 1.80
        WHEN hour_num IN (8, 9, 10, 15, 16, 17) THEN 1.15
        WHEN hour_num >= 22 OR hour_num <= 4 THEN 0.85
        ELSE 1.00
    END AS rush_multiplier,
    
    CASE
        WHEN hour_num IN (12, 13, 14) THEN 1.00
        WHEN hour_num IN (18, 19, 20, 21) THEN 1.50
        WHEN hour_num IN (8, 9, 10, 15, 16, 17) THEN 0.80
        WHEN hour_num >= 22 OR hour_num <= 4 THEN 0.20
        ELSE 0.55
    END AS volume_factor,
    
    -- Shift Mapping
    CASE
        WHEN hour_num BETWEEN 6 AND 14 THEN 'Morning Shift'
        WHEN hour_num BETWEEN 14 AND 22 THEN 'Evening Shift'
        ELSE 'Night Shift'
    END AS shift,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'dim_time' AS dw_source

FROM hours
ORDER BY hour_num