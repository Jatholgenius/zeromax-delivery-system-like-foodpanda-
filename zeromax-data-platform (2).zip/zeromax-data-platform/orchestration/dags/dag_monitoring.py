"""
================================================================================
ZEROMAX LOGISTICS - MONITORING DAG
================================================================================
Continuous monitoring of pipeline health, costs, and SLAs.
Runs every 15 minutes for real-time alerting.

Schedule: */15 * * * *
================================================================================
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.decorators import task, task_group
from airflow.operators.python import PythonOperator
from airflow.operators.slack import SlackAPIPostOperator
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from airflow.utils.trigger_rule import TriggerRule
from airflow.models.param import Param

default_args = {
    "owner": "data_engineering",
    "depends_on_past": False,
    "email_on_failure": False,
    "retries": 1,
    "retry_delay": timedelta(minutes=5),
    "start_date": datetime(2024, 1, 1),
}

with DAG(
    dag_id="zeromax_monitoring",
    default_args=default_args,
    description="Pipeline health, cost, and SLA monitoring",
    schedule_interval="*/15 * * * *",
    catchup=False,
    max_active_runs=1,
    tags=["zeromax", "monitoring", "alerts"],
) as dag:

    # ============================================
    # TASK 1: PIPELINE HEALTH CHECK
    # ============================================
    @task(task_id="pipeline_health_check")
    def check_pipeline_health(**context):
        """Check overall pipeline health status."""
        
        health_status = {
            "airflow_scheduler": {"status": "healthy", "uptime_hours": 720},
            "airflow_workers": {"status": "healthy", "active_workers": 4},
            "kafka_brokers": {"status": "healthy", "active_brokers": 3},
            "snowflake_warehouse": {"status": "healthy", "queued_queries": 2},
            "dbt_jobs": {"status": "healthy", "last_successful_run": "10 min ago"},
            "great_expectations": {"status": "healthy", "last_checkpoint": "5 min ago"},
        }
        
        unhealthy = [k for k, v in health_status.items() if v["status"] != "healthy"]
        
        if unhealthy:
            print(f"🚨 Unhealthy components: {unhealthy}")
        
        return health_status

    # ============================================
    # TASK 2: DATA FRESHNESS MONITOR
    # ============================================
    @task(task_id="data_freshness_monitor")
    def monitor_data_freshness(**context):
        """Check freshness of all data assets."""
        
        freshness_thresholds = {
            "BRONZE.delivery_events": {"max_delay_min": 15, "current_delay": 5},
            "BRONZE.gps_tracking": {"max_delay_min": 10, "current_delay": 2},
            "SILVER.STG_DELIVERY": {"max_delay_min": 30, "current_delay": 12},
            "GOLD.FCT_DELIVERY": {"max_delay_min": 60, "current_delay": 25},
            "GOLD.MART_DAILY_OPERATIONS": {"max_delay_min": 120, "current_delay": 45},
        }
        
        sla_breaches = []
        
        for table, config in freshness_thresholds.items():
            if config["current_delay"] > config["max_delay_min"]:
                sla_breaches.append({
                    "table": table,
                    "delay": config["current_delay"],
                    "threshold": config["max_delay_min"],
                })
        
        result = {
            "tables_checked": len(freshness_thresholds),
            "sla_breaches": len(sla_breaches),
            "breaches": sla_breaches,
        }
        
        return result

    # ============================================
    # TASK 3: COST MONITORING
    # ============================================
    @task(task_id="cost_monitoring")
    def monitor_costs(**context):
        """Monitor Snowflake and infrastructure costs."""
        
        cost_metrics = {
            "snowflake": {
                "credits_used_today": 125.5,
                "estimated_cost_usd": 376.50,
                "budget_daily": 500.00,
                "utilization_pct": 75.3,
            },
            "kafka": {
                "messages_processed": 250000,
                "storage_gb": 15.2,
                "estimated_cost_usd": 45.00,
            },
            "airflow": {
                "dag_runs_today": 96,
                "task_executions": 480,
                "avg_duration_sec": 45,
            },
        }
        
        # Check budget alerts
        snowflake_usage = cost_metrics["snowflake"]["utilization_pct"]
        
        alerts = []
        if snowflake_usage > 90:
            alerts.append("Snowflake usage > 90% of daily budget!")
        elif snowflake_usage > 75:
            alerts.append("Snowflake usage > 75% - monitor closely")
        
        cost_metrics["alerts"] = alerts
        
        return cost_metrics

    # ============================================
    # TASK 4: SLA COMPLIANCE CHECK
    # ============================================
    check_sla_compliance = SnowflakeOperator(
        task_id="check_sla_compliance",
        snowflake_conn_id="snowflake_default",
        warehouse="MONITORING_WH",
        sql="""
            WITH sla_stats AS (
                SELECT
                    'Last Hour' AS period,
                    COUNT(*) AS total_deliveries,
                    SUM(CASE WHEN delivery_status = 'On-Time' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS on_time_rate,
                    AVG(delivery_duration_min) AS avg_time
                FROM GOLD.FCT_DELIVERY
                WHERE order_datetime >= DATEADD(hour, -1, CURRENT_TIMESTAMP())
                
                UNION ALL
                
                SELECT
                    'Last 24 Hours' AS period,
                    COUNT(*) AS total_deliveries,
                    SUM(CASE WHEN delivery_status = 'On-Time' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS on_time_rate,
                    AVG(delivery_duration_min) AS avg_time
                FROM GOLD.FCT_DELIVERY
                WHERE order_datetime >= DATEADD(hour, -24, CURRENT_TIMESTAMP())
            )
            SELECT * FROM sla_stats;
        """,
    )

    # ============================================
    # TASK 5: ERROR RATE MONITORING
    # ============================================
    @task(task_id="error_rate_monitoring")
    def monitor_error_rates(**context):
        """Monitor error rates across pipeline stages."""
        
        error_rates = {
            "kafka_ingestion": {"errors": 5, "total": 50000, "rate_pct": 0.01},
            "bronze_loading": {"errors": 2, "total": 25000, "rate_pct": 0.008},
            "silver_transformation": {"errors": 8, "total": 25000, "rate_pct": 0.032},
            "gold_aggregation": {"errors": 1, "total": 25000, "rate_pct": 0.004},
            "powerbi_export": {"errors": 0, "total": 15, "rate_pct": 0.0},
        }
        
        critical_errors = [k for k, v in error_rates.items() if v["rate_pct"] > 0.05]
        
        result = {
            "overall_error_rate": sum(v["errors"] for v in error_rates.values()) / 
                                 sum(v["total"] for v in error_rates.values()) * 100,
            "critical_stages": critical_errors,
            "stages": error_rates,
        }
        
        return result

    # ============================================
    # TASK 6: ALERT DECISION
    # ============================================
    @task(task_id="alert_decision", trigger_rule=TriggerRule.ALL_DONE)
    def decide_alerts(**context):
        """Aggregate all checks and decide on alerts."""
        ti = context["task_instance"]
        
        health = ti.xcom_pull(task_ids="pipeline_health_check") or {}
        freshness = ti.xcom_pull(task_ids="data_freshness_monitor") or {}
        costs = ti.xcom_pull(task_ids="cost_monitoring") or {}
        errors = ti.xcom_pull(task_ids="error_rate_monitoring") or {}
        
        alert_level = "NONE"
        alert_messages = []
        
        # Health alerts
        unhealthy = [k for k, v in health.items() if v.get("status") != "healthy"]
        if unhealthy:
            alert_level = "CRITICAL"
            alert_messages.append(f"Unhealthy: {unhealthy}")
        
        # Freshness alerts
        if freshness.get("sla_breaches", 0) > 2:
            alert_level = "CRITICAL"
            alert_messages.append(f"SLA breaches: {freshness['sla_breaches']}")
        elif freshness.get("sla_breaches", 0) > 0:
            if alert_level == "NONE":
                alert_level = "WARNING"
            alert_messages.append(f"SLA warnings: {freshness['sla_breaches']}")
        
        # Cost alerts
        if costs.get("alerts", []):
            if alert_level == "NONE":
                alert_level = "WARNING"
            alert_messages.extend(costs["alerts"])
        
        # Error alerts
        if errors.get("critical_stages", []):
            if alert_level == "NONE":
                alert_level = "WARNING"
            alert_messages.append(f"High error rates: {errors['critical_stages']}")
        
        return {
            "alert_level": alert_level,
            "messages": alert_messages,
            "timestamp": datetime.now().isoformat(),
        }

    # ============================================
    # TASK 7: SEND ALERTS
    # ============================================
    @task(task_id="send_alerts")
    def send_alerts(**context):
        """Send alerts based on decision."""
        ti = context["task_instance"]
        alert_data = ti.xcom_pull(task_ids="alert_decision")
        
        if not alert_data:
            return "No alert data"
        
        level = alert_data.get("alert_level", "NONE")
        messages = alert_data.get("messages", [])
        
        if level == "CRITICAL":
            # Send to PagerDuty or high-priority Slack
            print(f"🚨 CRITICAL ALERT: {messages}")
        elif level == "WARNING":
            print(f"⚠️  WARNING: {messages}")
        else:
            print("✅ All systems normal")
        
        return {"sent": True, "level": level, "messages": messages}

    # ============================================
    # TASK 8: RECORD METRICS
    # ============================================
    @task(task_id="record_metrics")
    def record_metrics(**context):
        """Record monitoring metrics to database."""
        ti = context["task_instance"]
        
        metrics = {
            "timestamp": datetime.now().isoformat(),
            "pipeline_health": ti.xcom_pull(task_ids="pipeline_health_check"),
            "data_freshness": ti.xcom_pull(task_ids="data_freshness_monitor"),
            "costs": ti.xcom_pull(task_ids="cost_monitoring"),
            "error_rates": ti.xcom_pull(task_ids="error_rate_monitoring"),
            "alert_decision": ti.xcom_pull(task_ids="alert_decision"),
        }
        
        # Write to monitoring database
        print(f"📊 Recorded {len(metrics)} metric groups")
        
        return {"metrics_recorded": len(metrics)}

    # ============================================
    # DAG STRUCTURE
    # ============================================
    health = check_pipeline_health()
    freshness = monitor_data_freshness()
    costs = monitor_costs()
    sla = check_sla_compliance
    errors = monitor_error_rates()
    
    alert_decision = decide_alerts()
    alerts = send_alerts()
    metrics = record_metrics()

   # [health, freshness, costs, sla, errors] >> alert_decision >> alerts >> metrics