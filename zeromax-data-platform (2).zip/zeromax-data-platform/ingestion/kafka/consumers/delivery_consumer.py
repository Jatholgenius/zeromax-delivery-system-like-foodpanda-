"""
================================================================================
ZEROMAX LOGISTICS - DELIVERY EVENTS KAFKA CONSUMER
================================================================================
Consumes delivery events from Kafka and writes to Bronze layer.
Supports exactly-once semantics with checkpointing.

Usage:
    python delivery_consumer.py
    python delivery_consumer.py --topics zeromax.orders,zeromax.order_status
    python delivery_consumer.py --group delivery-consumer-group
================================================================================
"""

import os
import sys
import json
import time
import signal
import logging
from datetime import datetime
from typing import Dict, List, Optional, Callable
from pathlib import Path

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
from confluent_kafka import Consumer, KafkaError, KafkaException
from confluent_kafka.admin import AdminClient
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/delivery_consumer.log"),
    ],
)
logger = logging.getLogger(__name__)

# ============================================
# CONFIGURATION
# ============================================

KAFKA_CONFIG = {
    "bootstrap.servers": os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"),
    "group.id": os.getenv("KAFKA_GROUP_ID", "zeromax-delivery-consumer"),
    "auto.offset.reset": "earliest",
    "enable.auto.commit": False,
    "max.poll.interval.ms": 300000,
    "session.timeout.ms": 30000,
    "heartbeat.interval.ms": 10000,
    "isolation.level": "read_committed",
}

BRONZE_DIR = os.getenv("BRONZE_DIR", "data/bronze")
CHECKPOINT_DIR = os.getenv("CHECKPOINT_DIR", "data/checkpoints")
BATCH_SIZE = int(os.getenv("BATCH_SIZE", "1000"))
BATCH_TIMEOUT_SECONDS = int(os.getenv("BATCH_TIMEOUT", "30"))

TOPICS = [
    "zeromax.orders",
    "zeromax.order_status",
    "zeromax.gps_tracking",
]


class CheckpointManager:
    """Manages consumer checkpoints for exactly-once processing."""
    
    def __init__(self, checkpoint_dir: str = CHECKPOINT_DIR):
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_file = self.checkpoint_dir / "consumer_checkpoint.json"
        self.checkpoints = self._load()
    
    def _load(self) -> Dict:
        """Load checkpoints from file."""
        if self.checkpoint_file.exists():
            with open(self.checkpoint_file, "r") as f:
                return json.load(f)
        return {"offsets": {}, "last_commit": None}
    
    def save(self) -> None:
        """Save checkpoints to file."""
        self.checkpoints["last_commit"] = datetime.now().isoformat()
        with open(self.checkpoint_file, "w") as f:
            json.dump(self.checkpoints, f, indent=2)
    
    def update_offset(self, topic: str, partition: int, offset: int) -> None:
        """Update checkpoint for a topic partition."""
        key = f"{topic}_{partition}"
        self.checkpoints["offsets"][key] = offset
    
    def get_offset(self, topic: str, partition: int) -> Optional[int]:
        """Get checkpointed offset."""
        key = f"{topic}_{partition}"
        return self.checkpoints["offsets"].get(key)


class BronzeWriter:
    """Writes consumed messages to Bronze layer in Parquet format."""
    
    def __init__(self, bronze_dir: str = BRONZE_DIR):
        self.bronze_dir = Path(bronze_dir)
        self.bronze_dir.mkdir(parents=True, exist_ok=True)
        self.buffer: Dict[str, List[Dict]] = {}
    
    def add_message(self, topic: str, message: Dict) -> None:
        """Add message to buffer for batch writing."""
        if topic not in self.buffer:
            self.buffer[topic] = []
        self.buffer[topic].append(message)
    
    def get_buffer_size(self) -> int:
        """Get total messages in buffer."""
        return sum(len(messages) for messages in self.buffer.values())
    
    def flush(self) -> Dict[str, int]:
        """
        Write buffered messages to Bronze layer.
        
        Returns:
            Dict with rows written per topic
        """
        written_counts = {}
        
        for topic, messages in self.buffer.items():
            if not messages:
                continue
            
            try:
                # Convert to DataFrame
                df = pd.DataFrame(messages)
                
                # Add metadata
                df["ingestion_timestamp"] = datetime.now().isoformat()
                df["source_topic"] = topic
                
                # Create partition path
                now = datetime.now()
                topic_dir = topic.replace(".", "_")
                partition_path = (
                    self.bronze_dir / topic_dir /
                    f"year={now.year}" /
                    f"month={now.month:02d}" /
                    f"day={now.day:02d}" /
                    f"hour={now.hour:02d}"
                )
                partition_path.mkdir(parents=True, exist_ok=True)
                
                # Write Parquet file
                output_file = partition_path / f"data_{now.strftime('%Y%m%d_%H%M%S')}_{len(messages)}.parquet"
                
                table = pa.Table.from_pandas(df)
                pq.write_table(table, output_file, compression="snappy")
                
                written_counts[topic] = len(messages)
                logger.info(f"✅ {topic}: {len(messages):,} messages → {output_file}")
                
            except Exception as e:
                logger.error(f"❌ Error writing {topic}: {str(e)}")
                # Move to dead letter queue
                self._write_to_dlq(topic, messages, str(e))
        
        # Clear buffer
        self.buffer.clear()
        
        return written_counts
    
    def _write_to_dlq(self, topic: str, messages: List[Dict], error: str) -> None:
        """Write failed messages to Dead Letter Queue."""
        dlq_dir = self.bronze_dir / "dead_letter_queue"
        dlq_dir.mkdir(parents=True, exist_ok=True)
        
        dlq_file = dlq_dir / f"dlq_{topic}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        dlq_data = {
            "topic": topic,
            "error": error,
            "timestamp": datetime.now().isoformat(),
            "messages": messages,
        }
        
        with open(dlq_file, "w") as f:
            json.dump(dlq_data, f, indent=2, default=str)
        
        logger.warning(f"📁 Messages sent to DLQ: {dlq_file}")


class DeliveryEventConsumer:
    """
    Consumes delivery events from Kafka and writes to Bronze layer.
    """
    
    def __init__(self, config: Dict = None, topics: List[str] = None):
        self.config = config or KAFKA_CONFIG
        self.topics = topics or TOPICS
        self.consumer = Consumer(self.config)
        self.checkpoints = CheckpointManager()
        self.writer = BronzeWriter()
        self.running = True
        self.stats = {
            "messages_consumed": 0,
            "batches_written": 0,
            "errors": 0,
            "start_time": datetime.now(),
        }
    
    def subscribe(self) -> None:
        """Subscribe to Kafka topics."""
        self.consumer.subscribe(self.topics)
        logger.info(f"Subscribed to topics: {self.topics}")
    
    def process_message(self, msg) -> Optional[Dict]:
        """
        Process a single Kafka message.
        
        Args:
            msg: Kafka message object
            
        Returns:
            Parsed message dict or None on error
        """
        try:
            # Parse JSON
            message = json.loads(msg.value().decode("utf-8"))
            
            # Add Kafka metadata
            message["kafka_topic"] = msg.topic()
            message["kafka_partition"] = msg.partition()
            message["kafka_offset"] = msg.offset()
            message["kafka_timestamp"] = msg.timestamp()[1] if msg.timestamp()[1] else 0
            
            return message
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON decode error: {e}")
            return None
        except Exception as e:
            logger.error(f"Processing error: {e}")
            return None
    
    def transform_message(self, message: Dict, topic: str) -> Dict:
        """
        Apply transformations to standardize message format.
        
        Args:
            message: Raw message
            topic: Source topic
            
        Returns:
            Transformed message
        """
        # Add processing metadata
        message["processed_at"] = datetime.now().isoformat()
        message["processing_version"] = "1.0.0"
        
        # Standardize field names
        if topic == "zeromax.orders":
            message = self._transform_order(message)
        elif topic == "zeromax.order_status":
            message = self._transform_status(message)
        elif topic == "zeromax.gps_tracking":
            message = self._transform_gps(message)
        
        return message
    
    def _transform_order(self, msg: Dict) -> Dict:
        """Transform order event."""
        msg["event_type"] = "order"
        return msg
    
    def _transform_status(self, msg: Dict) -> Dict:
        """Transform status event."""
        msg["event_type"] = "status_update"
        return msg
    
    def _transform_gps(self, msg: Dict) -> Dict:
        """Transform GPS event."""
        msg["event_type"] = "gps_ping"
        return msg
    
    def commit_offsets(self) -> None:
        """Commit offsets to Kafka."""
        try:
            self.consumer.commit(asynchronous=False)
            self.checkpoints.save()
        except KafkaException as e:
            logger.error(f"Offset commit failed: {e}")
    
    def shutdown(self) -> None:
        """Graceful shutdown."""
        logger.info("Shutting down consumer...")
        self.running = False
        
        # Flush remaining messages
        if self.writer.get_buffer_size() > 0:
            logger.info(f"Flushing {self.writer.get_buffer_size()} remaining messages...")
            self.writer.flush()
        
        # Commit offsets
        self.commit_offsets()
        
        # Close consumer
        self.consumer.close()
        
        self._print_final_stats()
    
    def _print_final_stats(self) -> None:
        """Print final statistics."""
        elapsed = (datetime.now() - self.stats["start_time"]).total_seconds()
        
        print("\n" + "=" * 60)
        print("📊 CONSUMER STATISTICS")
        print("=" * 60)
        print(f"  Messages Consumed: {self.stats['messages_consumed']:,}")
        print(f"  Batches Written:   {self.stats['batches_written']}")
        print(f"  Errors:            {self.stats['errors']}")
        print(f"  Runtime:           {elapsed:.1f}s")
        print(f"  Avg Rate:          {self.stats['messages_consumed'] / elapsed:.1f} msg/s")
        print("=" * 60)
    
    def run(self) -> None:
        """Main consumer loop."""
        self.subscribe()
        
        logger.info("=" * 60)
        logger.info("🎧 DELIVERY EVENT CONSUMER STARTED")
        logger.info(f"   Topics: {self.topics}")
        logger.info(f"   Batch Size: {BATCH_SIZE}")
        logger.info("=" * 60)
        
        # Register signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, lambda s, f: self.shutdown())
        signal.signal(signal.SIGTERM, lambda s, f: self.shutdown())
        
        last_batch_time = time.time()
        
        try:
            while self.running:
                msg = self.consumer.poll(timeout=1.0)
                
                if msg is None:
                    # Check if batch timeout reached
                    if (time.time() - last_batch_time) >= BATCH_TIMEOUT_SECONDS:
                        if self.writer.get_buffer_size() > 0:
                            written = self.writer.flush()
                            self.stats["batches_written"] += 1
                            self.commit_offsets()
                        last_batch_time = time.time()
                    continue
                
                if msg.error():
                    if msg.error().code() == KafkaError._PARTITION_EOF:
                        logger.debug(f"Reached end of partition: {msg.topic()} [{msg.partition()}]")
                    else:
                        logger.error(f"Kafka error: {msg.error()}")
                        self.stats["errors"] += 1
                    continue
                
                # Process message
                message = self.process_message(msg)
                if message:
                    topic = msg.topic()
                    transformed = self.transform_message(message, topic)
                    self.writer.add_message(topic, transformed)
                    self.stats["messages_consumed"] += 1
                    
                    # Update checkpoint
                    self.checkpoints.update_offset(
                        topic, msg.partition(), msg.offset()
                    )
                
                # Flush batch when buffer is full or timeout reached
                if (self.writer.get_buffer_size() >= BATCH_SIZE or
                    (time.time() - last_batch_time) >= BATCH_TIMEOUT_SECONDS):
                    
                    if self.writer.get_buffer_size() > 0:
                        written = self.writer.flush()
                        self.stats["batches_written"] += 1
                        self.commit_offsets()
                    
                    last_batch_time = time.time()
                    
                    # Periodic stats
                    if self.stats["batches_written"] % 10 == 0:
                        elapsed = (datetime.now() - self.stats["start_time"]).total_seconds()
                        rate = self.stats["messages_consumed"] / elapsed if elapsed > 0 else 0
                        logger.info(f"📊 Consumed: {self.stats['messages_consumed']:,} msg "
                                   f"({rate:.1f} msg/s) | Batches: {self.stats['batches_written']}")
        
        except Exception as e:
            logger.error(f"Consumer error: {e}")
            self.stats["errors"] += 1
        finally:
            self.shutdown()


def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Delivery Event Consumer")
    parser.add_argument("--topics", nargs="+", help="Topics to consume")
    parser.add_argument("--group", type=str, help="Consumer group ID")
    parser.add_argument("--batch-size", type=int, default=BATCH_SIZE, help="Batch size for writes")
    parser.add_argument("--batch-timeout", type=int, default=BATCH_TIMEOUT_SECONDS, help="Batch timeout in seconds")
    args = parser.parse_args()
    
    config = KAFKA_CONFIG.copy()
    if args.group:
        config["group.id"] = args.group
    
    topics = args.topics if args.topics else TOPICS
    
    consumer = DeliveryEventConsumer(config=config, topics=topics)
    
    # Override batch settings
    global BATCH_SIZE, BATCH_TIMEOUT_SECONDS
    BATCH_SIZE = args.batch_size
    BATCH_TIMEOUT_SECONDS = args.batch_timeout
    
    consumer.run()


if __name__ == "__main__":
    main()