{{
  config(
    materialized='table',
    cluster_by=['restaurant_id', 'zone_id'],
    tags=['staging', 'silver', 'restaurant']
  )
}}

-- ============================================================
-- STAGING: STG_RESTAURANT
-- ============================================================
-- Bronze → Silver transformation for restaurant data.
-- ============================================================

WITH source AS (
    SELECT * FROM {{ source('bronze', 'restaurant_data') }}
),

deduped AS (
    SELECT *
    FROM source
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY restaurant_id 
        ORDER BY updated_at DESC
    ) = 1
),

cleaned AS (
    SELECT
        -- Primary Key
        restaurant_id,
        
        -- Basic Info
        restaurant_name,
        chain_name,
        is_chain,
        
        -- Location
        zone_id,
        zone_name,
        area,
        full_address,
        
        -- Coordinates
        CAST(lat AS DECIMAL(10,6)) AS latitude,
        CAST(lon AS DECIMAL(10,6)) AS longitude,
        
        -- Cuisine
        cuisine_type,
        cuisine_category,
        is_halal,
        
        -- Menu & Pricing
        CAST(avg_menu_price_pkr AS DECIMAL(8,2)) AS avg_menu_price,
        price_tier,  -- Budget/Standard/Premium/Luxury
        popular_items,
        
        -- Operations
        CAST(avg_prep_time_min AS INTEGER) AS avg_prep_time_min,
        CAST(avg_rating AS DECIMAL(3,1)) AS avg_rating,
        CAST(total_ratings AS INTEGER) AS total_ratings,
        
        -- Capacity
        CAST(daily_capacity AS INTEGER) AS daily_capacity,
        is_24_hours,
        opening_hours,
        
        -- Partnership
        partnership_tier,  -- Basic/Silver/Gold/Platinum
        CAST(commission_pct AS DECIMAL(4,2)) AS commission_pct,
        contract_start_date,
        contract_end_date,
        
        -- Status
        is_active,
        is_accepting_orders,
        is_delivery_only,
        
        -- Contact
        contact_phone,
        contact_email,
        manager_name,
        
        -- Metadata
        CAST(created_at AS TIMESTAMP) AS created_at,
        CAST(updated_at AS TIMESTAMP) AS updated_at,
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'stg_restaurant' AS dw_source
        
    FROM deduped
)

SELECT * FROM cleaned
WHERE restaurant_id IS NOT NULL
  AND restaurant_name IS NOT NULL
  AND latitude BETWEEN 24.7 AND 25.1
  AND longitude BETWEEN 66.8 AND 67.3
  AND avg_prep_time_min > 0
  AND avg_prep_time_min <= 60
  AND cuisine_type IS NOT NULL