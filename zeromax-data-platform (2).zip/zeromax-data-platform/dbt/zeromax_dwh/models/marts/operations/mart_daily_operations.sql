{{
  config(
    materialized='table',
    cluster_by=['full_date', 'zone_name'],
    tags=['gold', 'operations', 'daily', 'aggregated'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter",
      "GRANT SELECT ON {{ this }} TO ROLE analyst"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: MART_DAILY_OPERATIONS
-- ============================================================
-- Daily aggregated delivery metrics by zone.
-- Used for operational dashboards and trend analysis.
-- Granularity: One row per day per zone.
-- ============================================================

WITH daily_base AS (
    SELECT
        -- Date dimension
        dd.full_date,
        dd.year,
        dd.quarter,
        dd.month,
        dd.month_name,
        dd.week_num,
        dd.day_name,
        dd.is_weekend,
        dd.is_holiday,
        dd.holiday_name,
        dd.is_ramadan,
        dd.is_eid,
        dd.is_eid_adha,
        dd.season,
        
        -- Zone dimension
        dz.zone_key,
        dz.zone_id,
        dz.zone_name,
        dz.avg_base_time_min AS zone_avg_time,
        dz.traffic_factor AS zone_traffic_factor,
        
        -- Aggregation metrics
        COUNT(DISTINCT fd.delivery_sk) AS total_deliveries,
        COUNT(DISTINCT fd.driver_sk) AS unique_drivers,
        COUNT(DISTINCT fd.customer_sk) AS unique_customers,
        COUNT(DISTINCT fd.restaurant_sk) AS unique_restaurants,
        
        -- Status breakdown
        SUM(fd.is_on_time) AS on_time_deliveries,
        SUM(fd.is_late) AS late_deliveries,
        SUM(fd.is_failed) AS failed_deliveries,
        
        -- Time metrics
        ROUND(AVG(fd.delivery_duration_min), 1) AS avg_delivery_time_min,
        ROUND(AVG(fd.delay_min), 1) AS avg_delay_min,
        ROUND(AVG(fd.preparation_time_min), 1) AS avg_prep_time_min,
        ROUND(AVG(fd.travel_time_actual_min), 1) AS avg_travel_time_min,
        ROUND(AVG(fd.pickup_delay_min), 1) AS avg_pickup_delay_min,
        
        -- Percentile metrics
        PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY fd.delivery_duration_min) AS p50_delivery_time,
        PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY fd.delivery_duration_min) AS p90_delivery_time,
        PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY fd.delivery_duration_min) AS p95_delivery_time,
        PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY fd.delivery_duration_min) AS p99_delivery_time,
        
        -- Distance metrics
        ROUND(AVG(fd.distance_km), 2) AS avg_distance_km,
        SUM(fd.distance_km) AS total_distance_km,
        ROUND(AVG(fd.route_efficiency_pct), 1) AS avg_route_efficiency_pct,
        
        -- Rating metrics
        ROUND(AVG(fd.customer_rating), 2) AS avg_rating,
        COUNT(CASE WHEN fd.customer_rating >= 4.5 THEN 1 END) AS excellent_ratings,
        COUNT(CASE WHEN fd.customer_rating < 3.0 THEN 1 END) AS poor_ratings,
        
        -- Financial metrics
        SUM(fd.delivery_fee_pkr) AS total_revenue_pkr,
        SUM(fd.driver_cost_pkr) AS total_driver_cost_pkr,
        SUM(fd.platform_fee_pkr) AS total_platform_fee_pkr,
        SUM(fd.delay_penalty_pkr) AS total_penalty_pkr,
        SUM(fd.profit_pkr) AS total_profit_pkr,
        ROUND(AVG(fd.profit_pkr), 0) AS avg_profit_per_order_pkr,
        
        -- Vehicle breakdown
        COUNT(CASE WHEN fd.vehicle_category = 'Bike' THEN 1 END) AS bike_deliveries,
        COUNT(CASE WHEN fd.vehicle_category = 'Car' THEN 1 END) AS car_deliveries,
        COUNT(CASE WHEN fd.vehicle_category = 'Rickshaw' THEN 1 END) AS rickshaw_deliveries,
        
        -- Payment breakdown
        COUNT(CASE WHEN fd.is_cod THEN 1 END) AS cod_orders,
        COUNT(CASE WHEN NOT fd.is_cod THEN 1 END) AS digital_payment_orders,
        
        -- Weather & Traffic
        ROUND(AVG(fd.weather_severity), 1) AS avg_weather_severity,
        ROUND(AVG(fd.traffic_severity), 1) AS avg_traffic_severity,
        
        -- Peak vs Off-Peak
        COUNT(CASE WHEN fd.is_peak_hour THEN 1 END) AS peak_hour_deliveries,
        COUNT(CASE WHEN NOT fd.is_peak_hour THEN 1 END) AS off_peak_deliveries,
        
        -- Metadata
        MAX(fd.dw_created_at) AS last_updated
        
    FROM {{ ref('fct_delivery') }} fd
    INNER JOIN {{ ref('dim_date') }} dd
        ON fd.date_key = dd.date_key
    INNER JOIN {{ ref('dim_zone') }} dz
        ON fd.zone_key = dz.zone_key
    
    WHERE fd.order_datetime >= DATEADD(year, -1, CURRENT_DATE())  -- Rolling 12 months
    
    GROUP BY 
        dd.full_date, dd.year, dd.quarter, dd.month, dd.month_name,
        dd.week_num, dd.day_name, dd.is_weekend, dd.is_holiday,
        dd.holiday_name, dd.is_ramadan, dd.is_eid, dd.is_eid_adha,
        dd.season,
        dz.zone_key, dz.zone_id, dz.zone_name,
        dz.avg_base_time_min, dz.traffic_factor
)

SELECT
    -- ==========================================
    -- Calculated KPIs
    -- ==========================================
    *,
    
    -- On-Time Rate
    ROUND(
        (on_time_deliveries * 100.0 / NULLIF(total_deliveries, 0)), 1
    ) AS on_time_rate_pct,
    
    -- Late Rate
    ROUND(
        (late_deliveries * 100.0 / NULLIF(total_deliveries, 0)), 1
    ) AS late_rate_pct,
    
    -- Failed Rate
    ROUND(
        (failed_deliveries * 100.0 / NULLIF(total_deliveries, 0)), 1
    ) AS failed_rate_pct,
    
    -- Profit Margin
    ROUND(
        (total_profit_pkr * 100.0 / NULLIF(total_revenue_pkr, 0)), 1
    ) AS profit_margin_pct,
    
    -- Revenue per delivery
    ROUND(
        (total_revenue_pkr * 1.0 / NULLIF(total_deliveries, 0)), 0
    ) AS revenue_per_delivery_pkr,
    
    -- Cost per delivery
    ROUND(
        ((total_driver_cost_pkr + total_platform_fee_pkr) * 1.0 / NULLIF(total_deliveries, 0)), 0
    ) AS cost_per_delivery_pkr,
    
    -- SLA Compliance
    ROUND(
        (COUNT(CASE WHEN fd.delivery_duration_min <= 35 THEN 1 END) * 100.0 / NULLIF(total_deliveries, 0)), 1
    ) AS sla_compliance_pct,
    
    -- Excellent rating rate
    ROUND(
        (excellent_ratings * 100.0 / NULLIF(total_deliveries, 0)), 1
    ) AS excellent_rating_rate_pct,
    
    -- Poor rating rate
    ROUND(
        (poor_ratings * 100.0 / NULLIF(total_deliveries, 0)), 1
    ) AS poor_rating_rate_pct,
    
    -- Digital payment adoption
    ROUND(
        (digital_payment_orders * 100.0 / NULLIF(total_deliveries, 0)), 1
    ) AS digital_payment_rate_pct,
    
    -- Bike utilization
    ROUND(
        (bike_deliveries * 100.0 / NULLIF(total_deliveries, 0)), 1
    ) AS bike_utilization_pct,
    
    -- Peak hour ratio
    ROUND(
        (peak_hour_deliveries * 100.0 / NULLIF(total_deliveries, 0)), 1
    ) AS peak_hour_ratio_pct,
    
    -- Week over Week growth
    ROUND(
        ((total_deliveries - LAG(total_deliveries, 7) OVER (
            PARTITION BY zone_id ORDER BY full_date
        )) * 100.0 / NULLIF(LAG(total_deliveries, 7) OVER (
            PARTITION BY zone_id ORDER BY full_date
        ), 0)), 1
    ) AS wow_growth_pct,
    
    -- Month over Month growth
    ROUND(
        ((total_deliveries - LAG(total_deliveries, 30) OVER (
            PARTITION BY zone_id ORDER BY full_date
        )) * 100.0 / NULLIF(LAG(total_deliveries, 30) OVER (
            PARTITION BY zone_id ORDER BY full_date
        ), 0)), 1
    ) AS mom_growth_pct,
    
    -- Day of week ranking
    RANK() OVER (
        PARTITION BY full_date 
        ORDER BY total_deliveries DESC
    ) AS zone_rank_by_volume,
    
    -- 7-day moving average
    ROUND(AVG(total_deliveries) OVER (
        PARTITION BY zone_id 
        ORDER BY full_date 
        ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
    ), 0) AS moving_avg_7d_deliveries,
    
    -- 30-day moving average
    ROUND(AVG(total_deliveries) OVER (
        PARTITION BY zone_id 
        ORDER BY full_date 
        ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
    ), 0) AS moving_avg_30d_deliveries,
    
    -- Performance score (composite index)
    ROUND(
        (on_time_rate_pct * 0.35) +
        (sla_compliance_pct * 0.25) +
        (excellent_rating_rate_pct * 0.20) +
        (profit_margin_pct * 0.15) +
        (digital_payment_rate_pct * 0.05)
    , 1) AS performance_score

FROM daily_base