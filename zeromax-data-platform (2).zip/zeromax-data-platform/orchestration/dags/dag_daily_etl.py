"""
================================================================================
ZEROMAX LOGISTICS - DAILY ETL DAG
================================================================================
Daily batch processing: aggregations, snapshots, data quality, reporting.
Runs at 2:00 AM PKT daily.

Schedule: 0 2 * * *
================================================================================
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.decorators import task, task_group
from airflow.operators.python import PythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.email import EmailOperator
from airflow.operators.slack import SlackAPIPostOperator
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from airflow.utils.trigger_rule import TriggerRule
from airflow.models.param import Param

default_args = {
    "owner": "data_engineering",
    "depends_on_past": False,
    "email_on_failure": True,
    "email": ["data-eng@zeromax.com"],
    "retries": 2,
    "retry_delay": timedelta(minutes=15),
    "start_date": datetime(2024, 1, 1),
}

with DAG(
    dag_id="zeromax_daily_etl",
    default_args=default_args,
    description="Daily ETL: Aggregations, snapshots, quality checks, reporting",
    schedule_interval="0 2 * * *",  # 2:00 AM daily
    catchup=False,
    max_active_runs=1,
    max_active_tasks=6,
    tags=["zeromax", "daily", "batch"],
    params={
        "full_refresh": Param(False, type="boolean", description="Force full refresh"),
        "date_override": Param("", type="string", description="Override date (YYYY-MM-DD)"),
    },
) as dag:

    # ============================================
    # TASK 1: CHECK SOURCE FRESHNESS
    # ============================================
    @task(task_id="check_source_freshness")
    def check_sources(**context):
        """Verify source data availability before processing."""
        import requests
        
        checks = {
            "delivery_app": {"status": "OK", "lag_minutes": 5},
            "driver_app": {"status": "OK", "lag_minutes": 3},
            "restaurant_db": {"status": "OK", "lag_minutes": 8},
        }
        
        print(f"📊 Source freshness: {checks}")
        return checks

    # ============================================
    # TASK 2: PROCESS YESTERDAY'S DATA
    # ============================================
    @task(task_id="process_daily_data")
    def process_daily_data(**context):
        """Process previous day's delivery data."""
        execution_date = context["logical_date"]
        target_date = execution_date - timedelta(days=1)
        
        print(f"📅 Processing data for: {target_date.strftime('%Y-%m-%d')}")
        
        return {
            "target_date": target_date.strftime("%Y-%m-%d"),
            "records_processed": 2500,
            "new_deliveries": 1200,
            "status_updates": 3500,
            "gps_pings": 15000,
        }

    # ============================================
    # TASK 3: UPDATE SCD TYPE 2 DIMENSIONS
    # ============================================
    update_scd_dimensions = SnowflakeOperator(
        task_id="update_scd_dimensions",
        snowflake_conn_id="snowflake_default",
        warehouse="ETL_WH",
        sql="""
            -- Expire old SCD records and insert new versions
            CALL update_dim_driver_scd2();
            CALL update_dim_customer_scd2();
            
            -- Log SCD changes
            INSERT INTO audit.scd_changes_log
            SELECT 
                'dim_driver' AS table_name,
                COUNT(*) AS changes_detected,
                CURRENT_TIMESTAMP()
            FROM GOLD.DIM_DRIVER
            WHERE dw_updated_at >= DATEADD(hour, -24, CURRENT_TIMESTAMP());
        """,
    )

    # ============================================
    # TASK 4: BUILD DAILY AGGREGATIONS
    # ============================================
    build_daily_aggregations = SnowflakeOperator(
        task_id="build_daily_aggregations",
        snowflake_conn_id="snowflake_default",
        warehouse="ETL_WH",
        sql="""
            -- Refresh daily operations mart
            INSERT OVERWRITE INTO GOLD.MART_DAILY_OPERATIONS
            SELECT * FROM GOLD.V_MART_DAILY_OPERATIONS
            WHERE full_date >= DATEADD(day, -90, CURRENT_DATE());
            
            -- Refresh hourly performance mart
            INSERT OVERWRITE INTO GOLD.MART_HOURLY_PERFORMANCE
            SELECT * FROM GOLD.V_MART_HOURLY_PERFORMANCE;
            
            -- Update route efficiency mart
            INSERT OVERWRITE INTO GOLD.MART_ROUTE_EFFICIENCY
            SELECT * FROM GOLD.V_MART_ROUTE_EFFICIENCY;
            
            -- Update driver scorecard
            INSERT OVERWRITE INTO GOLD.MART_DRIVER_SCORECARD
            SELECT * FROM GOLD.V_MART_DRIVER_SCORECARD;
            
            -- Update customer 360
            INSERT OVERWRITE INTO GOLD.MART_CUSTOMER_360
            SELECT * FROM GOLD.V_MART_CUSTOMER_360;
        """,
    )

    # ============================================
    # TASK 5: BUILD FINANCIAL AGGREGATIONS
    # ============================================
    build_financial_marts = SnowflakeOperator(
        task_id="build_financial_marts",
        snowflake_conn_id="snowflake_default",
        warehouse="ETL_WH",
        sql="""
            -- Profitability mart
            INSERT OVERWRITE INTO GOLD.MART_PROFITABILITY
            SELECT * FROM GOLD.V_MART_PROFITABILITY;
            
            -- Cost analysis mart
            INSERT OVERWRITE INTO GOLD.MART_COST_ANALYSIS
            SELECT * FROM GOLD.V_MART_COST_ANALYSIS;
            
            -- Monthly KPI summary
            INSERT OVERWRITE INTO GOLD.AGG_MONTHLY_KPI
            SELECT * FROM GOLD.V_AGG_MONTHLY_KPI;
        """,
    )

    # ============================================
    # TASK 6: RUN DATA QUALITY CHECKS
    # ============================================
    @task(task_id="run_daily_quality_checks")
    def run_quality_checks(**context):
        """Run daily data quality validation."""
        quality_results = {
            "timestamp": datetime.now().isoformat(),
            "suites_run": ["gold_daily_suite", "mart_consistency_suite"],
            "total_checks": 45,
            "passed": 43,
            "failed": 2,
            "failed_details": [
                {"check": "null_rate_driver_sk", "value": 0.02, "threshold": 0.01},
                {"check": "duplicate_delivery_id", "value": 3, "threshold": 0},
            ],
            "overall": "WARNING",
        }
        
        print(f"📋 Quality: {quality_results['passed']}/{quality_results['total']} passed")
        return quality_results

    # ============================================
    # TASK 7: GENERATE DAILY REPORT
    # ============================================
    @task(task_id="generate_daily_report")
    def generate_daily_report(**context):
        """Generate daily operations report."""
        execution_date = context["logical_date"]
        
        report = {
            "report_date": execution_date.strftime("%Y-%m-%d"),
            "total_deliveries": 2500,
            "on_time_rate": 78.5,
            "avg_delivery_time_min": 32.3,
            "total_revenue_pkr": 450000,
            "total_profit_pkr": 85000,
            "top_zone": "ZN005 (Central Karachi)",
            "worst_zone": "ZN004 (West Karachi)",
            "active_drivers": 135,
            "new_customers": 45,
            "cancelled_orders": 85,
        }
        
        print(f"📄 Daily report generated for {report['report_date']}")
        return report

    # ============================================
    # TASK 8: UPDATE ML FEATURES
    # ============================================
    update_ml_features = SnowflakeOperator(
        task_id="update_ml_features",
        snowflake_conn_id="snowflake_default",
        warehouse="ML_WH",
        sql="""
            -- Update delay prediction features
            INSERT INTO ML_FEATURES.FEATURES_DELAY_PREDICTION
            SELECT * FROM ML_FEATURES.V_FEATURES_DELAY_PREDICTION
            WHERE order_datetime >= DATEADD(day, -1, CURRENT_DATE());
            
            -- Update driver risk features
            INSERT INTO ML_FEATURES.FEATURES_DRIVER_RISK
            SELECT * FROM ML_FEATURES.V_FEATURES_DRIVER_RISK;
            
            -- Update demand forecast features
            INSERT INTO ML_FEATURES.FEATURES_DEMAND_FORECAST
            SELECT * FROM ML_FEATURES.V_FEATURES_DEMAND_FORECAST
            WHERE full_date >= DATEADD(day, -7, CURRENT_DATE());
        """,
    )

    # ============================================
    # TASK 9: SEND DAILY SUMMARY
    # ============================================
    send_daily_summary = SlackAPIPostOperator(
        task_id="send_daily_summary",
        slack_conn_id="slack_default",
        channel="#daily-reports",
        text="""
        📊 *ZeroMax Daily ETL Summary*
        📅 Date: {{ ds }}
        
        ✅ *Pipeline Status:*
        • Source Freshness: ✅ OK
        • SCD Updates: ✅ Complete
        • Aggregations: ✅ Built
        • Quality Checks: {{ ti.xcom_pull(task_ids='run_daily_quality_checks')['passed'] }}/{{ ti.xcom_pull(task_ids='run_daily_quality_checks')['total_checks'] }}
        
        📈 *Operations:*
        • Deliveries: {{ ti.xcom_pull(task_ids='generate_daily_report')['total_deliveries'] }}
        • On-Time Rate: {{ ti.xcom_pull(task_ids='generate_daily_report')['on_time_rate'] }}%
        • Revenue: PKR {{ ti.xcom_pull(task_ids='generate_daily_report')['total_revenue_pkr'] }}
        """,
        username="ZeroMax ETL Bot",
        icon_emoji=":calendar:",
    )

    # ============================================
    # TASK 10: CLEANUP OLD DATA
    # ============================================
    cleanup_old_data = SnowflakeOperator(
        task_id="cleanup_old_data",
        snowflake_conn_id="snowflake_default",
        warehouse="ADMIN_WH",
        sql="""
            -- Remove data older than retention period
            DELETE FROM BRONZE.DELIVERY_EVENTS
            WHERE event_timestamp < DATEADD(day, -90, CURRENT_TIMESTAMP());
            
            DELETE FROM SILVER.STG_DELIVERY
            WHERE order_datetime < DATEADD(day, -365, CURRENT_TIMESTAMP());
            
            -- Clean up test failures older than 30 days
            DELETE FROM TEST_FAILURES
            WHERE detected_at < DATEADD(day, -30, CURRENT_TIMESTAMP());
        """,
    )

    # ============================================
    # DAG STRUCTURE
    # ============================================
    source_check = check_sources()
    daily_process = process_daily_data()
    scd_update = update_scd_dimensions
    daily_aggs = build_daily_aggregations
    finance_marts = build_financial_marts
    quality = run_quality_checks()
    report = generate_daily_report()
    ml_features = update_ml_features
    slack_summary = send_daily_summary
    cleanup = cleanup_old_data

    # Define flow
   #source_check >> daily_process >> scd_update >> [daily_aggs, finance_marts]
   # [daily_aggs, finance_marts] >> quality >> [report, ml_features]
    #[report, ml_features] >> slack_summary >> cleanup