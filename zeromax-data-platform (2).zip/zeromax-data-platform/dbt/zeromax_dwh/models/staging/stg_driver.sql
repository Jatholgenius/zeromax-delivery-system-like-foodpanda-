{{
  config(
    materialized='table',
    cluster_by=['driver_id'],
    tags=['staging', 'silver', 'driver']
  )
}}

-- ============================================================
-- STAGING: STG_DRIVER
-- ============================================================
-- Bronze → Silver transformation for driver data.
-- ============================================================

WITH source AS (
    SELECT * FROM {{ source('bronze', 'driver_data') }}
),

-- Deduplicate
deduped AS (
    SELECT *
    FROM source
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY driver_id 
        ORDER BY updated_at DESC
    ) = 1
),

cleaned AS (
    SELECT
        -- Primary Key
        driver_id,
        
        -- Personal Info
        driver_name,
        phone,
        email,
        
        -- Experience
        CAST(experience_years AS DECIMAL(4,1)) AS experience_years,
        experience_level,
        
        -- Vehicle
        vehicle_type,
        vehicle_id,
        
        -- Zone
        home_zone,
        
        -- Performance
        CAST(base_rating AS DECIMAL(3,1)) AS base_rating,
        CAST(speed_factor AS DECIMAL(4,3)) AS speed_factor,
        CAST(efficiency_score AS DECIMAL(4,3)) AS efficiency_score,
        
        -- Status
        status,
        CAST(hire_date AS DATE) AS hire_date,
        
        -- Shift
        CAST(shift_start_hour AS INTEGER) AS shift_start_hour,
        CAST(shift_end_hour AS INTEGER) AS shift_end_hour,
        
        -- Metadata
        CAST(created_at AS TIMESTAMP) AS created_at,
        CAST(updated_at AS TIMESTAMP) AS updated_at,
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'stg_driver' AS dw_source
        
    FROM deduped
)

SELECT * FROM cleaned
WHERE driver_id IS NOT NULL
  AND driver_name IS NOT NULL
  AND experience_years >= 0
  AND base_rating BETWEEN 1.0 AND 5.0
  AND status IN ('Active', 'Inactive', 'On Leave')