"""
================================================================================
ZEROMAX LOGISTICS - GOOGLE MAPS API CONNECTOR
================================================================================
Provides geocoding, distance matrix, and route optimization.
Used for delivery route planning and distance calculations.

Usage:
    python maps_api.py
    python maps_api.py --geocode "North Nazimabad, Karachi"
    python maps_api.py --distance 24.9500,67.0500 24.8100,67.0300
================================================================================
"""

import os
import sys
import json
import time
import logging
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from pathlib import Path

import requests
import pandas as pd
import numpy as np
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ============================================
# CONFIGURATION
# ============================================

API_KEY = os.getenv("GOOGLE_MAPS_API_KEY", "")

GEOCODE_URL = "https://maps.googleapis.com/maps/api/geocode/json"
DISTANCE_URL = "https://maps.googleapis.com/maps/api/distancematrix/json"
DIRECTIONS_URL = "https://maps.googleapis.com/maps/api/directions/json"
PLACES_URL = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"

DATA_DIR = os.getenv("DATA_DIR", "data/bronze/maps_api")

# Karachi bounds
KARACHI_BOUNDS = {
    "northeast": {"lat": 25.1000, "lon": 67.3000},
    "southwest": {"lat": 24.7500, "lon": 66.9000},
}


class MapsAPIConnector:
    """
    Connector for Google Maps Platform APIs.
    Handles geocoding, routing, and distance calculations.
    """
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or API_KEY
        self.session = requests.Session()
        self.call_count = 0
        
        if not self.api_key:
            logger.warning("No API key. Using simulated/haversine calculations.")
    
    def _make_request(self, url: str, params: Dict) -> Optional[Dict]:
        """Make API request with error handling."""
        params["key"] = self.api_key
        
        try:
            response = self.session.get(url, params=params, timeout=15)
            self.call_count += 1
            
            if response.status_code == 200:
                return response.json()
            elif response.status_code == 429:
                logger.warning("Rate limited, waiting 30s...")
                time.sleep(30)
                return self._make_request(url, params)
            else:
                logger.error(f"API error {response.status_code}")
                return None
                
        except requests.RequestException as e:
            logger.error(f"Request failed: {e}")
            return None
    
    def geocode(self, address: str) -> Optional[Dict]:
        """
        Convert address to coordinates.
        
        Args:
            address: Address string to geocode
            
        Returns:
            Dict with lat, lng, formatted_address
        """
        params = {
            "address": f"{address}, Karachi, Pakistan",
            "bounds": f"{KARACHI_BOUNDS['southwest']['lat']},{KARACHI_BOUNDS['southwest']['lon']}|{KARACHI_BOUNDS['northeast']['lat']},{KARACHI_BOUNDS['northeast']['lon']}",
        }
        
        result = self._make_request(GEOCODE_URL, params)
        
        if result and result.get("results"):
            location = result["results"][0]
            return {
                "address": location.get("formatted_address"),
                "latitude": location["geometry"]["location"]["lat"],
                "longitude": location["geometry"]["location"]["lng"],
                "place_id": location.get("place_id"),
                "location_type": location["geometry"].get("location_type"),
            }
        
        return None
    
    def reverse_geocode(self, lat: float, lon: float) -> Optional[Dict]:
        """Convert coordinates to address."""
        params = {"latlng": f"{lat},{lon}"}
        
        result = self._make_request(GEOCODE_URL, params)
        
        if result and result.get("results"):
            location = result["results"][0]
            return {
                "address": location.get("formatted_address"),
                "place_id": location.get("place_id"),
                "address_components": location.get("address_components", []),
                "types": location.get("types", []),
            }
        
        return None
    
    def get_distance_matrix(
        self,
        origins: List[Tuple[float, float]],
        destinations: List[Tuple[float, float]],
        mode: str = "driving",
    ) -> Optional[pd.DataFrame]:
        """
        Get distance/duration matrix between multiple points.
        
        Args:
            origins: List of (lat, lon) tuples
            destinations: List of (lat, lon) tuples
            mode: Travel mode (driving, walking, bicycling)
            
        Returns:
            DataFrame with distance and duration
        """
        if not self.api_key:
            return self._calculate_haversine_matrix(origins, destinations)
        
        origins_str = "|".join([f"{lat},{lon}" for lat, lon in origins])
        destinations_str = "|".join([f"{lat},{lon}" for lat, lon in destinations])
        
        params = {
            "origins": origins_str,
            "destinations": destinations_str,
            "mode": mode,
            "departure_time": "now",
            "traffic_model": "best_guess",
        }
        
        result = self._make_request(DISTANCE_URL, params)
        
        if not result:
            return None
        
        records = []
        for i, origin in enumerate(origins):
            for j, destination in enumerate(destinations):
                element = result["rows"][i]["elements"][j]
                
                if element["status"] == "OK":
                    records.append({
                        "origin_lat": origin[0],
                        "origin_lon": origin[1],
                        "dest_lat": destination[0],
                        "dest_lon": destination[1],
                        "distance_km": element["distance"]["value"] / 1000,
                        "duration_min": element["duration"]["value"] / 60,
                        "duration_traffic_min": element.get("duration_in_traffic", {}).get("value", 0) / 60,
                    })
        
        return pd.DataFrame(records)
    
    def _calculate_haversine_matrix(
        self, origins: List, destinations: List
    ) -> pd.DataFrame:
        """Calculate straight-line distances using Haversine formula."""
        records = []
        
        for origin in origins:
            for destination in destinations:
                distance = self._haversine(
                    origin[0], origin[1], destination[0], destination[1]
                )
                # Add road factor (Karachi roads ~1.15x straight line)
                road_distance = distance * np.random.uniform(1.10, 1.20)
                
                records.append({
                    "origin_lat": origin[0],
                    "origin_lon": origin[1],
                    "dest_lat": destination[0],
                    "dest_lon": destination[1],
                    "distance_km": round(road_distance, 2),
                    "straight_line_km": round(distance, 2),
                    "duration_min": round(road_distance / 30 * 60, 0),  # Assume 30 km/h avg
                    "is_estimated": True,
                })
        
        return pd.DataFrame(records)
    
    def _haversine(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate Haversine distance in km."""
        from math import radians, sin, cos, sqrt, atan2
        
        R = 6371.0
        lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        
        return R * c
    
    def get_directions(
        self,
        origin: Tuple[float, float],
        destination: Tuple[float, float],
        waypoints: List[Tuple[float, float]] = None,
    ) -> Optional[Dict]:
        """
        Get turn-by-turn directions.
        
        Args:
            origin: Start point (lat, lon)
            destination: End point (lat, lon)
            waypoints: Optional intermediate stops
            
        Returns:
            Directions response with route details
        """
        params = {
            "origin": f"{origin[0]},{origin[1]}",
            "destination": f"{destination[0]},{destination[1]}",
            "mode": "driving",
            "departure_time": "now",
            "traffic_model": "best_guess",
            "alternatives": "true",
        }
        
        if waypoints:
            params["waypoints"] = "|".join([f"{lat},{lon}" for lat, lon in waypoints])
            params["optimize"] = "true"
        
        return self._make_request(DIRECTIONS_URL, params)
    
    def optimize_route(
        self,
        origin: Tuple[float, float],
        stops: List[Tuple[float, float]],
    ) -> Optional[Dict]:
        """
        Optimize delivery route with multiple stops.
        Uses waypoint optimization to find best order.
        
        Args:
            origin: Starting point
            stops: List of delivery stops
            
        Returns:
            Optimized route with stop order
        """
        # Use Google Maps Directions API with waypoint optimization
        result = self.get_directions(origin, origin, stops)  # Round trip
        
        if result and result.get("routes"):
            route = result["routes"][0]
            
            optimized_stops = []
            for leg in route.get("legs", []):
                optimized_stops.append({
                    "lat": leg["end_location"]["lat"],
                    "lon": leg["end_location"]["lng"],
                    "distance_km": leg["distance"]["value"] / 1000,
                    "duration_min": leg["duration"]["value"] / 60,
                    "duration_traffic_min": leg.get("duration_in_traffic", {}).get("value", 0) / 60,
                })
            
            return {
                "total_distance_km": sum(s["distance_km"] for s in optimized_stops),
                "total_duration_min": sum(s["duration_traffic_min"] or s["duration_min"] for s in optimized_stops),
                "optimized_stop_order": optimized_stops[:-1],  # Exclude return to origin
                "polyline": route.get("overview_polyline", {}).get("points"),
            }
        
        return None
    
    def nearby_restaurants(
        self, lat: float, lon: float, radius: int = 2000
    ) -> Optional[pd.DataFrame]:
        """Find nearby restaurants."""
        params = {
            "location": f"{lat},{lon}",
            "radius": radius,
            "type": "restaurant",
        }
        
        result = self._make_request(PLACES_URL, params)
        
        if result and result.get("results"):
            restaurants = []
            for place in result["results"]:
                restaurants.append({
                    "place_id": place.get("place_id"),
                    "name": place.get("name"),
                    "rating": place.get("rating"),
                    "vicinity": place.get("vicinity"),
                    "lat": place["geometry"]["location"]["lat"],
                    "lon": place["geometry"]["location"]["lng"],
                    "types": place.get("types", []),
                })
            
            return pd.DataFrame(restaurants)
        
        return None
    
    def validate_coordinates(self, lat: float, lon: float) -> bool:
        """Check if coordinates are within Karachi."""
        return (
            KARACHI_BOUNDS["southwest"]["lat"] <= lat <= KARACHI_BOUNDS["northeast"]["lat"]
            and KARACHI_BOUNDS["southwest"]["lon"] <= lon <= KARACHI_BOUNDS["northeast"]["lon"]
        )
    
    def save_to_bronze(self, data: Dict, data_type: str) -> str:
        """Save API response to Bronze layer."""
        output_dir = Path(DATA_DIR) / data_type / datetime.now().strftime("%Y/%m/%d")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        output_file = output_dir / f"{data_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(output_file, "w") as f:
            json.dump(data, f, indent=2, default=str)
        
        logger.info(f"✅ Saved to {output_file}")
        return str(output_file)


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Maps API Connector")
    parser.add_argument("--geocode", type=str, help="Address to geocode")
    parser.add_argument("--reverse", nargs=2, type=float, help="Reverse geocode lat lon")
    parser.add_argument("--distance", nargs=4, type=float, 
                       help="Distance between two points: lat1 lon1 lat2 lon2")
    parser.add_argument("--optimize", action="store_true", help="Test route optimization")
    args = parser.parse_args()
    
    connector = MapsAPIConnector()
    
    if args.geocode:
        result = connector.geocode(args.geocode)
        print(json.dumps(result, indent=2))
    
    elif args.reverse:
        result = connector.reverse_geocode(args.reverse[0], args.reverse[1])
        print(json.dumps(result, indent=2))
    
    elif args.distance:
        origin = [(args.distance[0], args.distance[1])]
        dest = [(args.distance[2], args.distance[3])]
        df = connector.get_distance_matrix(origin, dest)
        print(df.to_string())
    
    elif args.optimize:
        origin = (24.8600, 67.0100)
        stops = [
            (24.8700, 67.0300),
            (24.8900, 67.0500),
            (24.8500, 67.0200),
            (24.8800, 67.0400),
        ]
        result = connector.optimize_route(origin, stops)
        print(json.dumps(result, indent=2, default=str))
    
    else:
        logger.info("No action specified. Use --help for options.")


if __name__ == "__main__":
    main()