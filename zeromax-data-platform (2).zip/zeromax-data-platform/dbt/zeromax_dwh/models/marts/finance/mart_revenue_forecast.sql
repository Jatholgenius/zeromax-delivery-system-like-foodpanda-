{{
  config(
    materialized='table',
    cluster_by=['forecast_month'],
    tags=['gold', 'finance', 'forecast', 'ml_based'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE finance_analyst",
      "GRANT SELECT ON {{ this }} TO ROLE executive"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: MART_REVENUE_FORECAST
-- ============================================================
-- Revenue and demand forecasting using historical trends.
-- Incorporates seasonality, Ramadan, Eid, and growth factors.
-- ============================================================

WITH historical_monthly AS (
    SELECT
        DATE_TRUNC('month', fd.order_datetime) AS month,
        EXTRACT(YEAR FROM fd.order_datetime) AS year,
        EXTRACT(MONTH FROM fd.order_datetime) AS month_num,
        
        -- Volume
        COUNT(DISTINCT fd.delivery_sk) AS total_deliveries,
        COUNT(DISTINCT fd.customer_sk) AS unique_customers,
        COUNT(DISTINCT fd.driver_sk) AS active_drivers,
        
        -- Revenue
        SUM(fd.delivery_fee_pkr) AS total_revenue,
        SUM(fd.profit_pkr) AS total_profit,
        ROUND(AVG(fd.delivery_fee_pkr), 0) AS avg_order_value,
        
        -- Distance
        SUM(fd.distance_km) AS total_distance_km,
        ROUND(AVG(fd.distance_km), 2) AS avg_distance_km,
        
        -- Environmental
        ROUND(AVG(fd.weather_severity), 1) AS avg_weather_severity,
        ROUND(AVG(fd.traffic_severity), 1) AS avg_traffic_severity,
        
        -- Flags
        MAX(CASE WHEN fd.is_ramadan THEN 1 ELSE 0 END) AS is_ramadan_month,
        MAX(CASE WHEN fd.is_eid THEN 1 ELSE 0 END) AS is_eid_month
        
    FROM {{ ref('fct_delivery') }} fd
    WHERE fd.order_datetime >= '2024-01-01'
    GROUP BY DATE_TRUNC('month', fd.order_datetime),
             EXTRACT(YEAR FROM fd.order_datetime),
             EXTRACT(MONTH FROM fd.order_datetime)
),

-- Calculate growth rates and moving averages
with_trends AS (
    SELECT
        *,
        
        -- 3-month moving average
        ROUND(AVG(total_revenue) OVER (
            ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
        ), 0) AS revenue_3m_ma,
        
        ROUND(AVG(total_deliveries) OVER (
            ORDER BY month ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
        ), 0) AS deliveries_3m_ma,
        
        -- Month over Month growth
        ROUND(
            (total_revenue - LAG(total_revenue) OVER (ORDER BY month)) * 100.0 
            / NULLIF(LAG(total_revenue) OVER (ORDER BY month), 0), 1
        ) AS mom_revenue_growth_pct,
        
        -- Year over Year growth (if available)
        ROUND(
            (total_revenue - LAG(total_revenue, 12) OVER (ORDER BY month)) * 100.0 
            / NULLIF(LAG(total_revenue, 12) OVER (ORDER BY month), 0), 1
        ) AS yoy_revenue_growth_pct,
        
        -- Average growth rate
        ROUND(AVG(
            (total_revenue - LAG(total_revenue) OVER (ORDER BY month)) * 100.0 
            / NULLIF(LAG(total_revenue) OVER (ORDER BY month), 0)
        ) OVER (), 1) AS avg_monthly_growth_pct
        
    FROM historical_monthly
),

-- Generate forecast for next 3 months
forecast_base AS (
    SELECT
        *,
        
        -- Forecast deliveries using trend + seasonality
        ROUND(
            deliveries_3m_ma * 
            (1 + (avg_monthly_growth_pct / 100.0)) *
            CASE 
                WHEN month_num IN (3, 4) THEN 1.35  -- Ramadan boost
                WHEN month_num IN (6) THEN 1.20      -- Eid boost
                WHEN month_num IN (5, 6, 7, 8) THEN 1.10  -- Summer
                WHEN month_num IN (12) THEN 1.15     -- Year end
                ELSE 1.00
            END
        , 0) AS forecast_deliveries,
        
        -- Forecast revenue
        ROUND(
            revenue_3m_ma * 
            (1 + (avg_monthly_growth_pct / 100.0)) *
            CASE 
                WHEN month_num IN (3, 4) THEN 1.40
                WHEN month_num IN (6) THEN 1.25
                WHEN month_num IN (5, 6, 7, 8) THEN 1.12
                WHEN month_num IN (12) THEN 1.18
                ELSE 1.00
            END
        , 0) AS forecast_revenue,
        
        -- Forecast profit (assume margin improvement)
        ROUND(
            (revenue_3m_ma * (total_profit * 1.0 / NULLIF(total_revenue, 0)) + 0.02) * 
            (1 + (avg_monthly_growth_pct / 100.0))
        , 0) AS forecast_profit
        
    FROM with_trends
)

SELECT
    month AS forecast_month,
    year,
    month_num,
    
    -- Actual values
    total_deliveries AS actual_deliveries,
    total_revenue AS actual_revenue,
    total_profit AS actual_profit,
    avg_order_value,
    
    -- Moving averages
    revenue_3m_ma,
    deliveries_3m_ma,
    
    -- Growth rates
    mom_revenue_growth_pct,
    yoy_revenue_growth_pct,
    avg_monthly_growth_pct,
    
    -- Forecasts
    forecast_deliveries,
    forecast_revenue,
    forecast_profit,
    
    -- Forecast accuracy (for past months where we have actuals)
    ROUND(
        ABS(forecast_revenue - total_revenue) * 100.0 / NULLIF(total_revenue, 0), 1
    ) AS forecast_error_pct,
    
    -- Confidence interval (wider for further forecasts)
    CASE
        WHEN month <= CURRENT_DATE() THEN 0
        WHEN month <= DATEADD(month, 1, CURRENT_DATE()) THEN 5
        WHEN month <= DATEADD(month, 2, CURRENT_DATE()) THEN 10
        ELSE 15
    END AS forecast_confidence_band_pct,
    
    -- Forecast range
    ROUND(forecast_revenue * (1 - forecast_confidence_band_pct / 100.0), 0) AS forecast_revenue_low,
    ROUND(forecast_revenue * (1 + forecast_confidence_band_pct / 100.0), 0) AS forecast_revenue_high,
    
    -- Seasonality flags
    is_ramadan_month,
    is_eid_month,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'mart_revenue_forecast' AS dw_source

FROM forecast_base
ORDER BY month