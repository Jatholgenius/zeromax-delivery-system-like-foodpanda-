"""
================================================================================
ZEROMAX LOGISTICS - ML TRAINING DAG
================================================================================
Scheduled ML model training and evaluation pipeline.
Runs weekly on Sunday at 6:00 AM PKT.

Schedule: 0 6 * * 0
================================================================================
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.decorators import task, task_group
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.slack import SlackAPIPostOperator
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from airflow.utils.trigger_rule import TriggerRule
from airflow.models.param import Param

default_args = {
    "owner": "ml_team",
    "depends_on_past": False,
    "email_on_failure": True,
    "email": ["ml-eng@zeromax.com"],
    "retries": 2,
    "retry_delay": timedelta(minutes=15),
    "start_date": datetime(2024, 1, 7),
}

with DAG(
    dag_id="zeromax_ml_training",
    default_args=default_args,
    description="Weekly ML model training pipeline",
    schedule_interval="0 6 * * 0",
    catchup=False,
    max_active_runs=1,
    tags=["zeromax", "ml", "training"],
    params={
        "full_training": Param(True, type="boolean"),
        "deploy_to_production": Param(False, type="boolean"),
    },
) as dag:

    # ============================================
    # TASK 1: EXTRACT TRAINING DATA
    # ============================================
    extract_features = SnowflakeOperator(
        task_id="extract_training_features",
        snowflake_conn_id="snowflake_default",
        warehouse="ML_WH",
        sql="""
            -- Extract delay prediction features
            CREATE OR REPLACE TABLE ML_TRAINING.delay_prediction_data AS
            SELECT * FROM ML_FEATURES.FEATURES_DELAY_PREDICTION
            WHERE order_datetime >= DATEADD(month, -3, CURRENT_DATE())
              AND target_delay_min IS NOT NULL;
            
            -- Extract driver risk features
            CREATE OR REPLACE TABLE ML_TRAINING.driver_risk_data AS
            SELECT * FROM ML_FEATURES.FEATURES_DRIVER_RISK
            WHERE target_performance_decline IS NOT NULL;
            
            -- Extract demand forecast features
            CREATE OR REPLACE TABLE ML_TRAINING.demand_forecast_data AS
            SELECT * FROM ML_FEATURES.FEATURES_DEMAND_FORECAST
            WHERE full_date >= DATEADD(month, -6, CURRENT_DATE());
            
            SELECT 
                (SELECT COUNT(*) FROM ML_TRAINING.delay_prediction_data) AS delay_rows,
                (SELECT COUNT(*) FROM ML_TRAINING.driver_risk_data) AS driver_rows,
                (SELECT COUNT(*) FROM ML_TRAINING.demand_forecast_data) AS forecast_rows;
        """,
    )

    # ============================================
    # TASK 2: TRAIN DELAY PREDICTION MODEL
    # ============================================
    @task(task_id="train_delay_prediction")
    def train_delay_prediction(**context):
        """Train XGBoost model for delivery delay prediction."""
        import numpy as np
        import json
        
        # Simulated training process
        training_result = {
            "model": "XGBoost Regressor",
            "target": "delay_min",
            "training_samples": 45000,
            "validation_samples": 5000,
            "features_used": 35,
            "training_time_sec": 120,
            "metrics": {
                "rmse": 5.2,
                "mae": 3.8,
                "r2_score": 0.82,
                "rmse_previous": 5.5,
                "improvement_pct": 5.5,
            },
            "feature_importance": {
                "distance_km": 0.25,
                "traffic_severity": 0.18,
                "weather_severity": 0.15,
                "is_peak_hour": 0.12,
                "experience_level": 0.10,
                "preparation_time_min": 0.08,
                "is_weekend": 0.07,
                "vehicle_category": 0.05,
            },
            "model_version": f"delay_v{datetime.now().strftime('%Y.%m.%d')}",
        }
        
        print(f"✅ Delay prediction model trained: RMSE={training_result['metrics']['rmse']}")
        return training_result

    # ============================================
    # TASK 3: TRAIN DRIVER SCORING MODEL
    # ============================================
    @task(task_id="train_driver_scoring")
    def train_driver_scoring(**context):
        """Train model for driver performance scoring."""
        
        training_result = {
            "model": "Random Forest Classifier",
            "target": "performance_decline",
            "training_samples": 150,
            "features_used": 20,
            "training_time_sec": 30,
            "metrics": {
                "accuracy": 0.89,
                "precision": 0.85,
                "recall": 0.82,
                "f1_score": 0.83,
            },
            "model_version": f"driver_v{datetime.now().strftime('%Y.%m.%d')}",
        }
        
        print(f"✅ Driver scoring model trained: Accuracy={training_result['metrics']['accuracy']:.2%}")
        return training_result

    # ============================================
    # TASK 4: TRAIN DEMAND FORECAST MODEL
    # ============================================
    @task(task_id="train_demand_forecast")
    def train_demand_forecast(**context):
        """Train Prophet model for demand forecasting."""
        
        training_result = {
            "model": "Prophet + XGBoost Ensemble",
            "target": "hourly_order_count",
            "training_samples": 48000,
            "forecast_horizon": "7 days",
            "training_time_sec": 180,
            "metrics": {
                "mape": 12.5,
                "rmse": 8.3,
                "mae": 5.6,
                "mape_previous": 14.2,
                "improvement_pct": 12.0,
            },
            "seasonality_detected": {
                "daily": True,
                "weekly": True,
                "ramadan_effect": True,
                "eid_effect": True,
            },
            "model_version": f"forecast_v{datetime.now().strftime('%Y.%m.%d')}",
        }
        
        print(f"✅ Demand forecast model trained: MAPE={training_result['metrics']['mape']}%")
        return training_result

    # ============================================
    # TASK 5: MODEL EVALUATION
    # ============================================
    @task(task_id="evaluate_models")
    def evaluate_models(**context):
        """Compare new models vs production models."""
        ti = context["task_instance"]
        
        delay_model = ti.xcom_pull(task_ids="train_delay_prediction")
        driver_model = ti.xcom_pull(task_ids="train_driver_scoring")
        forecast_model = ti.xcom_pull(task_ids="train_demand_forecast")
        
        evaluation = {
            "delay_prediction": {
                "improvement": delay_model["metrics"]["improvement_pct"] if delay_model else 0,
                "promote": delay_model["metrics"]["improvement_pct"] > 2.0 if delay_model else False,
            },
            "driver_scoring": {
                "accuracy": driver_model["metrics"]["accuracy"] if driver_model else 0,
                "promote": driver_model["metrics"]["accuracy"] > 0.85 if driver_model else False,
            },
            "demand_forecast": {
                "improvement": forecast_model["metrics"]["improvement_pct"] if forecast_model else 0,
                "promote": forecast_model["metrics"]["improvement_pct"] > 5.0 if forecast_model else False,
            },
        }
        
        promote_count = sum(1 for v in evaluation.values() if v.get("promote"))
        print(f"📊 Models to promote: {promote_count}/3")
        
        return evaluation

    # ============================================
    # TASK 6: DECISION - PROMOTE MODELS?
    # ============================================
    @task(task_id="promotion_decision", trigger_rule=TriggerRule.ALL_DONE)
    def promotion_decision(**context):
        """Decide which models to promote to production."""
        ti = context["task_instance"]
        evaluation = ti.xcom_pull(task_ids="evaluate_models")
        
        if not evaluation:
            return "skip_promotion"
        
        models_to_promote = [k for k, v in evaluation.items() if v.get("promote")]
        
        if models_to_promote:
            context["task_instance"].xcom_push(
                key="models_to_promote", value=models_to_promote
            )
            return "promote_models"
        else:
            return "skip_promotion"

    # ============================================
    # TASK 7: PROMOTE MODELS
    # ============================================
    @task(task_id="promote_models")
    def promote_models(**context):
        """Promote new models to production."""
        ti = context["task_instance"]
        models = ti.xcom_pull(key="models_to_promote", task_ids="promotion_decision")
        
        if not models:
            return {"promoted": []}
        
        for model_name in models:
            # Register in MLflow
            print(f"🚀 Promoting {model_name} to production...")
        
        return {"promoted": models, "timestamp": datetime.now().isoformat()}

    # ============================================
    # TASK 8: REGISTER TO MLFLOW
    # ============================================
    @task(task_id="register_to_mlflow")
    def register_to_mlflow(**context):
        """Register trained models in MLflow."""
        models = {
            "delay_prediction": {
                "registered": True,
                "version": f"v{datetime.now().strftime('%Y.%m.%d')}",
                "stage": "Staging",
            },
            "driver_scoring": {
                "registered": True,
                "version": f"v{datetime.now().strftime('%Y.%m.%d')}",
                "stage": "Staging",
            },
            "demand_forecast": {
                "registered": True,
                "version": f"v{datetime.now().strftime('%Y.%m.%d')}",
                "stage": "Staging",
            },
        }
        
        print(f"📦 Registered {len(models)} models to MLflow")
        return models

    # ============================================
    # TASK 9: NOTIFICATIONS
    # ============================================
    send_success_notification = SlackAPIPostOperator(
        task_id="send_success_notification",
        slack_conn_id="slack_default",
        channel="#ml-training",
        text="""
        🤖 *ML Training Complete*
        📅 Date: {{ ds }}
        
        *Delay Prediction:*
        RMSE: {{ ti.xcom_pull(task_ids='train_delay_prediction')['metrics']['rmse'] }}
        Improvement: {{ ti.xcom_pull(task_ids='train_delay_prediction')['metrics']['improvement_pct'] }}%
        
        *Driver Scoring:*
        Accuracy: {{ (ti.xcom_pull(task_ids='train_driver_scoring')['metrics']['accuracy'] * 100) | round(1) }}%
        
        *Demand Forecast:*
        MAPE: {{ ti.xcom_pull(task_ids='train_demand_forecast')['metrics']['mape'] }}%
        Improvement: {{ ti.xcom_pull(task_ids='train_demand_forecast')['metrics']['improvement_pct'] }}%
        
        Models registered to MLflow Staging.
        """,
        username="ML Training Bot",
        icon_emoji=":robot_face:",
    )

    # ============================================
    # DAG STRUCTURE
    # ============================================
    extract = extract_features
    
    delay_train = train_delay_prediction()
    driver_train = train_driver_scoring()
    forecast_train = train_demand_forecast()
    
    evaluation = evaluate_models()
    decision = promotion_decision()
    promotion = promote_models()
    skip_promotion = BashOperator(
        task_id="skip_promotion",
        bash_command="echo 'No models to promote'",
    )
    mlflow_registry = register_to_mlflow()
    notification = send_success_notification

    # extract >> [delay_train, driver_train, forecast_train] >> evaluation >> decision
    # decision >> [promotion, skip_promotion]
    # [promotion, skip_promotion] >> mlflow_registry >> notification