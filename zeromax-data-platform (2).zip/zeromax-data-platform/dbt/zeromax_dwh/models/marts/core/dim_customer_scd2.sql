{{
  config(
    materialized='table',
    cluster_by=['customer_id'],
    tags=['gold', 'dimension', 'scd_type2', 'customer', 'pii'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter",
      "GRANT SELECT ON {{ this }} TO ROLE analyst"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: DIM_CUSTOMER (SCD Type 2)
-- ============================================================
-- Slowly Changing Dimension Type 2 for customers.
-- Tracks: name changes, address updates, loyalty tier upgrades,
--          preference changes, contact info updates.
-- ============================================================

WITH current_source AS (
    SELECT
        customer_id,
        customer_name,
        phone,
        email,
        zone_id,
        zone_name,
        area,
        address,
        latitude,
        longitude,
        customer_type,
        loyalty_tier,
        join_date,
        last_order_date,
        total_orders_lifetime,
        total_spent_lifetime,
        avg_rating_given,
        preferred_payment,
        preferred_cuisine,
        dietary_preferences,
        is_marketing_opt_in,
        preferred_contact_method,
        
        -- Change detection hash (exclude metrics that always change)
        MD5(
            CONCAT_WS('|',
                COALESCE(customer_name, ''),
                COALESCE(phone, ''),
                COALESCE(email, ''),
                COALESCE(zone_id, ''),
                COALESCE(area, ''),
                COALESCE(address, ''),
                COALESCE(customer_type, ''),
                COALESCE(loyalty_tier, ''),
                COALESCE(preferred_payment, ''),
                COALESCE(preferred_cuisine, ''),
                COALESCE(dietary_preferences, ''),
                COALESCE(CAST(is_marketing_opt_in AS VARCHAR), ''),
                COALESCE(preferred_contact_method, '')
            )
        ) AS row_hash,
        
        updated_at AS source_updated_at
        
    FROM {{ ref('stg_customer') }}
    WHERE customer_id IS NOT NULL
),

existing_latest AS (
    SELECT * FROM {{ this }}
    WHERE is_current = TRUE
),

new_customers AS (
    SELECT
        cs.*,
        'INSERT' AS dml_type,
        {{ dbt_utils.generate_surrogate_key(['cs.customer_id', 'cs.source_updated_at']) }} AS customer_sk
    FROM current_source cs
    LEFT JOIN existing_latest el
        ON cs.customer_id = el.customer_id
    WHERE el.customer_id IS NULL
),

changed_customers AS (
    SELECT
        cs.*,
        'UPDATE' AS dml_type,
        el.customer_sk
    FROM current_source cs
    INNER JOIN existing_latest el
        ON cs.customer_id = el.customer_id
    WHERE cs.row_hash != el.row_hash
),

unchanged_customers AS (
    SELECT
        el.*,
        'NO_CHANGE' AS dml_type
    FROM existing_latest el
    INNER JOIN current_source cs
        ON el.customer_id = cs.customer_id
    WHERE cs.row_hash = el.row_hash
),

all_records AS (
    SELECT
        customer_sk,
        customer_id,
        customer_name,
        phone,
        email,
        zone_id,
        zone_name,
        area,
        address,
        latitude,
        longitude,
        customer_type,
        loyalty_tier,
        join_date,
        last_order_date,
        total_orders_lifetime,
        total_spent_lifetime,
        avg_rating_given,
        preferred_payment,
        preferred_cuisine,
        dietary_preferences,
        is_marketing_opt_in,
        preferred_contact_method,
        row_hash,
        dml_type,
        CURRENT_TIMESTAMP() AS valid_from,
        TO_TIMESTAMP('9999-12-31 23:59:59') AS valid_to,
        TRUE AS is_current,
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'dim_customer_scd2' AS dw_source
    FROM new_customers
    
    UNION ALL
    
    SELECT
        customer_sk,
        customer_id,
        customer_name,
        phone,
        email,
        zone_id,
        zone_name,
        area,
        address,
        latitude,
        longitude,
        customer_type,
        loyalty_tier,
        join_date,
        last_order_date,
        total_orders_lifetime,
        total_spent_lifetime,
        avg_rating_given,
        preferred_payment,
        preferred_cuisine,
        dietary_preferences,
        is_marketing_opt_in,
        preferred_contact_method,
        row_hash,
        dml_type,
        CURRENT_TIMESTAMP() AS valid_from,
        TO_TIMESTAMP('9999-12-31 23:59:59') AS valid_to,
        TRUE AS is_current,
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'dim_customer_scd2' AS dw_source
    FROM changed_customers
    
    UNION ALL
    
    SELECT
        customer_sk,
        customer_id,
        customer_name,
        phone,
        email,
        zone_id,
        zone_name,
        area,
        address,
        latitude,
        longitude,
        customer_type,
        loyalty_tier,
        join_date,
        last_order_date,
        total_orders_lifetime,
        total_spent_lifetime,
        avg_rating_given,
        preferred_payment,
        preferred_cuisine,
        dietary_preferences,
        is_marketing_opt_in,
        preferred_contact_method,
        row_hash,
        dml_type,
        valid_from,
        valid_to,
        is_current,
        dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'dim_customer_scd2' AS dw_source
    FROM unchanged_customers
)

SELECT
    customer_sk,
    customer_id,
    customer_name,
    phone,
    email,
    zone_id,
    zone_name,
    area,
    address,
    latitude,
    longitude,
    customer_type,
    loyalty_tier,
    join_date,
    last_order_date,
    total_orders_lifetime,
    total_spent_lifetime,
    avg_rating_given,
    preferred_payment,
    preferred_cuisine,
    dietary_preferences,
    is_marketing_opt_in,
    preferred_contact_method,
    
    -- Derived
    DATEDIFF('day', join_date, CURRENT_DATE()) AS customer_tenure_days,
    
    CASE
        WHEN total_orders_lifetime >= 100 THEN 'Power User'
        WHEN total_orders_lifetime >= 50 THEN 'Frequent'
        WHEN total_orders_lifetime >= 20 THEN 'Regular'
        WHEN total_orders_lifetime >= 5 THEN 'Occasional'
        ELSE 'New'
    END AS order_frequency_category,
    
    CASE
        WHEN avg_rating_given >= 4.5 THEN 'Highly Satisfied'
        WHEN avg_rating_given >= 4.0 THEN 'Satisfied'
        WHEN avg_rating_given >= 3.0 THEN 'Neutral'
        ELSE 'Dissatisfied'
    END AS satisfaction_category,
    
    valid_from,
    valid_to,
    is_current,
    row_hash,
    dml_type AS change_type,
    dw_created_at,
    dw_updated_at,
    dw_source

FROM all_records

QUALIFY ROW_NUMBER() OVER (
    PARTITION BY customer_id 
    ORDER BY valid_from DESC
) = 1