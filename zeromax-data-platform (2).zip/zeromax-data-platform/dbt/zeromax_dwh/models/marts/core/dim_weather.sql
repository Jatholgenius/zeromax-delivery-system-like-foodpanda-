{{
  config(
    materialized='table',
    tags=['gold', 'dimension', 'weather', 'reference'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: DIM_WEATHER
-- ============================================================
-- Weather condition reference dimension.
-- Maps weather types to severity and delay multipliers.
-- ============================================================

WITH weather_conditions AS (
    SELECT * FROM (VALUES
        ('Clear', 1, 1.00, 'Clear skies, optimal delivery conditions'),
        ('Sunny', 1, 1.00, 'Sunny and clear'),
        ('Partly Cloudy', 1, 1.00, 'Partly cloudy, no impact'),
        ('Cloudy', 1, 1.05, 'Overcast, slight visibility reduction'),
        ('Drizzle', 2, 1.15, 'Light rain, minor road wetness'),
        ('Light Rain', 2, 1.20, 'Light rain, reduced visibility'),
        ('Rain', 3, 1.35, 'Moderate rain, wet roads, slower traffic'),
        ('Heavy Rain', 4, 1.50, 'Heavy rainfall, significant delays'),
        ('Fog', 3, 1.50, 'Dense fog, very low visibility'),
        ('Dust Storm', 3, 1.40, 'Dust storm, hazardous conditions'),
        ('Hot Wind', 2, 1.20, 'Hot dry winds, discomfort'),
        ('Thunderstorm', 4, 1.70, 'Thunderstorms, dangerous conditions'),
        ('Extreme Heat', 3, 1.25, 'Temperatures above 42°C'),
        ('Hail', 4, 1.60, 'Hailstorm, dangerous for bikes')
    ) AS w(condition, severity, delay_multiplier, description)
)

SELECT
    -- Surrogate Key
    ROW_NUMBER() OVER (ORDER BY severity, condition) AS weather_sk,
    
    -- Weather Attributes
    condition AS weather_condition,
    severity AS severity_level,
    delay_multiplier AS weather_delay_multiplier,
    description AS weather_description,
    
    -- Severity Classification
    CASE
        WHEN severity = 1 THEN 'Favorable'
        WHEN severity = 2 THEN 'Minor Impact'
        WHEN severity = 3 THEN 'Moderate Impact'
        WHEN severity = 4 THEN 'Severe Impact'
    END AS severity_category,
    
    -- Delivery Impact
    CASE
        WHEN delay_multiplier <= 1.00 THEN 'No Impact'
        WHEN delay_multiplier <= 1.20 THEN 'Low Impact'
        WHEN delay_multiplier <= 1.40 THEN 'Medium Impact'
        WHEN delay_multiplier <= 1.60 THEN 'High Impact'
        ELSE 'Extreme Impact'
    END AS delivery_impact,
    
    -- Is Dangerous
    CASE WHEN severity >= 4 THEN TRUE ELSE FALSE END AS is_dangerous,
    
    -- Is Favorable
    CASE WHEN severity = 1 THEN TRUE ELSE FALSE END AS is_favorable,
    
    -- Recommended Action
    CASE
        WHEN severity = 1 THEN 'Normal Operations'
        WHEN severity = 2 THEN 'Slight Caution'
        WHEN severity = 3 THEN 'Reduce Speed, Extra Time'
        WHEN severity = 4 THEN 'Suspend Operations if Necessary'
    END AS recommended_action,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'dim_weather' AS dw_source

FROM weather_conditions