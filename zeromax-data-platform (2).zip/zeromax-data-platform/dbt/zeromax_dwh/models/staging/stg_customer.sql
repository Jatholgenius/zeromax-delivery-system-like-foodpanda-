{{
  config(
    materialized='table',
    cluster_by=['customer_id'],
    tags=['staging', 'silver', 'customer', 'pii']
  )
}}

-- ============================================================
-- STAGING: STG_CUSTOMER
-- ============================================================
-- Bronze → Silver transformation for customer data.
-- Contains PII - restrict access appropriately.
-- ============================================================

WITH source AS (
    SELECT * FROM {{ source('bronze', 'customer_data') }}
),

-- Deduplicate by customer_id (keep latest)
deduped AS (
    SELECT *
    FROM source
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY customer_id 
        ORDER BY updated_at DESC
    ) = 1
),

cleaned AS (
    SELECT
        -- Primary Key
        customer_id,
        
        -- Personal Info (PII - mask in non-production)
        customer_name,
        phone,
        CASE 
            WHEN '{{ target.name }}' NOT IN ('prod', 'production') 
            THEN MASK_EMAIL(email) 
            ELSE email 
        END AS email,
        
        -- Location
        zone_id,
        zone_name,
        area,
        address,
        
        -- Coordinates
        CAST(lat AS DECIMAL(10,6)) AS latitude,
        CAST(lon AS DECIMAL(10,6)) AS longitude,
        
        -- Customer Classification
        customer_type,
        loyalty_tier,
        
        -- Account Dates
        CAST(join_date AS DATE) AS join_date,
        CAST(last_order_date AS DATE) AS last_order_date,
        
        -- Order History
        CAST(total_orders_lifetime AS INTEGER) AS total_orders_lifetime,
        CAST(total_spent_lifetime AS DECIMAL(12,2)) AS total_spent_lifetime,
        
        -- Rating Behavior
        CAST(avg_rating_given AS DECIMAL(3,1)) AS avg_rating_given,
        
        -- Preferences
        preferred_payment,
        preferred_cuisine,
        dietary_preferences,
        
        -- Communication
        is_marketing_opt_in,
        preferred_contact_method,
        
        -- Metadata
        CAST(created_at AS TIMESTAMP) AS created_at,
        CAST(updated_at AS TIMESTAMP) AS updated_at,
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'stg_customer' AS dw_source
        
    FROM deduped
)

SELECT * FROM cleaned
WHERE customer_id IS NOT NULL
  AND customer_name IS NOT NULL
  AND latitude BETWEEN 24.7 AND 25.1  -- Karachi bounds
  AND longitude BETWEEN 66.8 AND 67.3
  AND join_date IS NOT NULL
  AND total_orders_lifetime >= 0