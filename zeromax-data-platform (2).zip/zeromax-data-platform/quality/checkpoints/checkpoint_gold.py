"""
================================================================================
ZEROMAX LOGISTICS - GOLD LAYER CHECKPOINT
================================================================================
Great Expectations checkpoint for validating Gold layer tables.
Validates: fct_delivery, dim_driver, dim_customer, mart_* tables.

Usage:
    great_expectations checkpoint run checkpoint_gold
    python quality/checkpoints/checkpoint_gold.py
================================================================================
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional

from great_expectations.checkpoint import Checkpoint
from great_expectations.data_context import BaseDataContext
from great_expectations.data_context.types.base import (
    DataContextConfig,
    CheckpointConfig,
)
from great_expectations.core.batch import BatchRequest
from great_expectations.checkpoint.types.checkpoint_result import CheckpointResult

# Add project root to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ============================================
# CONFIGURATION
# ============================================

GOLD_TABLES = {
    "fct_delivery": {
        "schema": "GOLD",
        "table": "FCT_DELIVERY",
        "suite": "gold_fct_delivery_suite",
        "critical": True,
    },
    "dim_driver": {
        "schema": "GOLD",
        "table": "DIM_DRIVER",
        "suite": "gold_dim_driver_suite",
        "critical": True,
    },
    "dim_customer": {
        "schema": "GOLD",
        "table": "DIM_CUSTOMER",
        "suite": "gold_dim_customer_suite",
        "critical": True,
    },
    "dim_restaurant": {
        "schema": "GOLD",
        "table": "DIM_RESTAURANT",
        "suite": "gold_dim_restaurant_suite",
        "critical": False,
    },
    "dim_zone": {
        "schema": "GOLD",
        "table": "DIM_ZONE",
        "suite": "gold_dim_zone_suite",
        "critical": False,
    },
    "dim_date": {
        "schema": "GOLD",
        "table": "DIM_DATE",
        "suite": "gold_dim_date_suite",
        "critical": False,
    },
    "mart_daily_operations": {
        "schema": "GOLD",
        "table": "MART_DAILY_OPERATIONS",
        "suite": "gold_mart_daily_ops_suite",
        "critical": True,
    },
    "mart_profitability": {
        "schema": "GOLD",
        "table": "MART_PROFITABILITY",
        "suite": "gold_mart_profitability_suite",
        "critical": False,
    },
}

# Alert thresholds
CRITICAL_FAILURE_THRESHOLD = 0.05  # 5% failure rate triggers alert
WARNING_FAILURE_THRESHOLD = 0.02   # 2% failure rate triggers warning


class GoldLayerValidator:
    """
    Validates all Gold layer tables using Great Expectations checkpoints.
    """
    
    def __init__(self, context: BaseDataContext):
        self.context = context
        self.results: Dict[str, CheckpointResult] = {}
        self.validation_summary: Dict = {}
        
    def validate_table(
        self,
        table_name: str,
        schema: str,
        suite_name: str,
        critical: bool = False,
    ) -> CheckpointResult:
        """
        Run validation suite on a single table.
        
        Args:
            table_name: Table to validate
            schema: Database schema
            suite_name: Expectation suite name
            critical: Whether failure blocks pipeline
        
        Returns:
            CheckpointResult with validation details
        """
        logger.info(f"🔍 Validating: {schema}.{table_name} (suite: {suite_name})")
        
        batch_request = BatchRequest(
            datasource_name="zeromax_gold",
            data_connector_name="default_inferred_data_connector_name",
            data_asset_name=f"{schema}.{table_name}",
        )
        
        checkpoint_config = CheckpointConfig(
            name=f"checkpoint_{table_name.lower()}",
            config_version=1,
            class_name="SimpleCheckpoint",
            validations=[
                {
                    "batch_request": batch_request,
                    "expectation_suite_name": suite_name,
                }
            ],
        )
        
        checkpoint = Checkpoint(
            data_context=self.context,
            **checkpoint_config.to_json_dict(),
        )
        
        result = checkpoint.run()
        self.results[table_name] = result
        
        return result
    
    def validate_all_tables(self) -> Dict:
        """
        Run validation on all Gold tables.
        
        Returns:
            Summary dictionary with results
        """
        logger.info("=" * 60)
        logger.info("🏅 GOLD LAYER VALIDATION STARTING")
        logger.info("=" * 60)
        
        total_checks = 0
        passed_checks = 0
        failed_checks = 0
        critical_failures = []
        
        for table_key, table_config in GOLD_TABLES.items():
            try:
                result = self.validate_table(
                    table_name=table_config["table"],
                    schema=table_config["schema"],
                    suite_name=table_config["suite"],
                    critical=table_config["critical"],
                )
                
                # Extract statistics
                stats = result.list_validation_results()[0]
                expectation_results = stats["results"]
                
                table_total = len(expectation_results)
                table_passed = sum(1 for r in expectation_results if r["success"])
                table_failed = table_total - table_passed
                
                total_checks += table_total
                passed_checks += table_passed
                failed_checks += table_failed
                
                failure_rate = table_failed / table_total if table_total > 0 else 0
                
                # Log results
                status = "✅" if table_failed == 0 else "⚠️" if failure_rate < CRITICAL_FAILURE_THRESHOLD else "🚨"
                logger.info(f"  {status} {table_key}: {table_passed}/{table_total} passed")
                
                if table_failed > 0 and table_config["critical"] and failure_rate >= CRITICAL_FAILURE_THRESHOLD:
                    critical_failures.append({
                        "table": table_key,
                        "failed": table_failed,
                        "total": table_total,
                        "failure_rate": f"{failure_rate:.1%}",
                    })
                
                # Log individual failures
                for r in expectation_results:
                    if not r["success"]:
                        logger.warning(f"    ❌ {r['expectation_config']['expectation_type']}: "
                                      f"{r['exception_info']['exception_message'][:200]}")
                
            except Exception as e:
                logger.error(f"  ❌ {table_key}: Validation error - {str(e)}")
                critical_failures.append({
                    "table": table_key,
                    "error": str(e),
                })
        
        # Build summary
        overall_pass_rate = (passed_checks / total_checks * 100) if total_checks > 0 else 0
        
        self.validation_summary = {
            "timestamp": datetime.now().isoformat(),
            "overall_status": "PASSED" if len(critical_failures) == 0 else "FAILED",
            "summary": {
                "tables_validated": len(GOLD_TABLES),
                "total_checks": total_checks,
                "passed": passed_checks,
                "failed": failed_checks,
                "pass_rate": f"{overall_pass_rate:.1f}%",
                "critical_failures": len(critical_failures),
            },
            "critical_failures": critical_failures,
            "per_table": {
                table_key: {
                    "passed": sum(1 for r in self.results[table_key]
                                 .list_validation_results()[0]["results"] if r["success"]),
                    "total": len(self.results[table_key].list_validation_results()[0]["results"]),
                }
                for table_key in self.results
            },
        }
        
        return self.validation_summary
    
    def save_report(self, filename: str = None) -> str:
        """Save validation report to JSON."""
        if filename is None:
            os.makedirs("reports", exist_ok=True)
            filename = f"reports/gold_validation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, "w") as f:
            json.dump(self.validation_summary, f, indent=2, default=str)
        
        logger.info(f"📄 Report saved: {filename}")
        return filename
    
    def print_summary(self) -> None:
        """Print validation summary to console."""
        summary = self.validation_summary.get("summary", {})
        
        print("\n" + "=" * 60)
        print("🏅 GOLD LAYER VALIDATION SUMMARY")
        print("=" * 60)
        print(f"  Status:        {self.validation_summary.get('overall_status', 'UNKNOWN')}")
        print(f"  Tables:        {summary.get('tables_validated', 0)}")
        print(f"  Checks Total:  {summary.get('total_checks', 0)}")
        print(f"  Passed:        {summary.get('passed', 0)}")
        print(f"  Failed:        {summary.get('failed', 0)}")
        print(f"  Pass Rate:     {summary.get('pass_rate', 'N/A')}")
        print(f"  Critical:      {summary.get('critical_failures', 0)}")
        print("=" * 60)
        
        if self.validation_summary.get("critical_failures"):
            print("\n🚨 CRITICAL FAILURES:")
            for cf in self.validation_summary["critical_failures"]:
                print(f"  • {cf['table']}: {cf.get('failed', 'ERROR')} failures")
    
    def exit_with_status(self) -> None:
        """Exit with appropriate status code for CI/CD."""
        if self.validation_summary.get("overall_status") == "FAILED":
            sys.exit(1)
        else:
            sys.exit(0)


def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Gold Layer Validator")
    parser.add_argument("--output", type=str, help="Output report file path")
    parser.add_argument("--strict", action="store_true", help="Exit with error on any failure")
    args = parser.parse_args()
    
    # Get Great Expectations context
    context = BaseDataContext(project_root_dir=".")
    
    # Run validation
    validator = GoldLayerValidator(context)
    validator.validate_all_tables()
    validator.print_summary()
    
    if args.output:
        validator.save_report(args.output)
    else:
        validator.save_report()
    
    # Exit with status
    if args.strict:
        validator.exit_with_status()


if __name__ == "__main__":
    main()