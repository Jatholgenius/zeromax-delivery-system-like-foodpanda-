"""
================================================================================
ZEROMAX LOGISTICS - CUSTOM KAFKA HOOK
================================================================================
Extended Kafka hook for producing/consuming messages in Airflow.
Supports Avro serialization and Schema Registry.
================================================================================
"""

import json
import logging
from typing import Dict, List, Optional, Any, Generator
from datetime import datetime

from airflow.hooks.base import BaseHook
from airflow.exceptions import AirflowException

logger = logging.getLogger(__name__)


class ZeroMaxKafkaHook(BaseHook):
    """
    Custom Kafka hook for ZeroMax data pipeline.
    
    Features:
    - Produce messages with delivery guarantee
    - Consume messages with timeout
    - Schema Registry integration
    - Topic management utilities
    """
    
    def __init__(
        self,
        kafka_conn_id: str = "kafka_default",
        schema_registry_conn_id: str = None,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.kafka_conn_id = kafka_conn_id
        self.schema_registry_conn_id = schema_registry_conn_id
        self._producer = None
        self._consumer = None
    
    def get_conn(self) -> Any:
        """Get Kafka connection."""
        conn = self.get_connection(self.kafka_conn_id)
        extra = conn.extra_dejson
        
        config = {
            "bootstrap.servers": extra.get("bootstrap.servers", f"{conn.host}:{conn.port}"),
            "client.id": f"airflow-{datetime.now().strftime('%Y%m%d%H%M%S')}",
        }
        
        if extra.get("security.protocol"):
            config["security.protocol"] = extra["security.protocol"]
        
        return config
    
    def get_producer(self) -> Any:
        """Get or create Kafka producer."""
        if self._producer is None:
            try:
                from confluent_kafka import Producer
                config = self.get_conn()
                config.update({
                    "acks": "all",
                    "retries": 3,
                    "compression.type": "snappy",
                    "linger.ms": 5,
                })
                self._producer = Producer(config)
                logger.info("Kafka producer created")
            except ImportError:
                raise AirflowException(
                    "confluent-kafka package required. Install: pip install confluent-kafka"
                )
        
        return self._producer
    
    def get_consumer(self, group_id: str = None) -> Any:
        """Get or create Kafka consumer."""
        if self._consumer is None:
            try:
                from confluent_kafka import Consumer
                config = self.get_conn()
                config.update({
                    "group.id": group_id or f"airflow-consumer-{datetime.now().strftime('%Y%m%d')}",
                    "auto.offset.reset": "earliest",
                    "enable.auto.commit": False,
                })
                self._consumer = Consumer(config)
                logger.info("Kafka consumer created")
            except ImportError:
                raise AirflowException(
                    "confluent-kafka package required. Install: pip install confluent-kafka"
                )
        
        return self._consumer
    
    def produce(
        self,
        topic: str,
        value: Any,
        key: str = None,
        headers: Dict = None,
        callback: callable = None,
    ) -> None:
        """
        Produce a message to Kafka topic.
        
        Args:
            topic: Topic name
            value: Message value (dict or string)
            key: Message key
            headers: Message headers
            callback: Delivery callback function
        """
        producer = self.get_producer()
        
        # Serialize value
        if isinstance(value, dict):
            value = json.dumps(value, default=str).encode("utf-8")
        elif isinstance(value, str):
            value = value.encode("utf-8")
        
        # Serialize key
        if key and isinstance(key, str):
            key = key.encode("utf-8")
        
        def default_callback(err, msg):
            if err:
                logger.error(f"Message delivery failed: {err}")
            else:
                logger.debug(f"Message delivered to {msg.topic()} [{msg.partition()}] @ {msg.offset()}")
        
        producer.produce(
            topic=topic,
            value=value,
            key=key,
            headers=headers or {},
            callback=callback or default_callback,
        )
        
        logger.debug(f"Message queued for topic: {topic}")
    
    def produce_batch(
        self,
        topic: str,
        messages: List[Dict],
        key_field: str = None,
        flush: bool = True,
    ) -> int:
        """
        Produce multiple messages in batch.
        
        Args:
            topic: Topic name
            messages: List of message dicts
            key_field: Field to use as message key
            flush: Whether to flush after batch
            
        Returns:
            Number of messages produced
        """
        producer = self.get_producer()
        count = 0
        
        for msg in messages:
            key = msg.get(key_field) if key_field else None
            self.produce(topic, msg, key=key)
            count += 1
        
        if flush:
            producer.flush()
            logger.info(f"Batch produced: {count} messages to {topic}")
        
        return count
    
    def consume(
        self,
        topics: List[str],
        max_messages: int = 100,
        timeout: float = 30.0,
    ) -> List[Dict]:
        """
        Consume messages from Kafka topics.
        
        Args:
            topics: List of topic names
            max_messages: Maximum messages to consume
            timeout: Timeout in seconds
            
        Returns:
            List of consumed messages
        """
        consumer = self.get_consumer()
        consumer.subscribe(topics)
        
        messages = []
        start_time = datetime.now()
        
        try:
            while len(messages) < max_messages:
                elapsed = (datetime.now() - start_time).total_seconds()
                if elapsed > timeout:
                    logger.info(f"Consumer timeout reached ({timeout}s)")
                    break
                
                msg = consumer.poll(timeout=1.0)
                
                if msg is None:
                    continue
                
                if msg.error():
                    logger.error(f"Consumer error: {msg.error()}")
                    continue
                
                try:
                    value = json.loads(msg.value().decode("utf-8"))
                    messages.append({
                        "topic": msg.topic(),
                        "partition": msg.partition(),
                        "offset": msg.offset(),
                        "key": msg.key().decode("utf-8") if msg.key() else None,
                        "value": value,
                        "timestamp": msg.timestamp()[1],
                    })
                except json.JSONDecodeError:
                    logger.warning(f"Failed to decode message at offset {msg.offset()}")
                    continue
            
        finally:
            consumer.close()
        
        logger.info(f"Consumed {len(messages)} messages from {topics}")
        return messages
    
    def get_topic_partitions(self, topic: str) -> List[int]:
        """
        Get partitions for a topic.
        
        Args:
            topic: Topic name
            
        Returns:
            List of partition IDs
        """
        try:
            from confluent_kafka.admin import AdminClient
            
            config = self.get_conn()
            admin = AdminClient(config)
            
            metadata = admin.list_topics(topic, timeout=10)
            topic_metadata = metadata.topics.get(topic)
            
            if topic_metadata:
                return list(topic_metadata.partitions.keys())
            
            return []
            
        except Exception as e:
            logger.error(f"Failed to get partitions: {e}")
            return []
    
    def get_topic_lag(self, topic: str, group_id: str) -> Dict[int, int]:
        """
        Get consumer lag for a topic.
        
        Args:
            topic: Topic name
            group_id: Consumer group ID
            
        Returns:
            Dict of partition -> lag
        """
        try:
            from confluent_kafka.admin import AdminClient
            
            config = self.get_conn()
            admin = AdminClient(config)
            
            # Get committed offsets
            consumer_group_offsets = admin.list_consumer_group_offsets(
                group_id, request_timeout=10
            )
            
            lag = {}
            # Simplified - full implementation would compare with topic end offsets
            
            return lag
            
        except Exception as e:
            logger.error(f"Failed to get lag: {e}")
            return {}
    
    def topic_exists(self, topic: str) -> bool:
        """
        Check if topic exists.
        
        Args:
            topic: Topic name
            
        Returns:
            True if topic exists
        """
        try:
            from confluent_kafka.admin import AdminClient
            
            config = self.get_conn()
            admin = AdminClient(config)
            
            metadata = admin.list_topics(topic, timeout=10)
            return topic in metadata.topics
            
        except Exception:
            return False
    
    def create_topic(
        self,
        topic: str,
        num_partitions: int = 3,
        replication_factor: int = 1,
    ) -> bool:
        """
        Create a Kafka topic.
        
        Args:
            topic: Topic name
            num_partitions: Number of partitions
            replication_factor: Replication factor
            
        Returns:
            True if created successfully
        """
        try:
            from confluent_kafka.admin import AdminClient, NewTopic
            
            config = self.get_conn()
            admin = AdminClient(config)
            
            new_topic = NewTopic(
                topic,
                num_partitions=num_partitions,
                replication_factor=replication_factor,
            )
            
            futures = admin.create_topics([new_topic])
            
            for topic_name, future in futures.items():
                future.result()
                logger.info(f"Topic created: {topic_name}")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to create topic {topic}: {e}")
            return False
    
    def flush_producer(self) -> None:
        """Flush all pending producer messages."""
        if self._producer:
            self._producer.flush()
            logger.info("Producer flushed")
    
    def close(self) -> None:
        """Close producer and consumer."""
        if self._producer:
            self._producer.flush()
            self._producer = None
        
        if self._consumer:
            self._consumer.close()
            self._consumer = None
        
        logger.info("Kafka connections closed")