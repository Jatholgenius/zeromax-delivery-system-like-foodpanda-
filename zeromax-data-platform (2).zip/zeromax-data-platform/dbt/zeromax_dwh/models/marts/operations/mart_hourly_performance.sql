{{
  config(
    materialized='table',
    cluster_by=['hour', 'zone_name'],
    tags=['gold', 'operations', 'hourly', 'aggregated'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter",
      "GRANT SELECT ON {{ this }} TO ROLE analyst"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: MART_HOURLY_PERFORMANCE
-- ============================================================
-- Hourly delivery performance metrics by zone.
-- Used for peak hour analysis and shift optimization.
-- ============================================================

WITH hourly_base AS (
    SELECT
        -- Time dimensions
        dt.hour,
        dt.hour_label,
        dt.period,
        dt.peak_status,
        dt.is_peak_hour,
        dt.is_night,
        dt.shift,
        
        -- Zone dimensions
        dz.zone_name,
        dz.zone_id,
        dz.traffic_factor AS zone_traffic_factor,
        
        -- Date dimensions
        dd.full_date,
        dd.is_weekend,
        dd.is_ramadan,
        dd.is_eid,
        
        -- Aggregation
        COUNT(DISTINCT fd.delivery_sk) AS total_deliveries,
        COUNT(DISTINCT fd.driver_sk) AS unique_drivers,
        
        -- Status breakdown
        SUM(fd.is_on_time) AS on_time_count,
        SUM(fd.is_late) AS late_count,
        SUM(fd.is_failed) AS failed_count,
        
        -- Time metrics
        ROUND(AVG(fd.delivery_duration_min), 1) AS avg_delivery_time_min,
        ROUND(AVG(fd.delay_min), 1) AS avg_delay_min,
        ROUND(AVG(fd.preparation_time_min), 1) AS avg_prep_time_min,
        ROUND(AVG(fd.travel_time_actual_min), 1) AS avg_travel_time_min,
        ROUND(AVG(fd.pickup_delay_min), 1) AS avg_pickup_delay_min,
        
        -- Percentile metrics
        PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY fd.delivery_duration_min) AS p50_time,
        PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY fd.delivery_duration_min) AS p90_time,
        PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY fd.delivery_duration_min) AS p95_time,
        
        -- Distance
        ROUND(AVG(fd.distance_km), 2) AS avg_distance_km,
        SUM(fd.distance_km) AS total_distance_km,
        
        -- Ratings
        ROUND(AVG(fd.customer_rating), 2) AS avg_rating,
        COUNT(CASE WHEN fd.customer_rating >= 4.5 THEN 1 END) AS excellent_count,
        COUNT(CASE WHEN fd.customer_rating < 3.0 THEN 1 END) AS poor_count,
        
        -- Financials
        SUM(fd.delivery_fee_pkr) AS total_revenue,
        SUM(fd.profit_pkr) AS total_profit,
        ROUND(AVG(fd.profit_pkr), 0) AS avg_profit_per_order,
        
        -- Vehicle breakdown
        COUNT(CASE WHEN fd.vehicle_category = 'Bike' THEN 1 END) AS bike_deliveries,
        COUNT(CASE WHEN fd.vehicle_category = 'Car' THEN 1 END) AS car_deliveries,
        COUNT(CASE WHEN fd.vehicle_category = 'Rickshaw' THEN 1 END) AS rickshaw_deliveries,
        
        -- Environmental
        ROUND(AVG(fd.weather_severity), 1) AS avg_weather_severity,
        ROUND(AVG(fd.traffic_severity), 1) AS avg_traffic_severity,
        ROUND(AVG(fd.severity_index), 1) AS avg_severity_index,
        
        -- Metadata
        MAX(fd.dw_created_at) AS last_updated
        
    FROM {{ ref('fct_delivery') }} fd
    INNER JOIN {{ ref('dim_time') }} dt
        ON fd.time_key = dt.time_sk
    INNER JOIN {{ ref('dim_zone') }} dz
        ON fd.zone_key = dz.zone_sk
    INNER JOIN {{ ref('dim_date') }} dd
        ON fd.date_key = dd.date_sk
    
    WHERE fd.order_datetime >= DATEADD(month, -3, CURRENT_DATE())
    
    GROUP BY 
        dt.hour, dt.hour_label, dt.period, dt.peak_status,
        dt.is_peak_hour, dt.is_night, dt.shift,
        dz.zone_name, dz.zone_id, dz.traffic_factor,
        dd.full_date, dd.is_weekend, dd.is_ramadan, dd.is_eid
)

SELECT
    *,
    
    -- ==========================================
    -- CALCULATED KPIs
    -- ==========================================
    
    -- On-Time Rate
    ROUND((on_time_count * 100.0 / NULLIF(total_deliveries, 0)), 1) AS on_time_rate_pct,
    
    -- Late Rate
    ROUND((late_count * 100.0 / NULLIF(total_deliveries, 0)), 1) AS late_rate_pct,
    
    -- Failed Rate
    ROUND((failed_count * 100.0 / NULLIF(total_deliveries, 0)), 1) AS failed_rate_pct,
    
    -- Profit Margin
    ROUND((total_profit * 100.0 / NULLIF(total_revenue, 0)), 1) AS profit_margin_pct,
    
    -- Revenue per delivery
    ROUND((total_revenue * 1.0 / NULLIF(total_deliveries, 0)), 0) AS revenue_per_delivery,
    
    -- Excellent rating rate
    ROUND((excellent_count * 100.0 / NULLIF(total_deliveries, 0)), 1) AS excellent_rate_pct,
    
    -- Poor rating rate
    ROUND((poor_count * 100.0 / NULLIF(total_deliveries, 0)), 1) AS poor_rate_pct,
    
    -- Bike utilization
    ROUND((bike_deliveries * 100.0 / NULLIF(total_deliveries, 0)), 1) AS bike_utilization_pct,
    
    -- Deliveries per driver
    ROUND((total_deliveries * 1.0 / NULLIF(unique_drivers, 0)), 1) AS deliveries_per_driver,
    
    -- Hour efficiency score
    ROUND(
        (on_time_rate_pct * 0.40) +
        ((100 - COALESCE(failed_rate_pct, 0)) * 0.30) +
        (COALESCE(profit_margin_pct, 0) * 0.20) +
        (COALESCE(excellent_rate_pct, 0) * 0.10)
    , 1) AS hour_efficiency_score,
    
    -- Performance vs zone average
    ROUND(
        on_time_rate_pct - AVG(on_time_rate_pct) OVER (
            PARTITION BY hour
        ), 1
    ) AS on_time_vs_hourly_avg,
    
    -- Rank within hour
    RANK() OVER (
        PARTITION BY hour 
        ORDER BY total_deliveries DESC
    ) AS zone_rank_by_volume,
    
    -- Peak demand indicator
    CASE
        WHEN total_deliveries > PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY total_deliveries) OVER ()
        THEN 'High Demand'
        WHEN total_deliveries > PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY total_deliveries) OVER ()
        THEN 'Medium Demand'
        ELSE 'Low Demand'
    END AS demand_level

FROM hourly_base