{#
-- ============================================================
-- HAVERSINE DISTANCE MACRO
-- ============================================================
-- Calculates the great-circle distance between two points
-- on Earth using the Haversine formula.
--
-- Parameters:
--   lat1, lon1 - Latitude/Longitude of point 1 (degrees)
--   lat2, lon2 - Latitude/Longitude of point 2 (degrees)
--   unit       - 'km' (default) or 'mi' for miles
--
-- Returns: Distance in kilometers or miles
-- ============================================================
#}

{% macro haversine_distance(lat1, lon1, lat2, lon2, unit='km') %}

    -- Earth's radius
    {% if unit == 'mi' %}
        -- Radius in miles
        {% set R = 3959 %}
    {% else %}
        -- Radius in kilometers (default)
        {% set R = 6371 %}
    {% endif %}

    -- Convert degrees to radians
    (
        {{ R }} * 2 * ATAN2(
            SQRT(
                POWER(SIN(RADIANS({{ lat2 }} - {{ lat1 }}) / 2), 2) +
                COS(RADIANS({{ lat1 }})) * COS(RADIANS({{ lat2 }})) *
                POWER(SIN(RADIANS({{ lon2 }} - {{ lon1 }}) / 2), 2)
            ),
            SQRT(
                1 - (
                    POWER(SIN(RADIANS({{ lat2 }} - {{ lat1 }}) / 2), 2) +
                    COS(RADIANS({{ lat1 }})) * COS(RADIANS({{ lat2 }})) *
                    POWER(SIN(RADIANS({{ lon2 }} - {{ lon1 }}) / 2), 2)
                )
            )
        )
    )

{% endmacro %}


{#
-- ============================================================
-- HAVERSINE DISTANCE WITH ROAD FACTOR
-- ============================================================
-- Adds a road factor multiplier to account for non-straight-line
-- road distances in urban environments like Karachi.
--
-- Parameters:
--   lat1, lon1 - Point 1 coordinates
--   lat2, lon2 - Point 2 coordinates
--   road_factor - Multiplier for road vs straight-line (default: 1.15)
-- ============================================================
#}

{% macro road_distance(lat1, lon1, lat2, lon2, road_factor=1.15) %}

    -- Straight-line haversine distance
    {{ haversine_distance(lat1, lon1, lat2, lon2, 'km') }} * {{ road_factor }}

{% endmacro %}


{#
-- ============================================================
-- DISTANCE CATEGORY
-- ============================================================
-- Categorizes delivery distance into buckets for analysis.
-- ============================================================
#}

{% macro distance_category(distance_km) %}

    CASE
        WHEN {{ distance_km }} <= 2 THEN 'Very Short (0-2 km)'
        WHEN {{ distance_km }} <= 4 THEN 'Short (2-4 km)'
        WHEN {{ distance_km }} <= 6 THEN 'Medium (4-6 km)'
        WHEN {{ distance_km }} <= 8 THEN 'Long (6-8 km)'
        WHEN {{ distance_km }} <= 10 THEN 'Very Long (8-10 km)'
        WHEN {{ distance_km }} <= 12 THEN 'Extended (10-12 km)'
        ELSE 'Extreme (12+ km)'
    END

{% endmacro %}


{#
-- ============================================================
-- ROUTE EFFICIENCY SCORE
-- ============================================================
-- Calculates route efficiency as percentage.
-- Efficiency = (Optimal Distance / Actual Distance) * 100
-- ============================================================
#}

{% macro route_efficiency(optimal_km, actual_km) %}

    CASE
        WHEN {{ actual_km }} > 0 THEN
            ROUND(({{ optimal_km }} / {{ actual_km }}) * 100, 1)
        ELSE 0
    END

{% endmacro %}


{#
-- ============================================================
-- DELIVERY TIME ESTIMATOR
-- ============================================================
-- Estimates delivery time based on distance, traffic, weather.
--
-- Parameters:
--   distance_km     - Delivery distance
--   traffic_factor  - Traffic delay multiplier (1.0-2.5)
--   weather_factor  - Weather delay multiplier (1.0-1.7)
--   vehicle_speed   - Average vehicle speed in km/h
--   prep_time       - Food preparation time in minutes
-- ============================================================
#}

{% macro estimate_delivery_time(
    distance_km, 
    traffic_factor=1.0, 
    weather_factor=1.0, 
    vehicle_speed=35, 
    prep_time=10
) %}

    -- Travel time = (Distance / Speed) * 60 minutes * traffic * weather
    -- Total time = Prep time + Travel time
    ROUND(
        {{ prep_time }} + 
        (({{ distance_km }} / {{ vehicle_speed }}) * 60 * {{ traffic_factor }} * {{ weather_factor }}),
        0
    )

{% endmacro %}


{#
-- ============================================================
-- GEO-FENCE CHECK
-- ============================================================
-- Checks if a point is within a defined zone boundary.
-- Returns TRUE/FALSE.
--
-- Parameters:
--   lat, lon       - Point to check
--   zone_lat, zone_lon - Zone center coordinates
--   radius_km      - Zone radius in kilometers
-- ============================================================
#}

{% macro is_in_zone(lat, lon, zone_lat, zone_lon, radius_km) %}

    {{ haversine_distance(lat, lon, zone_lat, zone_lon, 'km') }} <= {{ radius_km }}

{% endmacro %}


{#
-- ============================================================
-- NEAREST ZONE FINDER
-- ============================================================
-- Finds the nearest delivery zone for a given point.
-- Requires dim_zone table with zone coordinates.
-- ============================================================
#}

{% macro nearest_zone(lat, lon) %}

    (
        SELECT zone_id
        FROM {{ ref('dim_zone') }}
        ORDER BY {{ haversine_distance(lat, lon, 'center_lat', 'center_lon', 'km') }} ASC
        LIMIT 1
    )

{% endmacro %}


{#
-- ============================================================
-- COORDINATE VALIDATOR
-- ============================================================
-- Validates if coordinates are within Karachi boundaries.
-- Karachi approximate bounds:
--   Latitude:  24.7 - 25.1
--   Longitude: 66.8 - 67.3
-- ============================================================
#}

{% macro is_valid_karachi_coordinate(lat, lon) %}

    {{ lat }} BETWEEN 24.7 AND 25.1 
    AND {{ lon }} BETWEEN 66.8 AND 67.3

{% endmacro %}


{#
-- ============================================================
-- EXAMPLE USAGE IN MODELS:
-- ============================================================
-- 
-- SELECT
--     delivery_id,
--     {{ haversine_distance('rest_lat', 'rest_lon', 'cust_lat', 'cust_lon', 'km') }} AS distance_km,
--     {{ distance_category('distance_km') }} AS distance_bucket,
--     {{ route_efficiency('optimal_distance_km', 'actual_distance_km') }} AS efficiency_pct,
--     {{ estimate_delivery_time('distance_km', 'traffic_delay_factor', 'weather_delay_multiplier', 'vehicle_speed_kmh', 'prep_time_min') }} AS estimated_minutes,
--     {{ is_valid_karachi_coordinate('cust_lat', 'cust_lon') }} AS is_valid_location
-- FROM {{ ref('stg_delivery') }}
-- ============================================================
#}