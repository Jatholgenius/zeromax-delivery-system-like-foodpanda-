{{
  config(
    materialized='table',
    cluster_by=['driver_sk'],
    tags=['gold', 'driver', 'scorecard', 'performance'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE operations_manager",
      "GRANT SELECT ON {{ this }} TO ROLE executive"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: MART_DRIVER_SCORECARD
-- ============================================================
-- Driver performance scorecard with weighted KPIs.
-- Used for incentives, promotions, and performance improvement.
-- ============================================================

WITH driver_stats AS (
    SELECT
        fd.driver_sk,
        
        -- Volume metrics
        COUNT(DISTINCT fd.delivery_sk) AS total_deliveries,
        COUNT(DISTINCT DATE_TRUNC('day', fd.order_datetime)) AS active_days,
        COUNT(DISTINCT DATE_TRUNC('month', fd.order_datetime)) AS active_months,
        
        -- Time metrics
        ROUND(AVG(fd.delivery_duration_min), 1) AS avg_delivery_time_min,
        ROUND(AVG(fd.delay_min), 1) AS avg_delay_min,
        ROUND(AVG(fd.travel_time_actual_min), 1) AS avg_travel_time_min,
        
        -- Quality metrics
        SUM(fd.is_on_time) AS on_time_count,
        SUM(fd.is_late) AS late_count,
        SUM(fd.is_failed) AS failed_count,
        ROUND(AVG(fd.customer_rating), 2) AS avg_rating,
        COUNT(CASE WHEN fd.customer_rating >= 4.5 THEN 1 END) AS excellent_ratings,
        COUNT(CASE WHEN fd.customer_rating < 3.0 THEN 1 END) AS poor_ratings,
        
        -- Distance
        SUM(fd.distance_km) AS total_distance_km,
        ROUND(AVG(fd.distance_km), 2) AS avg_distance_km,
        ROUND(AVG(fd.route_efficiency_pct), 1) AS avg_route_efficiency,
        
        -- Financials
        SUM(fd.delivery_fee_pkr) AS total_revenue,
        SUM(fd.profit_pkr) AS total_profit,
        ROUND(AVG(fd.profit_pkr), 0) AS avg_profit_per_delivery,
        SUM(fd.delay_penalty_pkr) AS total_penalties,
        
        -- Peak performance
        COUNT(CASE WHEN fd.is_peak_hour THEN 1 END) AS peak_deliveries,
        COUNT(CASE WHEN fd.is_night THEN 1 END) AS night_deliveries,
        
        -- Weather resilience
        ROUND(AVG(CASE WHEN fd.weather_severity >= 3 THEN fd.customer_rating END), 2) AS avg_rating_bad_weather,
        ROUND(AVG(CASE WHEN fd.weather_severity <= 1 THEN fd.customer_rating END), 2) AS avg_rating_good_weather,
        
        -- Efficiency
        ROUND(SUM(fd.distance_km) * 1.0 / NULLIF(COUNT(*), 0) / 
              NULLIF(AVG(fd.speed_factor), 0), 2) AS efficiency_index
        
    FROM {{ ref('fct_delivery') }} fd
    WHERE fd.order_datetime >= DATEADD(month, -3, CURRENT_DATE())
    GROUP BY fd.driver_sk
),

driver_info AS (
    SELECT
        driver_sk,
        driver_id,
        driver_name,
        experience_level,
        vehicle_type,
        home_zone,
        base_rating,
        status,
        hire_date,
        DATEDIFF('day', hire_date, CURRENT_DATE()) AS tenure_days
    FROM {{ ref('dim_driver_scd2') }}
    WHERE is_current = TRUE
)

SELECT
    di.driver_sk,
    di.driver_id,
    di.driver_name,
    di.experience_level,
    di.vehicle_type,
    di.home_zone,
    di.status,
    di.tenure_days,
    
    -- Volume
    COALESCE(ds.total_deliveries, 0) AS total_deliveries,
    COALESCE(ds.active_days, 0) AS active_days,
    ROUND(COALESCE(ds.total_deliveries, 0) * 1.0 / NULLIF(ds.active_days, 0), 1) AS deliveries_per_day,
    
    -- Quality
    COALESCE(ds.avg_rating, 0) AS avg_customer_rating,
    ROUND(COALESCE(ds.on_time_count, 0) * 100.0 / NULLIF(ds.total_deliveries, 0), 1) AS on_time_rate_pct,
    ROUND(COALESCE(ds.failed_count, 0) * 100.0 / NULLIF(ds.total_deliveries, 0), 1) AS failure_rate_pct,
    ROUND(COALESCE(ds.excellent_ratings, 0) * 100.0 / NULLIF(ds.total_deliveries, 0), 1) AS excellent_rate_pct,
    
    -- Time
    COALESCE(ds.avg_delivery_time_min, 0) AS avg_delivery_time_min,
    COALESCE(ds.avg_delay_min, 0) AS avg_delay_min,
    
    -- Distance & Route
    COALESCE(ds.total_distance_km, 0) AS total_distance_km,
    COALESCE(ds.avg_distance_km, 0) AS avg_distance_km,
    COALESCE(ds.avg_route_efficiency, 0) AS route_efficiency_pct,
    
    -- Financial
    COALESCE(ds.total_revenue, 0) AS total_revenue_pkr,
    COALESCE(ds.total_profit, 0) AS total_profit_pkr,
    COALESCE(ds.avg_profit_per_delivery, 0) AS avg_profit_per_delivery_pkr,
    COALESCE(ds.total_penalties, 0) AS total_penalties_pkr,
    
    -- Peak vs Off-Peak
    COALESCE(ds.peak_deliveries, 0) AS peak_deliveries,
    COALESCE(ds.night_deliveries, 0) AS night_deliveries,
    
    -- ==========================================
    -- PERFORMANCE SCORES (0-100 each)
    -- ==========================================
    
    -- Quality Score (40% weight)
    ROUND(
        (COALESCE(on_time_rate_pct, 0) * 0.5) +
        (COALESCE(excellent_rate_pct, 0) * 0.3) +
        (COALESCE(avg_customer_rating * 20, 0) * 0.2)
    , 1) AS quality_score,
    
    -- Productivity Score (30% weight)
    ROUND(
        LEAST(COALESCE(total_deliveries, 0) * 2, 100) * 0.6 +
        LEAST(COALESCE(deliveries_per_day * 20, 0), 100) * 0.4
    , 1) AS productivity_score,
    
    -- Efficiency Score (20% weight)
    ROUND(
        (COALESCE(route_efficiency_pct, 0) * 0.5) +
        (GREATEST(100 - COALESCE(avg_delay_min, 0) * 2, 0) * 0.3) +
        (LEAST(COALESCE(total_distance_km / NULLIF(active_days, 0) * 10, 0), 100) * 0.2)
    , 1) AS efficiency_score,
    
    -- Financial Score (10% weight)
    ROUND(
        LEAST(COALESCE(total_profit_pkr / 1000, 0), 100) * 0.6 +
        (GREATEST(100 - COALESCE(total_penalties_pkr / 100, 0), 0) * 0.4)
    , 1) AS financial_score,
    
    -- ==========================================
    -- COMPOSITE SCORE
    -- ==========================================
    ROUND(
        (COALESCE(quality_score, 0) * 0.40) +
        (COALESCE(productivity_score, 0) * 0.30) +
        (COALESCE(efficiency_score, 0) * 0.20) +
        (COALESCE(financial_score, 0) * 0.10)
    , 1) AS composite_score,
    
    -- Performance Tier
    CASE
        WHEN composite_score >= 85 THEN '⭐ Top Performer'
        WHEN composite_score >= 70 THEN 'Strong Performer'
        WHEN composite_score >= 55 THEN 'Average Performer'
        WHEN composite_score >= 40 THEN 'Below Average'
        ELSE 'Needs Improvement'
    END AS performance_tier,
    
    -- Recommendation
    CASE
        WHEN composite_score >= 85 THEN 'Promotion/Incentive Eligible'
        WHEN composite_score >= 70 THEN 'Mentor/Mentee Program'
        WHEN composite_score >= 55 THEN 'Additional Training'
        WHEN composite_score >= 40 THEN 'Performance Improvement Plan'
        ELSE 'Review Employment Status'
    END AS recommendation,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'mart_driver_scorecard' AS dw_source

FROM driver_info di
LEFT JOIN driver_stats ds ON di.driver_sk = ds.driver_sk