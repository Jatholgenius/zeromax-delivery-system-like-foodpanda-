{{
  config(
    materialized='table',
    tags=['gold', 'dimension', 'zone', 'static'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter",
      "GRANT SELECT ON {{ this }} TO ROLE analyst"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: DIM_ZONE
-- ============================================================
-- Static dimension for Karachi delivery zones.
-- SCD Type 1 (overwrite) - zone boundaries rarely change.
-- ============================================================

WITH zone_data AS (
    SELECT
        zone_id,
        zone_name,
        center_lat,
        center_lon,
        avg_base_time_min,
        avg_distance_km,
        traffic_factor,
        peak_hours,
        top_areas,
        total_restaurants,
        total_drivers,
        total_customers,
        area_sq_km,
        population_density,
        is_active
    FROM {{ ref('stg_zone') }}
),

-- Add calculated metrics
enriched AS (
    SELECT
        -- Surrogate Key
        {{ dbt_utils.generate_surrogate_key(['zone_id']) }} AS zone_sk,
        
        -- Natural Key
        zone_id,
        zone_name,
        
        -- Coordinates
        center_lat,
        center_lon,
        
        -- Performance Metrics
        avg_base_time_min,
        avg_distance_km,
        traffic_factor,
        
        -- Classification
        CASE
            WHEN traffic_factor >= 1.40 THEN 'High Traffic'
            WHEN traffic_factor >= 1.25 THEN 'Medium Traffic'
            WHEN traffic_factor >= 1.10 THEN 'Low-Medium Traffic'
            ELSE 'Low Traffic'
        END AS traffic_category,
        
        CASE
            WHEN avg_base_time_min >= 38 THEN 'Slow Zone'
            WHEN avg_base_time_min >= 33 THEN 'Moderate Zone'
            WHEN avg_base_time_min >= 28 THEN 'Fast Zone'
            ELSE 'Very Fast Zone'
        END AS speed_category,
        
        -- Peak Hours
        peak_hours,
        SPLIT(peak_hours, ',') AS peak_hours_array,
        
        -- Coverage
        top_areas,
        total_restaurants,
        total_drivers,
        total_customers,
        area_sq_km,
        population_density,
        
        -- Density Metrics
        CASE 
            WHEN area_sq_km > 0 
            THEN ROUND((total_restaurants * 1.0 / area_sq_km), 2)
            ELSE 0 
        END AS restaurants_per_sq_km,
        
        CASE 
            WHEN area_sq_km > 0 
            THEN ROUND((total_drivers * 1.0 / area_sq_km), 2)
            ELSE 0 
        END AS drivers_per_sq_km,
        
        -- Status
        is_active,
        
        -- Metadata
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'dim_zone' AS dw_source
        
    FROM zone_data
)

SELECT * FROM enriched