"""
================================================================================
ZEROMAX LOGISTICS - HISTORICAL DATA LOADER
================================================================================
Batch loads historical delivery data from CSV files to Bronze layer.
Handles initial load and backfill operations.

Usage:
    python historical_loader.py
    python historical_loader.py --start 2024-01-01 --end 2024-06-30
    python historical_loader.py --full-refresh
================================================================================
"""

import os
import sys
import json
import logging
from datetime import datetime, date
from typing import Dict, List, Optional
from pathlib import Path

import pandas as pd
import numpy as np
from dotenv import load_dotenv

load_dotenv()

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("logs/historical_loader.log"),
    ],
)
logger = logging.getLogger(__name__)

# ============================================
# CONFIGURATION
# ============================================

DATA_DIR = os.getenv("DATA_DIR", "data")
BRONZE_DIR = os.path.join(DATA_DIR, "bronze")
SILVER_DIR = os.path.join(DATA_DIR, "silver")
GOLD_DIR = os.path.join(DATA_DIR, "gold")

TABLE_MAPPING = {
    "dim_zone": {
        "source": "zeromax_output/dim_zone.csv",
        "target": "bronze/dim_zone",
        "key": "zone_key",
    },
    "dim_driver": {
        "source": "zeromax_output/dim_driver.csv",
        "target": "bronze/dim_driver",
        "key": "driver_key",
    },
    "dim_customer": {
        "source": "zeromax_output/dim_customer.csv",
        "target": "bronze/dim_customer",
        "key": "customer_key",
    },
    "dim_restaurant": {
        "source": "zeromax_output/dim_restaurant.csv",
        "target": "bronze/dim_restaurant",
        "key": "restaurant_key",
    },
    "dim_date": {
        "source": "zeromax_output/dim_date.csv",
        "target": "bronze/dim_date",
        "key": "date_key",
    },
    "dim_time": {
        "source": "zeromax_output/dim_time.csv",
        "target": "bronze/dim_time",
        "key": "time_key",
    },
    "dim_weather": {
        "source": "zeromax_output/dim_weather.csv",
        "target": "bronze/dim_weather",
        "key": "weather_key",
    },
    "dim_traffic": {
        "source": "zeromax_output/dim_traffic.csv",
        "target": "bronze/dim_traffic",
        "key": "traffic_key",
    },
    "dim_vehicle": {
        "source": "zeromax_output/dim_vehicle.csv",
        "target": "bronze/dim_vehicle",
        "key": "vehicle_key",
    },
    "dim_payment": {
        "source": "zeromax_output/dim_payment.csv",
        "target": "bronze/dim_payment",
        "key": "payment_key",
    },
    "dim_cancellation": {
        "source": "zeromax_output/dim_cancellation_reason.csv",
        "target": "bronze/dim_cancellation",
        "key": "cancel_key",
    },
    "fact_delivery": {
        "source": "zeromax_output/fact_delivery.csv",
        "target": "bronze/fact_delivery",
        "key": "delivery_key",
        "partition_by": "order_datetime",
    },
}


class HistoricalLoader:
    """
    Loads historical data from CSV files to Bronze layer.
    Supports incremental and full refresh modes.
    """
    
    def __init__(self, data_dir: str = None):
        self.data_dir = data_dir or DATA_DIR
        self.stats = {
            "tables_loaded": 0,
            "tables_skipped": 0,
            "total_rows": 0,
            "errors": [],
            "start_time": datetime.now(),
        }
        
        # Ensure directories exist
        for dir_path in [BRONZE_DIR, SILVER_DIR, GOLD_DIR]:
            Path(dir_path).mkdir(parents=True, exist_ok=True)
    
    def load_table(
        self, 
        table_name: str, 
        source_path: str, 
        target_path: str,
        key_column: str = None,
        partition_column: str = None,
        mode: str = "append",
    ) -> Dict:
        """
        Load a single table from CSV to Bronze layer.
        
        Args:
            table_name: Name of the table
            source_path: Path to source CSV
            target_path: Target path in Bronze layer
            key_column: Primary key column for deduplication
            partition_column: Column to partition by
            mode: 'append' or 'overwrite'
            
        Returns:
            Dict with load statistics
        """
        result = {
            "table": table_name,
            "status": "pending",
            "rows_loaded": 0,
            "error": None,
        }
        
        try:
            # Check if source exists
            if not os.path.exists(source_path):
                logger.warning(f"Source not found: {source_path}")
                result["status"] = "skipped"
                result["error"] = "Source file not found"
                return result
            
            # Read source CSV
            logger.info(f"Reading {source_path}...")
            df = pd.read_csv(source_path)
            initial_rows = len(df)
            
            # Basic validation
            if df.empty:
                logger.warning(f"Empty dataframe for {table_name}")
                result["status"] = "skipped"
                return result
            
            # Check for existing data
            target_dir = os.path.join(BRONZE_DIR, target_path)
            target_file = os.path.join(target_dir, f"{table_name}.parquet")
            
            if mode == "append" and os.path.exists(target_file):
                existing_df = pd.read_parquet(target_file)
                
                if key_column and key_column in df.columns:
                    # Deduplicate: remove rows already in target
                    existing_keys = set(existing_df[key_column].values)
                    df = df[~df[key_column].isin(existing_keys)]
                    logger.info(f"Deduplication: {initial_rows - len(df)} rows removed")
            
            if df.empty:
                logger.info(f"No new data for {table_name}")
                result["status"] = "no_new_data"
                return result
            
            # Write to Bronze layer (Parquet format)
            Path(target_dir).mkdir(parents=True, exist_ok=True)
            
            if partition_column and partition_column in df.columns:
                # Write partitioned
                df[partition_column] = pd.to_datetime(df[partition_column])
                df["year"] = df[partition_column].dt.year
                df["month"] = df[partition_column].dt.month
                
                for (year, month), group in df.groupby(["year", "month"]):
                    partition_dir = os.path.join(target_dir, f"year={year}", f"month={month}")
                    Path(partition_dir).mkdir(parents=True, exist_ok=True)
                    group.to_parquet(
                        os.path.join(partition_dir, "data.parquet"),
                        index=False,
                    )
            else:
                # Write single file
                if mode == "append" and os.path.exists(target_file):
                    df = pd.concat([existing_df, df], ignore_index=True)
                
                df.to_parquet(target_file, index=False)
            
            result["status"] = "loaded"
            result["rows_loaded"] = len(df)
            logger.info(f"✅ {table_name}: {len(df):,} rows loaded")
            
        except Exception as e:
            logger.error(f"❌ Error loading {table_name}: {str(e)}")
            result["status"] = "error"
            result["error"] = str(e)
        
        return result
    
    def load_all_dimensions(self) -> List[Dict]:
        """Load all dimension tables."""
        logger.info("=" * 60)
        logger.info("LOADING DIMENSION TABLES")
        logger.info("=" * 60)
        
        results = []
        
        for table_name, config in TABLE_MAPPING.items():
            if table_name.startswith("dim_"):
                result = self.load_table(
                    table_name=table_name,
                    source_path=config["source"],
                    target_path=config["target"],
                    key_column=config.get("key"),
                    mode="overwrite",  # Dimensions are overwritten
                )
                results.append(result)
                
                if result["status"] == "loaded":
                    self.stats["tables_loaded"] += 1
                    self.stats["total_rows"] += result["rows_loaded"]
                elif result["status"] == "skipped":
                    self.stats["tables_skipped"] += 1
        
        return results
    
    def load_fact_delivery(
        self, 
        start_date: str = None, 
        end_date: str = None,
        mode: str = "append",
    ) -> Dict:
        """
        Load fact delivery table with optional date filtering.
        
        Args:
            start_date: Start date filter (YYYY-MM-DD)
            end_date: End date filter (YYYY-MM-DD)
            mode: 'append' or 'overwrite'
            
        Returns:
            Load result dict
        """
        config = TABLE_MAPPING["fact_delivery"]
        
        logger.info("=" * 60)
        logger.info("LOADING FACT DELIVERY TABLE")
        logger.info("=" * 60)
        
        try:
            # Read source
            df = pd.read_csv(config["source"])
            
            # Apply date filters
            if "order_datetime" in df.columns:
                df["order_datetime"] = pd.to_datetime(df["order_datetime"])
                
                if start_date:
                    start_dt = pd.to_datetime(start_date)
                    df = df[df["order_datetime"] >= start_dt]
                    logger.info(f"Filtered from {start_date}: {len(df):,} rows")
                
                if end_date:
                    end_dt = pd.to_datetime(end_date) + pd.Timedelta(days=1)
                    df = df[df["order_datetime"] < end_dt]
                    logger.info(f"Filtered to {end_date}: {len(df):,} rows")
            
            if df.empty:
                logger.warning("No data after filtering")
                return {"table": "fact_delivery", "status": "no_data"}
            
            # Write partitioned by date
            target_dir = os.path.join(BRONZE_DIR, config["target"])
            
            df["year"] = df["order_datetime"].dt.year
            df["month"] = df["order_datetime"].dt.month
            df["day"] = df["order_datetime"].dt.day
            
            total_loaded = 0
            
            for (year, month, day), group in df.groupby(["year", "month", "day"]):
                partition_dir = os.path.join(
                    target_dir, 
                    f"year={year}", 
                    f"month={month:02d}", 
                    f"day={day:02d}"
                )
                Path(partition_dir).mkdir(parents=True, exist_ok=True)
                
                output_path = os.path.join(partition_dir, "data.parquet")
                group.to_parquet(output_path, index=False)
                total_loaded += len(group)
            
            result = {
                "table": "fact_delivery",
                "status": "loaded",
                "rows_loaded": total_loaded,
                "partitions": len(df.groupby(["year", "month", "day"])),
            }
            
            self.stats["tables_loaded"] += 1
            self.stats["total_rows"] += total_loaded
            
            logger.info(f"✅ fact_delivery: {total_loaded:,} rows in {result['partitions']} partitions")
            return result
            
        except Exception as e:
            logger.error(f"❌ Error loading fact_delivery: {str(e)}")
            return {"table": "fact_delivery", "status": "error", "error": str(e)}
    
    def generate_qa_report(self) -> str:
        """Generate quality assurance report."""
        report = f"""
============================================================
ZEROMAX HISTORICAL DATA LOAD - QA REPORT
============================================================
Load Time: {self.stats['start_time'].strftime('%Y-%m-%d %H:%M:%S')}
Duration: {(datetime.now() - self.stats['start_time']).total_seconds():.1f}s

SUMMARY:
  Tables Loaded: {self.stats['tables_loaded']}
  Tables Skipped: {self.stats['tables_skipped']}
  Total Rows: {self.stats['total_rows']:,}
  Errors: {len(self.stats['errors'])}

============================================================
"""
        
        if self.stats["errors"]:
            report += "\nERRORS:\n"
            for error in self.stats["errors"]:
                report += f"  • {error}\n"
        
        # Save report
        report_path = os.path.join(DATA_DIR, "QA_report.txt")
        with open(report_path, "w") as f:
            f.write(report)
        
        logger.info(f"📄 QA report saved: {report_path}")
        return report
    
    def run_full_load(
        self,
        start_date: str = None,
        end_date: str = None,
        full_refresh: bool = False,
    ) -> Dict:
        """
        Run complete historical data load.
        
        Args:
            start_date: Start date for fact data
            end_date: End date for fact data
            full_refresh: If True, overwrite all existing data
            
        Returns:
            Statistics dictionary
        """
        mode = "overwrite" if full_refresh else "append"
        
        logger.info("=" * 60)
        logger.info("🚀 ZEROMAX HISTORICAL DATA LOAD STARTING")
        logger.info(f"   Mode: {mode}")
        logger.info(f"   Date Range: {start_date or 'All'} to {end_date or 'All'}")
        logger.info("=" * 60)
        
        # Step 1: Load dimensions
        self.load_all_dimensions()
        
        # Step 2: Load fact table
        self.load_fact_delivery(
            start_date=start_date,
            end_date=end_date,
            mode=mode,
        )
        
        # Step 3: Generate report
        self.generate_qa_report()
        
        logger.info("=" * 60)
        logger.info(f"✅ LOAD COMPLETE: {self.stats['total_rows']:,} rows loaded")
        logger.info("=" * 60)
        
        return self.stats


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Historical Data Loader")
    parser.add_argument("--start", type=str, help="Start date (YYYY-MM-DD)")
    parser.add_argument("--end", type=str, help="End date (YYYY-MM-DD)")
    parser.add_argument("--full-refresh", action="store_true", help="Overwrite all existing data")
    parser.add_argument("--dimensions-only", action="store_true", help="Load only dimension tables")
    parser.add_argument("--data-dir", type=str, default=DATA_DIR, help="Data directory path")
    args = parser.parse_args()
    
    loader = HistoricalLoader(data_dir=args.data_dir)
    
    if args.dimensions_only:
        loader.load_all_dimensions()
    else:
        loader.run_full_load(
            start_date=args.start,
            end_date=args.end,
            full_refresh=args.full_refresh,
        )


if __name__ == "__main__":
    main()