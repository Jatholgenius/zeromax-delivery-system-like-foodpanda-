{#
-- ============================================================
-- SURROGATE KEY MACROS
-- ============================================================
-- Collection of macros for generating and managing surrogate keys.
-- Surrogate keys are system-generated, meaningless unique identifiers
-- used as primary keys in dimensional modeling.
-- ============================================================
#}

-- ============================================================
-- GENERATE SURROGATE KEY (Enhanced)
-- ============================================================
-- Generates a SHA-256 based surrogate key with optional namespace.
-- More collision-resistant than MD5 for large datasets.
{%

macro generate_surrogate_key(columns, namespace='zeromax') %}
    
    SHA2_HEX(
        CONCAT(
            '{{ namespace }}|',
            {% for col in columns %}
                COALESCE(CAST({{ col }} AS VARCHAR), '##NULL##')
                {% if not loop.last %} || '|' || {% endif %}
            {% endfor %}
        ),
        256
    )

{% endmacro %}


-- ============================================================
-- SEQUENCE-BASED SURROGATE KEY
-- ============================================================
-- Uses Snowflake sequence for numeric surrogate keys.
-- Better for join performance than hash-based keys.
{% macro sequence_surrogate_key(sequence_name) %}

    {{ sequence_name }}.NEXTVAL

{% endmacro %}


-- ============================================================
-- UUID SURROGATE KEY
-- ============================================================
-- Generates UUID v4 style surrogate key.
{% macro uuid_surrogate_key() %}

    UUID_STRING()

{% endmacro %}


-- ============================================================
-- COMPOSITE SURROGATE KEY
-- ============================================================
-- Combines multiple business keys into a single surrogate.
-- Useful for bridge tables and factless fact tables.
{% macro composite_surrogate_key(key_parts) %}

    MD5(
        CONCAT_WS('|',
            {% for key in key_parts %}
                COALESCE(CAST({{ key }} AS VARCHAR), '0')
                {% if not loop.last %}, {% endif %}
            {% endfor %}
        )
    )

{% endmacro %}


-- ============================================================
-- SURROGATE KEY LOOKUP
-- ============================================================
-- Looks up existing surrogate key from dimension table.
-- Returns existing SK or NULL if not found.
{% macro lookup_surrogate_key(dimension_table, natural_key, natural_value) %}

    (
        SELECT surrogate_key
        FROM {{ dimension_table }}
        WHERE {{ natural_key }} = {{ natural_value }}
          AND is_current = TRUE
        LIMIT 1
    )

{% endmacro %}


-- ============================================================
-- SURROGATE KEY VALIDATOR
-- ============================================================
-- Validates surrogate key integrity across fact and dimension tables.
-- Returns count of orphan records (facts without valid dimension SK).
{% macro validate_surrogate_keys(fact_table, dim_table, fk_column) %}

    SELECT 
        '{{ fact_table }}.{{ fk_column }} -> {{ dim_table }}' AS relationship,
        COUNT(*) AS orphan_count,
        COUNT(*) * 100.0 / (SELECT COUNT(*) FROM {{ fact_table }}) AS orphan_pct
    FROM {{ fact_table }} f
    LEFT JOIN {{ dim_table }} d
        ON f.{{ fk_column }} = d.surrogate_key
    WHERE d.surrogate_key IS NULL
    HAVING COUNT(*) > 0

{% endmacro %}


-- ============================================================
-- SURROGATE KEY GENERATOR FOR DIMENSIONS
-- ============================================================
-- Complete macro to generate surrogate keys during dimension loading.
-- Handles both new records and SCD Type 2 scenarios.
{% macro generate_dimension_surrogate_keys(
    source_data,
    natural_key,
    dimension_name,
    use_hash=True
) %}

    WITH source_with_sk AS (
        SELECT
            {% if use_hash %}
                -- Hash-based surrogate key (deterministic)
                {{ generate_surrogate_key([natural_key], dimension_name) }} AS surrogate_key,
            {% else %}
                -- Sequence-based surrogate key (non-deterministic)
                {{ sequence_surrogate_key('seq_' + dimension_name) }} AS surrogate_key,
            {% endif %}
            
            {{ natural_key }},
            *
        FROM {{ source_data }}
    )
    
    SELECT * FROM source_with_sk

{% endmacro %}


-- ============================================================
-- INCREMENTAL SURROGATE KEY
-- ============================================================
-- Generates incremental integer surrogate keys.
-- Requires a control table to track last used key.
{% macro incremental_surrogate_key(table_name, key_column='surrogate_key') %}

    {% set max_key_query %}
        SELECT COALESCE(MAX({{ key_column }}), 0) 
        FROM {{ table_name }}
    {% endset %}
    
    {% set current_max = run_query(max_key_query).columns[0].values()[0] | int %}
    
    -- Return next value using ROW_NUMBER()
    {{ current_max }} + ROW_NUMBER() OVER (ORDER BY (SELECT NULL))

{% endmacro %}


-- ============================================================
-- SURROGATE KEY MAPPING TABLE
-- ============================================================
-- Creates a mapping between natural keys and surrogate keys.
-- Useful for ETL processes that need to resolve SKs.
{% macro create_sk_mapping(natural_key, surrogate_key, source_table) %}

    SELECT DISTINCT
        {{ natural_key }},
        {{ surrogate_key }},
        CURRENT_TIMESTAMP() AS mapped_at
    FROM {{ source_table }}
    WHERE {{ natural_key }} IS NOT NULL
      AND {{ surrogate_key }} IS NOT NULL

{% endmacro %}


-- ============================================================
-- MERGE WITH SURROGATE KEYS
-- ============================================================
-- Merges fact data with dimension surrogate keys in one operation.
-- Handles late-arriving dimensions gracefully.
{% macro merge_with_surrogate_keys(
    fact_data,
    dim_table,
    natural_key_fact,
    natural_key_dim,
    surrogate_key_col
) %}

    SELECT
        f.*,
        COALESCE(
            d_current.{{ surrogate_key_col }},
            d_history.{{ surrogate_key_col }},
            'UNKNOWN'
        ) AS {{ surrogate_key_col }}
    FROM {{ fact_data }} f
    
    -- Try current dimension record first
    LEFT JOIN {{ dim_table }} d_current
        ON f.{{ natural_key_fact }} = d_current.{{ natural_key_dim }}
        AND d_current.is_current = TRUE
        AND f.order_datetime BETWEEN d_current.valid_from AND d_current.valid_to
    
    -- Fall back to historical record
    LEFT JOIN {{ dim_table }} d_history
        ON f.{{ natural_key_fact }} = d_history.{{ natural_key_dim }}
        AND f.order_datetime BETWEEN d_history.valid_from AND d_history.valid_to
        AND d_history.is_current = FALSE
    
    WHERE d_current.{{ surrogate_key_col }} IS NOT NULL 
       OR d_history.{{ surrogate_key_col }} IS NOT NULL

{% endmacro %}


{#
-- ============================================================
-- EXAMPLE USAGE IN MODELS:
-- ============================================================

-- 1. Generate SK for new dimension record:
SELECT 
    {{ generate_surrogate_key(['driver_id', 'license_number'], 'dim_driver') }} AS driver_sk,
    *
FROM {{ ref('stg_driver') }}

-- 2. Lookup existing SK:
SELECT 
    COALESCE(
        {{ lookup_surrogate_key('dim_driver', 'driver_id', 'driver_id') }},
        {{ generate_surrogate_key(['driver_id'], 'dim_driver') }}
    ) AS driver_sk

-- 3. Validate SK integrity:
{{ validate_surrogate_keys('fct_delivery', 'dim_driver', 'driver_sk') }}

-- ============================================================
#}