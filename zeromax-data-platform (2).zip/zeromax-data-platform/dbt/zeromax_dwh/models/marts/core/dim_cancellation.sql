{{
  config(
    materialized='table',
    tags=['gold', 'dimension', 'cancellation', 'reference'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: DIM_CANCELLATION
-- ============================================================
-- Cancellation reason reference dimension.
-- Maps cancellation reasons to categories and controllability.
-- ============================================================

WITH cancellation_reasons AS (
    SELECT * FROM (VALUES
        ('Customer not available', 'Customer Issue', FALSE, 
         'Customer was not at the delivery location'),
        ('Wrong address provided', 'Customer Issue', TRUE, 
         'Incorrect address entered by customer'),
        ('Customer cancelled', 'Customer Issue', FALSE, 
         'Customer voluntarily cancelled the order'),
        ('Customer refused delivery', 'Customer Issue', FALSE, 
         'Customer refused to accept the delivery'),
        
        ('Restaurant closed', 'Restaurant Issue', TRUE, 
         'Restaurant was closed at order time'),
        ('Item out of stock', 'Restaurant Issue', FALSE, 
         'Ordered items were not available'),
        ('Restaurant delayed >30 min', 'Restaurant Issue', TRUE, 
         'Restaurant preparation exceeded 30 minutes'),
        ('Wrong order prepared', 'Restaurant Issue', TRUE, 
         'Restaurant prepared incorrect items'),
        
        ('Driver accident', 'Driver Issue', FALSE, 
         'Driver met with an accident en route'),
        ('Vehicle breakdown', 'Driver Issue', TRUE, 
         'Delivery vehicle broke down'),
        ('Fuel shortage', 'Driver Issue', TRUE, 
         'Vehicle ran out of fuel'),
        ('Driver unavailable', 'Driver Issue', FALSE, 
         'Driver became unavailable during delivery'),
        
        ('Extreme weather', 'External Factor', FALSE, 
         'Severe weather conditions prevented delivery'),
        ('Security concerns', 'External Factor', FALSE, 
         'Security situation in delivery area'),
        ('Bad road conditions', 'External Factor', FALSE, 
         'Road damage or flooding'),
        ('Route blockage', 'External Factor', FALSE, 
         'Road blocked due to protest/accident'),
        
        ('System error', 'Technical Issue', TRUE, 
         'App or system malfunction'),
        ('Payment failed', 'Technical Issue', TRUE, 
         'Payment processing error')
    ) AS c(reason, category, is_controllable, description)
)

SELECT
    -- Surrogate Key
    ROW_NUMBER() OVER (ORDER BY category, reason) AS cancel_sk,
    
    -- Cancellation Attributes
    reason AS cancellation_reason,
    category AS cancellation_category,
    is_controllable AS is_controllable_cancel,
    description AS cancellation_description,
    
    -- Derived Attributes
    
    -- Accountability
    CASE
        WHEN category = 'Customer Issue' THEN 'Customer'
        WHEN category = 'Restaurant Issue' THEN 'Restaurant'
        WHEN category = 'Driver Issue' THEN 'Driver'
        WHEN category = 'External Factor' THEN 'External'
        WHEN category = 'Technical Issue' THEN 'Platform'
    END AS accountable_party,
    
    -- Is Refundable
    CASE
        WHEN category IN ('Restaurant Issue', 'Technical Issue') THEN TRUE
        WHEN category = 'Driver Issue' AND is_controllable THEN TRUE
        WHEN category = 'External Factor' THEN FALSE
        ELSE FALSE
    END AS is_refundable,
    
    -- Is Preventable
    CASE
        WHEN is_controllable THEN 'Preventable'
        ELSE 'Unpreventable'
    END AS preventability,
    
    -- Customer Compensation
    CASE
        WHEN category = 'Restaurant Issue' THEN 'Full Refund + Coupon'
        WHEN category = 'Technical Issue' THEN 'Full Refund'
        WHEN category = 'Driver Issue' AND is_controllable THEN 'Full Refund'
        WHEN category = 'External Factor' THEN 'No Compensation (Force Majeure)'
        WHEN category = 'Customer Issue' AND reason = 'Wrong address provided' THEN 'Partial Refund'
        ELSE 'Case-by-Case'
    END AS compensation_policy,
    
    -- SLA Impact
    CASE
        WHEN category IN ('Restaurant Issue', 'Driver Issue') THEN 'Internal SLA Breach'
        WHEN category = 'Customer Issue' THEN 'No SLA Breach'
        ELSE 'Force Majeure'
    END AS sla_impact,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'dim_cancellation' AS dw_source

FROM cancellation_reasons