{#
-- ============================================================
-- CUSTOM SCHEMA NAME GENERATOR
-- ============================================================
-- Overrides dbt's default schema naming.
-- Development: dbt_<username>_<custom_schema>
-- Production: <custom_schema> (no prefix)
-- ============================================================
#}

{% macro generate_schema_name(custom_schema_name, node) -%}

    {%- set default_schema = target.schema -%}
    
    {%- if target.name in ('prod', 'production') -%}
        -- Production: Use custom schema or default
        {%- if custom_schema_name is none -%}
            {{ default_schema }}
        {%- else -%}
            {{ custom_schema_name | trim }}
        {%- endif -%}
    
    {%- elif target.name == 'staging' -%}
        -- Staging: Prefix with staging_
        {{ 'staging_' + custom_schema_name | trim if custom_schema_name else 'staging_' + default_schema }}
    
    {%- elif target.name == 'ci' -%}
        -- CI: Prefix with PR number
        {%- set pr_number = env_var('PR_NUMBER', '0000') -%}
        {{ 'ci_pr_' + pr_number + '_' + custom_schema_name | trim if custom_schema_name else 'ci_pr_' + pr_number }}
    
    {%- else -%}
        -- Development: Prefix with username
        {%- set user = env_var('USER', 'developer') -%}
        {{ user + '_' + custom_schema_name | trim if custom_schema_name else user + '_' + default_schema }}
    
    {%- endif -%}

{%- endmacro %}