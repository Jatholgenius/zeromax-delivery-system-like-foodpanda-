"""
================================================================================
ZEROMAX LOGISTICS - CUSTOM SENSOR OPERATORS
================================================================================
Custom sensors for data availability, freshness, and pipeline conditions.
================================================================================
"""

from datetime import datetime, timedelta
from typing import Dict, Optional

from airflow.sensors.base import BaseSensorOperator
from airflow.utils.decorators import apply_defaults
from airflow.exceptions import AirflowSensorTimeout


class DataAvailabilitySensor(BaseSensorOperator):
    """
    Sensor that waits for data to be available in a table.
    
    Checks both row count and freshness.
    """
    
    template_fields = ["table_name", "sql"]
    ui_color = "#7B68EE"
    
    @apply_defaults
    def __init__(
        self,
        table_name: str,
        snowflake_conn_id: str = "snowflake_default",
        min_rows: int = 1,
        max_wait_hours: int = 2,
        poke_interval: int = 300,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.table_name = table_name
        self.snowflake_conn_id = snowflake_conn_id
        self.min_rows = min_rows
        self.max_wait_hours = max_wait_hours
        self.poke_interval = poke_interval
    
    def poke(self, context: Dict) -> bool:
        """Check if data is available."""
        from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
        
        hook = SnowflakeHook(snowflake_conn_id=self.snowflake_conn_id)
        
        try:
            # Check row count
            result = hook.get_first(f"SELECT COUNT(*) FROM {self.table_name}")
            row_count = result[0] if result else 0
            
            if row_count < self.min_rows:
                self.log.info(
                    f"Waiting for data in {self.table_name}: "
                    f"{row_count}/{self.min_rows} rows"
                )
                return False
            
            # Check freshness (last 24 hours)
            freshness_result = hook.get_first(
                f"SELECT MAX(dw_updated_at) FROM {self.table_name}"
            )
            
            if freshness_result and freshness_result[0]:
                age_hours = (datetime.now() - freshness_result[0]).total_seconds() / 3600
                
                if age_hours > 24:
                    self.log.warning(f"Data in {self.table_name} is {age_hours:.1f}h old")
            
            self.log.info(f"Data available in {self.table_name}: {row_count:,} rows")
            return True
            
        except Exception as e:
            self.log.error(f"Error checking {self.table_name}: {e}")
            return False


class KafkaLagSensor(BaseSensorOperator):
    """
    Sensor that monitors Kafka consumer lag.
    """
    
    @apply_defaults
    def __init__(
        self,
        topic: str,
        group_id: str,
        max_lag: int = 1000,
        kafka_conn_id: str = "kafka_default",
        poke_interval: int = 60,
        timeout: int = 600,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.topic = topic
        self.group_id = group_id
        self.max_lag = max_lag
        self.kafka_conn_id = kafka_conn_id
        self.poke_interval = poke_interval
        self.timeout = timeout
    
    def poke(self, context: Dict) -> bool:
        """Check consumer lag."""
        from plugins.hooks.kafka_hook import ZeroMaxKafkaHook
        
        hook = ZeroMaxKafkaHook(kafka_conn_id=self.kafka_conn_id)
        
        lag = hook.get_topic_lag(self.topic, self.group_id)
        total_lag = sum(lag.values()) if lag else 0
        
        if total_lag > self.max_lag:
            self.log.info(f"Consumer lag for {self.topic}: {total_lag} (max: {self.max_lag})")
            return False
        
        self.log.info(f"Consumer lag acceptable: {total_lag}")
        return True


class DbtModelSensor(BaseSensorOperator):
    """
    Sensor that checks if a dbt model has been run successfully.
    """
    
    template_fields = ["model_name"]
    
    @apply_defaults
    def __init__(
        self,
        model_name: str,
        snowflake_conn_id: str = "snowflake_default",
        poke_interval: int = 300,
        timeout: int = 3600,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.model_name = model_name
        self.snowflake_conn_id = snowflake_conn_id
        self.poke_interval = poke_interval
        self.timeout = timeout
    
    def poke(self, context: Dict) -> bool:
        """Check if model has fresh data."""
        from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
        
        hook = SnowflakeHook(snowflake_conn_id=self.snowflake_conn_id)
        
        # Check if table exists and has recent data
        result = hook.get_first(
            f"SELECT MAX(dw_updated_at) FROM {self.model_name}"
        )
        
        if result and result[0]:
            age_hours = (datetime.now() - result[0]).total_seconds() / 3600
            
            if age_hours < 6:
                self.log.info(f"Model {self.model_name} is fresh ({age_hours:.1f}h)")
                return True
        
        self.log.info(f"Waiting for model {self.model_name} to be updated...")
        return False


class ExternalAPISensor(BaseSensorOperator):
    """
    Sensor that checks if an external API is available.
    """
    
    @apply_defaults
    def __init__(
        self,
        api_name: str,
        url: str,
        expected_status: int = 200,
        poke_interval: int = 60,
        timeout: int = 300,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.api_name = api_name
        self.url = url
        self.expected_status = expected_status
        self.poke_interval = poke_interval
        self.timeout = timeout
    
    def poke(self, context: Dict) -> bool:
        """Check API availability."""
        import requests
        
        try:
            response = requests.get(self.url, timeout=10)
            
            if response.status_code == self.expected_status:
                self.log.info(f"API {self.api_name} is available")
                return True
            
            self.log.warning(
                f"API {self.api_name} returned {response.status_code} "
                f"(expected {self.expected_status})"
            )
            return False
            
        except requests.RequestException as e:
            self.log.warning(f"API {self.api_name} not available: {e}")
            return False