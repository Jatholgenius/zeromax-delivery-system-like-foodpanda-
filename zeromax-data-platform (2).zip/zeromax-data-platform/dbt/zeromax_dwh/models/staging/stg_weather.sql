{{
  config(
    materialized='table',
    cluster_by=['weather_date', 'city'],
    tags=['staging', 'silver', 'weather']
  )
}}

-- ============================================================
-- STAGING: STG_WEATHER
-- ============================================================
-- Bronze → Silver transformation for weather data.
-- Source: OpenWeatherMap API (hourly observations)
-- ============================================================

WITH source AS (
    SELECT * FROM {{ source('bronze', 'weather_api') }}
),

deduped AS (
    SELECT *
    FROM source
    QUALIFY ROW_NUMBER() OVER (
        PARTITION BY observation_timestamp, city 
        ORDER BY ingestion_timestamp DESC
    ) = 1
),

cleaned AS (
    SELECT
        -- Primary Key (generated)
        weather_id,
        
        -- Temporal
        CAST(observation_timestamp AS TIMESTAMP) AS observation_timestamp,
        CAST(observation_timestamp AS DATE) AS weather_date,
        EXTRACT(HOUR FROM observation_timestamp) AS observation_hour,
        
        -- Location
        city,
        country_code,
        CAST(lat AS DECIMAL(10,6)) AS latitude,
        CAST(lon AS DECIMAL(10,6)) AS longitude,
        
        -- Weather Condition
        weather_condition,
        weather_description,
        weather_icon_code,
        
        -- Temperature
        CAST(temperature_c AS DECIMAL(5,1)) AS temperature_c,
        CAST(feels_like_c AS DECIMAL(5,1)) AS feels_like_c,
        CAST(temp_min_c AS DECIMAL(5,1)) AS temp_min_c,
        CAST(temp_max_c AS DECIMAL(5,1)) AS temp_max_c,
        
        -- Humidity & Pressure
        CAST(humidity_pct AS INTEGER) AS humidity_pct,
        CAST(pressure_hpa AS INTEGER) AS pressure_hpa,
        
        -- Wind
        CAST(wind_speed_kmh AS DECIMAL(6,2)) AS wind_speed_kmh,
        CAST(wind_gust_kmh AS DECIMAL(6,2)) AS wind_gust_kmh,
        wind_direction_deg,
        
        -- Visibility & Clouds
        CAST(visibility_km AS DECIMAL(6,2)) AS visibility_km,
        CAST(cloud_coverage_pct AS INTEGER) AS cloud_coverage_pct,
        
        -- Precipitation
        CAST(rain_mm AS DECIMAL(6,2)) AS rain_mm,
        CAST(snow_mm AS DECIMAL(6,2)) AS snow_mm,
        
        -- Derived: Severity Level
        CASE
            WHEN weather_condition IN ('Thunderstorm') THEN 4
            WHEN weather_condition IN ('Dust Storm', 'Fog') THEN 3
            WHEN weather_condition IN ('Rain', 'Drizzle') THEN 2
            WHEN weather_condition IN ('Cloudy', 'Hot Wind') THEN 1
            ELSE 0  -- Clear, Sunny
        END AS severity_level,
        
        -- Derived: Delivery Delay Multiplier
        CASE
            WHEN weather_condition = 'Thunderstorm' THEN 1.70
            WHEN weather_condition = 'Fog' THEN 1.50
            WHEN weather_condition = 'Dust Storm' THEN 1.40
            WHEN weather_condition = 'Rain' THEN 1.35
            WHEN weather_condition = 'Drizzle' THEN 1.15
            WHEN weather_condition = 'Hot Wind' THEN 1.20
            WHEN weather_condition = 'Cloudy' THEN 1.05
            ELSE 1.00  -- Clear, Sunny
        END AS delay_multiplier,
        
        -- Derived: Is Extreme Weather
        CASE
            WHEN weather_condition IN ('Thunderstorm', 'Dust Storm') THEN TRUE
            WHEN wind_speed_kmh > 50 THEN TRUE
            WHEN visibility_km < 1 THEN TRUE
            WHEN temperature_c > 42 THEN TRUE
            ELSE FALSE
        END AS is_extreme_weather,
        
        -- Derived: Temperature Category
        CASE
            WHEN temperature_c < 10 THEN 'Cold'
            WHEN temperature_c < 18 THEN 'Cool'
            WHEN temperature_c < 28 THEN 'Mild'
            WHEN temperature_c < 35 THEN 'Warm'
            WHEN temperature_c < 40 THEN 'Hot'
            ELSE 'Extreme Heat'
        END AS temperature_category,
        
        -- Sunrise/Sunset
        CAST(sunrise AS TIMESTAMP) AS sunrise_time,
        CAST(sunset AS TIMESTAMP) AS sunset_time,
        CASE 
            WHEN observation_timestamp BETWEEN sunrise AND sunset THEN TRUE 
            ELSE FALSE 
        END AS is_daytime,
        
        -- Metadata
        CAST(ingestion_timestamp AS TIMESTAMP) AS ingested_at,
        CURRENT_TIMESTAMP() AS dw_created_at,
        CURRENT_TIMESTAMP() AS dw_updated_at,
        'stg_weather' AS dw_source
        
    FROM deduped
)

SELECT * FROM cleaned
WHERE observation_timestamp IS NOT NULL
  AND city IS NOT NULL
  AND temperature_c BETWEEN -10 AND 55
  AND humidity_pct BETWEEN 0 AND 100
  AND wind_speed_kmh >= 0