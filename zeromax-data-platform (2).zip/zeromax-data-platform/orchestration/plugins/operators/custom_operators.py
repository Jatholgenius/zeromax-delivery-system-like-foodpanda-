"""
================================================================================
ZEROMAX LOGISTICS - CUSTOM AIRFLOW OPERATORS
================================================================================
Custom operators for ZeroMax-specific pipeline tasks.
Includes: GreatExpectationsOperator, DataFreshnessSensor, SlackAlertOperator
================================================================================
"""

from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any

from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.sensors.base import BaseSensorOperator
from airflow.exceptions import AirflowException
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator


class GreatExpectationsOperator(BaseOperator):
    """
    Executes a Great Expectations checkpoint.
    
    Args:
        checkpoint_name: Name of GE checkpoint to run
        expectation_suite: GE expectation suite name
        batch_kwargs: Batch configuration for validation
        fail_on_error: Whether to fail the task on validation errors
    """
    
    template_fields = ["checkpoint_name", "batch_kwargs"]
    ui_color = "#4B9CD3"
    
    @apply_defaults
    def __init__(
        self,
        checkpoint_name: str,
        expectation_suite: str = None,
        batch_kwargs: Dict = None,
        fail_on_error: bool = True,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.checkpoint_name = checkpoint_name
        self.expectation_suite = expectation_suite
        self.batch_kwargs = batch_kwargs or {}
        self.fail_on_error = fail_on_error
    
    def execute(self, context: Dict) -> Dict:
        """Run Great Expectations checkpoint."""
        import great_expectations as ge
        
        self.log.info(f"Running GE checkpoint: {self.checkpoint_name}")
        
        try:
            context_ge = ge.get_context()
            result = context_ge.run_checkpoint(
                checkpoint_name=self.checkpoint_name,
                expectation_suite_name=self.expectation_suite,
                batch_request=self.batch_kwargs,
            )
            
            # Parse results
            stats = result.list_validation_results()[0]
            expectation_results = stats.get("results", [])
            
            total = len(expectation_results)
            passed = sum(1 for r in expectation_results if r.get("success"))
            failed = total - passed
            
            summary = {
                "checkpoint": self.checkpoint_name,
                "success": result.success,
                "total_expectations": total,
                "passed": passed,
                "failed": failed,
                "run_time": str(result.run_id),
            }
            
            self.log.info(f"GE Results: {passed}/{total} passed")
            
            # Push to XCom
            context["task_instance"].xcom_push(key="ge_results", value=summary)
            
            if not result.success and self.fail_on_error:
                failed_checks = [
                    r["expectation_config"]["expectation_type"]
                    for r in expectation_results
                    if not r.get("success")
                ]
                raise AirflowException(
                    f"GE checkpoint failed: {failed}/{total} checks failed. "
                    f"Failed checks: {failed_checks[:5]}"
                )
            
            return summary
            
        except Exception as e:
            self.log.error(f"GE checkpoint error: {str(e)}")
            if self.fail_on_error:
                raise
            return {"error": str(e)}


class DataFreshnessSensor(BaseSensorOperator):
    """
    Sensor that checks if data is fresh before proceeding.
    
    Args:
        connection_id: Database connection ID
        sql: SQL query to check freshness
        threshold_minutes: Maximum allowed data age in minutes
        poke_interval: Seconds between checks
        timeout: Maximum seconds to wait
    """
    
    template_fields = ["sql"]
    ui_color = "#F4A460"
    
    @apply_defaults
    def __init__(
        self,
        connection_id: str,
        sql: str,
        threshold_minutes: int = 30,
        poke_interval: int = 300,
        timeout: int = 3600,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.connection_id = connection_id
        self.sql = sql
        self.threshold_minutes = threshold_minutes
        self.poke_interval = poke_interval
        self.timeout = timeout
    
    def poke(self, context: Dict) -> bool:
        """Check if data is fresh."""
        from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
        
        hook = SnowflakeHook(snowflake_conn_id=self.connection_id)
        result = hook.get_first(self.sql)
        
        if not result:
            self.log.warning("No data returned from freshness check")
            return False
        
        last_updated = result[0]
        
        if last_updated is None:
            self.log.warning("Last updated timestamp is NULL")
            return False
        
        # Calculate age in minutes
        if isinstance(last_updated, str):
            last_updated = datetime.fromisoformat(last_updated)
        
        age_minutes = (datetime.now() - last_updated).total_seconds() / 60
        
        is_fresh = age_minutes <= self.threshold_minutes
        
        if is_fresh:
            self.log.info(f"Data is fresh: {age_minutes:.1f} min old (threshold: {self.threshold_minutes} min)")
        else:
            self.log.warning(f"Data is stale: {age_minutes:.1f} min old (threshold: {self.threshold_minutes} min)")
        
        return is_fresh


class SlackAlertOperator(SlackWebhookOperator):
    """
    Enhanced Slack operator with alert formatting.
    
    Args:
        alert_type: 'success', 'warning', 'error', 'info'
        title: Alert title
        message: Alert message body
        include_task_info: Include task execution details
    """
    
    template_fields = ["title", "message", "http_conn_id"]
    ui_color = "#E91E63"
    
    @apply_defaults
    def __init__(
        self,
        alert_type: str = "info",
        title: str = "",
        message: str = "",
        include_task_info: bool = True,
        *args,
        **kwargs,
    ):
        self.alert_type = alert_type
        self.title = title
        self.message = message
        self.include_task_info = include_task_info
        
        # Set color based on alert type
        color_map = {
            "success": "#36A64F",
            "warning": "#FFC107",
            "error": "#E91E63",
            "critical": "#D32F2F",
            "info": "#2196F3",
        }
        
        # Build Slack message
        task_info = ""
        if include_task_info:
            task_info = f"\n*DAG:* {{{{ dag.dag_id }}}}\n*Task:* {{{{ task.task_id }}}}\n*Date:* {{{{ ds }}}}"
        
        slack_message = f"*{title}*\n{message}{task_info}"
        
        super().__init__(
            message=slack_message,
            username=f"ZeroMax {alert_type.upper()}",
            icon_emoji={
                "success": ":white_check_mark:",
                "warning": ":warning:",
                "error": ":x:",
                "critical": ":rotating_light:",
                "info": ":information_source:",
            }.get(alert_type, ":bell:"),
            *args,
            **kwargs,
        )
    
    def execute(self, context: Dict) -> Any:
        """Execute with context rendering."""
        self.log.info(f"Sending {self.alert_type} alert: {self.title}")
        return super().execute(context)


class SnowflakeQueryOperator(BaseOperator):
    """
    Executes Snowflake SQL with result logging and error handling.
    
    Args:
        sql: SQL query to execute
        snowflake_conn_id: Snowflake connection ID
        warehouse: Warehouse to use
        database: Database to use
        schema: Schema to use
    """
    
    template_fields = ["sql"]
    ui_color = "#29B6F6"
    
    @apply_defaults
    def __init__(
        self,
        sql: str,
        snowflake_conn_id: str = "snowflake_default",
        warehouse: str = None,
        database: str = None,
        schema: str = None,
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.sql = sql
        self.snowflake_conn_id = snowflake_conn_id
        self.warehouse = warehouse
        self.database = database
        self.schema = schema
    
    def execute(self, context: Dict) -> Any:
        """Execute SQL in Snowflake."""
        from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
        
        hook = SnowflakeHook(snowflake_conn_id=self.snowflake_conn_id)
        
        # Build execution context
        pre_queries = []
        if self.warehouse:
            pre_queries.append(f"USE WAREHOUSE {self.warehouse}")
        if self.database:
            pre_queries.append(f"USE DATABASE {self.database}")
        if self.schema:
            pre_queries.append(f"USE SCHEMA {self.schema}")
        
        full_sql = ";\n".join(pre_queries + [self.sql]) if pre_queries else self.sql
        
        self.log.info(f"Executing SQL on {self.snowflake_conn_id}")
        self.log.debug(f"SQL: {full_sql[:500]}...")
        
        try:
            result = hook.run(full_sql)
            self.log.info("Query executed successfully")
            
            # Push to XCom
            context["task_instance"].xcom_push(key="query_result", value=result)
            
            return result
            
        except Exception as e:
            self.log.error(f"Query failed: {str(e)}")
            raise AirflowException(f"Snowflake query failed: {str(e)}")


class DataVolumeSensor(BaseSensorOperator):
    """
    Sensor that checks if a table has expected row count.
    
    Args:
        table_name: Fully qualified table name
        min_rows: Minimum expected rows
        snowflake_conn_id: Snowflake connection
    """
    
    @apply_defaults
    def __init__(
        self,
        table_name: str,
        min_rows: int = 1,
        snowflake_conn_id: str = "snowflake_default",
        *args,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.table_name = table_name
        self.min_rows = min_rows
        self.snowflake_conn_id = snowflake_conn_id
    
    def poke(self, context: Dict) -> bool:
        """Check row count."""
        from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
        
        hook = SnowflakeHook(snowflake_conn_id=self.snowflake_conn_id)
        result = hook.get_first(f"SELECT COUNT(*) FROM {self.table_name}")
        
        if result:
            count = result[0]
            self.log.info(f"Table {self.table_name}: {count:,} rows (min: {self.min_rows:,})")
            return count >= self.min_rows
        
        return False