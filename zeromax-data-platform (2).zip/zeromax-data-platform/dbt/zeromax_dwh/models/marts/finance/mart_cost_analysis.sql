{{
  config(
    materialized='table',
    cluster_by=['month', 'cost_category'],
    tags=['gold', 'finance', 'cost', 'sensitive'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE finance_analyst",
      "GRANT SELECT ON {{ this }} TO ROLE executive"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: MART_COST_ANALYSIS
-- ============================================================
-- Detailed cost breakdown and optimization analysis.
-- Granularity: Monthly by zone, vehicle, cost category.
-- ============================================================

WITH cost_base AS (
    SELECT
        DATE_TRUNC('month', fd.order_datetime) AS month,
        EXTRACT(YEAR FROM fd.order_datetime) AS year,
        EXTRACT(MONTH FROM fd.order_datetime) AS month_num,
        
        dz.zone_name,
        dv.vehicle_category,
        dv.vehicle_type,
        dp.payment_method,
        
        -- Cost breakdown
        fd.driver_cost_pkr,
        fd.platform_fee_pkr,
        fd.delay_penalty_pkr,
        (fd.delivery_fee_pkr - fd.profit_pkr - fd.driver_cost_pkr - fd.platform_fee_pkr - fd.delay_penalty_pkr) AS other_cost_pkr,
        
        -- Revenue
        fd.delivery_fee_pkr AS revenue_pkr,
        fd.profit_pkr,
        
        -- Volume
        fd.distance_km,
        1 AS delivery_count
        
    FROM {{ ref('fct_delivery') }} fd
    INNER JOIN {{ ref('dim_zone') }} dz
        ON fd.zone_key = dz.zone_sk
    INNER JOIN {{ ref('dim_vehicle') }} dv
        ON fd.vehicle_key = dv.vehicle_sk
    INNER JOIN {{ ref('dim_payment') }} dp
        ON fd.payment_key = dp.payment_sk
    WHERE fd.order_datetime >= DATEADD(year, -1, CURRENT_DATE())
),

-- Unpivot cost categories
cost_unpivoted AS (
    SELECT
        month, year, month_num,
        zone_name, vehicle_category, vehicle_type, payment_method,
        distance_km, delivery_count, revenue_pkr, profit_pkr,
        'Driver Cost' AS cost_category,
        driver_cost_pkr AS cost_amount
    FROM cost_base
    
    UNION ALL
    
    SELECT
        month, year, month_num,
        zone_name, vehicle_category, vehicle_type, payment_method,
        distance_km, delivery_count, revenue_pkr, profit_pkr,
        'Platform Fee' AS cost_category,
        platform_fee_pkr AS cost_amount
    FROM cost_base
    
    UNION ALL
    
    SELECT
        month, year, month_num,
        zone_name, vehicle_category, vehicle_type, payment_method,
        distance_km, delivery_count, revenue_pkr, profit_pkr,
        'Delay Penalty' AS cost_category,
        delay_penalty_pkr AS cost_amount
    FROM cost_base
    
    UNION ALL
    
    SELECT
        month, year, month_num,
        zone_name, vehicle_category, vehicle_type, payment_method,
        distance_km, delivery_count, revenue_pkr, profit_pkr,
        'Other Costs' AS cost_category,
        other_cost_pkr AS cost_amount
    FROM cost_base
)

SELECT
    month,
    year,
    month_num,
    zone_name,
    vehicle_category,
    vehicle_type,
    payment_method,
    cost_category,
    
    -- Volume
    SUM(delivery_count) AS total_deliveries,
    SUM(distance_km) AS total_distance_km,
    
    -- Cost metrics
    SUM(cost_amount) AS total_cost_pkr,
    ROUND(AVG(cost_amount), 0) AS avg_cost_per_delivery_pkr,
    ROUND(SUM(cost_amount) * 1.0 / NULLIF(SUM(distance_km), 0), 2) AS cost_per_km_pkr,
    
    -- Revenue metrics
    SUM(revenue_pkr) AS total_revenue_pkr,
    SUM(profit_pkr) AS total_profit_pkr,
    
    -- Percentage of total costs
    ROUND(
        SUM(cost_amount) * 100.0 / SUM(SUM(cost_amount)) OVER (
            PARTITION BY month, zone_name, vehicle_category
        ), 2
    ) AS cost_pct_of_total,
    
    -- Cost Ratio (cost / revenue)
    ROUND(
        SUM(cost_amount) * 100.0 / NULLIF(SUM(revenue_pkr), 0), 2
    ) AS cost_ratio_pct,
    
    -- Month over Month cost change
    ROUND(
        (SUM(cost_amount) - LAG(SUM(cost_amount)) OVER (
            PARTITION BY zone_name, vehicle_category, cost_category 
            ORDER BY month
        )) * 100.0 / NULLIF(LAG(SUM(cost_amount)) OVER (
            PARTITION BY zone_name, vehicle_category, cost_category 
            ORDER BY month
        ), 0), 2
    ) AS mom_cost_change_pct,
    
    -- Cost per km trend
    ROUND(AVG(SUM(cost_amount) * 1.0 / NULLIF(SUM(distance_km), 0)) OVER (
        PARTITION BY zone_name, vehicle_category, cost_category 
        ORDER BY month
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ), 2) AS cost_per_km_3m_avg,
    
    -- Optimization potential
    CASE
        WHEN cost_category = 'Delay Penalty' AND SUM(cost_amount) > 10000 
            THEN 'High - Review delay root causes'
        WHEN cost_category = 'Driver Cost' AND cost_ratio_pct > 60 
            THEN 'Medium - Optimize driver allocation'
        WHEN cost_category = 'Platform Fee' AND cost_ratio_pct > 20 
            THEN 'Medium - Review payment mix'
        ELSE 'Low'
    END AS optimization_potential,
    
    -- Cost efficiency tier
    CASE
        WHEN cost_ratio_pct <= 50 THEN 'Excellent'
        WHEN cost_ratio_pct <= 65 THEN 'Good'
        WHEN cost_ratio_pct <= 80 THEN 'Fair'
        ELSE 'Poor'
    END AS cost_efficiency_tier,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'mart_cost_analysis' AS dw_source

FROM cost_unpivoted
GROUP BY 
    month, year, month_num,
    zone_name, vehicle_category, vehicle_type,
    payment_method, cost_category