"""
================================================================================
ZEROMAX LOGISTICS - SILVER LAYER CHECKPOINT
================================================================================
Great Expectations checkpoint for Silver layer validation.
Validates cleaned/transformed data before Gold layer.

Checks:
- Referential integrity
- Data type consistency
- Business rule compliance
- SCD Type 2 validity
- Transformation correctness
================================================================================
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import Dict, List, Optional

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ============================================
# SILVER LAYER CONFIGURATION
# ============================================

SILVER_TABLES = {
    "STG_DELIVERY": {
        "suite": "silver_delivery_suite",
        "critical": True,
        "foreign_keys": {
            "driver_id": "STG_DRIVER.driver_id",
            "customer_id": "STG_CUSTOMER.customer_id",
            "restaurant_id": "STG_RESTAURANT.restaurant_id",
        },
    },
    "STG_DRIVER": {
        "suite": "silver_driver_suite",
        "critical": True,
        "unique_keys": ["driver_id"],
    },
    "STG_CUSTOMER": {
        "suite": "silver_customer_suite",
        "critical": True,
        "unique_keys": ["customer_id"],
    },
    "STG_RESTAURANT": {
        "suite": "silver_restaurant_suite",
        "critical": True,
        "unique_keys": ["restaurant_id"],
    },
    "INT_DELIVERY_ENRICHED": {
        "suite": "silver_enriched_suite",
        "critical": True,
    },
}

BUSINESS_RULES = {
    "valid_coordinates": {
        "description": "Coordinates must be within Karachi bounds",
        "rule": "cust_lat BETWEEN 24.7 AND 25.1 AND cust_lon BETWEEN 66.8 AND 67.3",
    },
    "valid_distance": {
        "description": "Distance must be between 0.5 and 20 km",
        "rule": "distance_km BETWEEN 0.5 AND 20.0",
    },
    "valid_delivery_time": {
        "description": "Delivery time must be between 5 and 120 minutes",
        "rule": "delivery_duration_min BETWEEN 5 AND 120",
    },
    "valid_rating": {
        "description": "Rating must be between 1.0 and 5.0 or NULL",
        "rule": "(customer_rating IS NULL) OR (customer_rating BETWEEN 1.0 AND 5.0)",
    },
    "valid_status": {
        "description": "Status must be On-Time, Late, or Failed",
        "rule": "delivery_status IN ('On-Time', 'Late', 'Failed')",
    },
    "positive_fee": {
        "description": "Delivery fee must be positive",
        "rule": "delivery_fee_pkr >= 0",
    },
    "valid_prep_time": {
        "description": "Prep time must be between 3 and 60 minutes",
        "rule": "preparation_time_min BETWEEN 3 AND 60",
    },
}


class SilverLayerValidator:
    """
    Validates Silver layer data quality.
    Checks referential integrity, business rules, and transformations.
    """
    
    def __init__(self):
        self.results: Dict = {}
        self.validation_summary: Dict = {}
        self._snowflake_conn = None
    
    def _get_snowflake_connection(self):
        """Get Snowflake connection."""
        if self._snowflake_conn is None:
            import snowflake.connector
            
            self._snowflake_conn = snowflake.connector.connect(
                account=os.getenv("SNOWFLAKE_ACCOUNT"),
                user=os.getenv("SNOWFLAKE_USER"),
                password=os.getenv("SNOWFLAKE_PASSWORD"),
                warehouse="VALIDATION_WH",
                database="ZEROMAX_DWH_PROD",
                schema="SILVER",
            )
        
        return self._snowflake_conn
    
    def check_referential_integrity(self, table: str, fk_mappings: Dict) -> List[Dict]:
        """
        Check foreign key integrity.
        
        Args:
            table: Table with foreign keys
            fk_mappings: Dict of {fk_column: referenced_table.column}
            
        Returns:
            List of integrity check results
        """
        conn = self._get_snowflake_connection()
        cursor = conn.cursor()
        
        results = []
        
        for fk_column, ref in fk_mappings.items():
            ref_table, ref_column = ref.split(".")
            
            sql = f"""
                SELECT COUNT(*) AS orphan_count
                FROM {table} t
                LEFT JOIN {ref_table} r ON t.{fk_column} = r.{ref_column}
                WHERE t.{fk_column} IS NOT NULL
                  AND r.{ref_column} IS NULL
            """
            
            try:
                cursor.execute(sql)
                orphan_count = cursor.fetchone()[0]
                
                result = {
                    "table": table,
                    "check": "referential_integrity",
                    "fk_column": fk_column,
                    "ref_table": ref_table,
                    "orphan_count": orphan_count,
                    "status": "PASS" if orphan_count == 0 else "FAIL",
                }
                
                if orphan_count > 0:
                    logger.warning(f"  ⚠️  {table}.{fk_column}: {orphan_count} orphans")
                
                results.append(result)
                
            except Exception as e:
                logger.error(f"  ❌ Integrity check failed: {e}")
                results.append({
                    "table": table,
                    "check": "referential_integrity",
                    "fk_column": fk_column,
                    "status": "ERROR",
                    "error": str(e),
                })
        
        return results
    
    def check_uniqueness(self, table: str, unique_keys: List[str]) -> Dict:
        """
        Check uniqueness of key columns.
        
        Args:
            table: Table name
            unique_keys: List of columns that should be unique
            
        Returns:
            Validation result
        """
        conn = self._get_snowflake_connection()
        cursor = conn.cursor()
        
        cols = ", ".join(unique_keys)
        sql = f"""
            SELECT COUNT(*) AS total, COUNT(DISTINCT {cols}) AS unique_count
            FROM {table}
        """
        
        cursor.execute(sql)
        total, unique_count = cursor.fetchone()
        
        duplicates = total - unique_count
        
        result = {
            "table": table,
            "check": "uniqueness",
            "columns": unique_keys,
            "total_rows": total,
            "unique_rows": unique_count,
            "duplicates": duplicates,
            "status": "PASS" if duplicates == 0 else "FAIL",
        }
        
        if duplicates > 0:
            logger.warning(f"  ⚠️  {table}: {duplicates} duplicates on {unique_keys}")
        
        return result
    
    def check_business_rules(self, table: str) -> List[Dict]:
        """
        Check business rule compliance.
        
        Args:
            table: Table name
            
        Returns:
            List of business rule results
        """
        conn = self._get_snowflake_connection()
        cursor = conn.cursor()
        
        results = []
        
        for rule_name, rule_config in BUSINESS_RULES.items():
            sql = f"""
                SELECT 
                    COUNT(*) AS total,
                    SUM(CASE WHEN {rule_config['rule']} THEN 1 ELSE 0 END) AS passed,
                    SUM(CASE WHEN NOT ({rule_config['rule']}) THEN 1 ELSE 0 END) AS failed
                FROM {table}
            """
            
            try:
                cursor.execute(sql)
                total, passed, failed = cursor.fetchone()
                
                status = "PASS" if failed == 0 else "WARN" if (failed / total) < 0.05 else "FAIL"
                
                results.append({
                    "table": table,
                    "check": "business_rule",
                    "rule_name": rule_name,
                    "description": rule_config["description"],
                    "total": total,
                    "passed": passed,
                    "failed": failed,
                    "failure_rate_pct": round((failed / total) * 100, 2) if total > 0 else 0,
                    "status": status,
                })
                
                if failed > 0:
                    logger.warning(f"  ⚠️  {rule_name}: {failed}/{total} failed")
                
            except Exception as e:
                logger.error(f"  ❌ Rule check failed: {e}")
        
        return results
    
    def check_scd_type2_validity(self, table: str) -> Dict:
        """
        Check SCD Type 2 dimension validity.
        
        Checks:
        - No overlapping validity periods
        - Only one current record per natural key
        - valid_from < valid_to
        
        Args:
            table: SCD Type 2 table name
            
        Returns:
            Validation result
        """
        conn = self._get_snowflake_connection()
        cursor = conn.cursor()
        
        checks = {}
        
        # Check overlapping periods
        cursor.execute(f"""
            SELECT COUNT(*) FROM {table} a
            JOIN {table} b ON a.driver_id = b.driver_id 
                AND a.driver_sk != b.driver_sk
                AND a.valid_from < b.valid_to 
                AND b.valid_from < a.valid_to
        """)
        checks["overlapping_periods"] = cursor.fetchone()[0]
        
        # Check multiple current records
        cursor.execute(f"""
            SELECT COUNT(*) FROM (
                SELECT driver_id, COUNT(*) as cnt
                FROM {table}
                WHERE is_current = TRUE
                GROUP BY driver_id
                HAVING COUNT(*) > 1
            )
        """)
        checks["multiple_current"] = cursor.fetchone()[0]
        
        # Check invalid date ranges
        cursor.execute(f"""
            SELECT COUNT(*) FROM {table}
            WHERE valid_from >= valid_to
        """)
        checks["invalid_dates"] = cursor.fetchone()[0]
        
        total_issues = sum(checks.values())
        
        result = {
            "table": table,
            "check": "scd_type2_validity",
            "overlapping_periods": checks["overlapping_periods"],
            "multiple_current": checks["multiple_current"],
            "invalid_dates": checks["invalid_dates"],
            "total_issues": total_issues,
            "status": "PASS" if total_issues == 0 else "FAIL",
        }
        
        if total_issues > 0:
            logger.warning(f"  ⚠️  {table}: {total_issues} SCD issues")
        
        return result
    
    def validate_all(self) -> Dict:
        """
        Run all Silver layer validations.
        
        Returns:
            Validation summary
        """
        logger.info("=" * 60)
        logger.info("🔍 SILVER LAYER VALIDATION")
        logger.info("=" * 60)
        
        all_results = []
        
        for table, config in SILVER_TABLES.items():
            logger.info(f"\n📋 Checking: {table}")
            
            # Check referential integrity
            if config.get("foreign_keys"):
                fk_results = self.check_referential_integrity(table, config["foreign_keys"])
                all_results.extend(fk_results)
            
            # Check uniqueness
            if config.get("unique_keys"):
                unique_result = self.check_uniqueness(table, config["unique_keys"])
                all_results.append(unique_result)
            
            # Check business rules (for STG_DELIVERY and INT tables)
            if "DELIVERY" in table:
                rule_results = self.check_business_rules(table)
                all_results.extend(rule_results)
            
            # Check SCD Type 2 (for dimension tables)
            if "DRIVER" in table or "CUSTOMER" in table:
                scd_result = self.check_scd_type2_validity(table)
                all_results.append(scd_result)
        
        # Build summary
        total = len(all_results)
        passed = sum(1 for r in all_results if r.get("status") == "PASS")
        failed = sum(1 for r in all_results if r.get("status") in ["FAIL", "ERROR"])
        warnings = sum(1 for r in all_results if r.get("status") == "WARN")
        
        self.validation_summary = {
            "layer": "SILVER",
            "timestamp": datetime.now().isoformat(),
            "total_checks": total,
            "passed": passed,
            "failed": failed,
            "warnings": warnings,
            "overall_status": "PASS" if failed == 0 else "FAIL",
            "results": all_results,
        }
        
        return self.validation_summary
    
    def print_summary(self) -> None:
        """Print validation summary."""
        s = self.validation_summary
        
        print("\n" + "=" * 60)
        print("🏅 SILVER LAYER VALIDATION SUMMARY")
        print("=" * 60)
        print(f"  Status:   {s.get('overall_status', 'UNKNOWN')}")
        print(f"  Checks:   {s.get('total_checks', 0)}")
        print(f"  Passed:   {s.get('passed', 0)} ✅")
        print(f"  Failed:   {s.get('failed', 0)} ❌")
        print(f"  Warnings: {s.get('warnings', 0)} ⚠️")
        print("=" * 60)
        
        failures = [r for r in s.get("results", []) if r.get("status") in ["FAIL", "ERROR"]]
        if failures:
            print("\n🚨 FAILURES:")
            for f in failures[:10]:
                print(f"  • {f.get('table', '')}: {f.get('check', '')}")
    
    def save_report(self, filename: str = None) -> str:
        """Save report to JSON."""
        if filename is None:
            os.makedirs("reports", exist_ok=True)
            filename = f"reports/silver_validation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        with open(filename, "w") as f:
            json.dump(self.validation_summary, f, indent=2, default=str)
        
        logger.info(f"📄 Report saved: {filename}")
        return filename


def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Silver Layer Validator")
    parser.add_argument("--output", type=str, help="Output report path")
    parser.add_argument("--strict", action="store_true", help="Exit with error on failure")
    args = parser.parse_args()
    
    validator = SilverLayerValidator()
    validator.validate_all()
    validator.print_summary()
    
    if args.output:
        validator.save_report(args.output)
    else:
        validator.save_report()
    
    if args.strict and validator.validation_summary.get("overall_status") == "FAIL":
        sys.exit(1)


if __name__ == "__main__":
    main()