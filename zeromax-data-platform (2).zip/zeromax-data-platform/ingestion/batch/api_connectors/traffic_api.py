"""
================================================================================
ZEROMAX LOGISTICS - TRAFFIC API CONNECTOR
================================================================================
Fetches traffic data from Google Maps Traffic API.
Provides real-time congestion and travel time estimates.

Usage:
    python traffic_api.py
    python traffic_api.py --zones ZN001,ZN002,ZN003
    python traffic_api.py --interval 300  # 5 minutes
================================================================================
"""

import os
import sys
import json
import time
import logging
from datetime import datetime
from typing import Dict, List, Optional, Tuple
from pathlib import Path

import requests
import pandas as pd
import numpy as np
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

# ============================================
# CONFIGURATION
# ============================================

API_KEY = os.getenv("GOOGLE_MAPS_API_KEY", "")
DISTANCE_MATRIX_URL = "https://maps.googleapis.com/maps/api/distancematrix/json"
DIRECTIONS_URL = "https://maps.googleapis.com/maps/api/directions/json"

DATA_DIR = os.getenv("DATA_DIR", "data/bronze/traffic_api")

TRAFFIC_LEVELS = ["Low", "Low-Medium", "Medium", "High", "Severe", "Gridlock"]

# Karachi major routes for traffic sampling
ROUTES = [
    {"name": "Shahrah-e-Faisal", "start": (24.8700, 67.0500), "end": (24.8500, 67.1200)},
    {"name": "M.A. Jinnah Road", "start": (24.8600, 67.0200), "end": (24.8800, 67.0400)},
    {"name": "University Road", "start": (24.9100, 67.0800), "end": (24.8900, 67.1100)},
    {"name": "Korangi Road", "start": (24.8200, 67.0800), "end": (24.8400, 67.1300)},
    {"name": "Northern Bypass", "start": (24.9500, 67.0500), "end": (24.9200, 66.9800)},
    {"name": "Lyari Expressway", "start": (24.8800, 67.0200), "end": (24.8300, 66.9800)},
    {"name": "Tariq Road", "start": (24.8700, 67.0500), "end": (24.8800, 67.0600)},
    {"name": "Gulshan-e-Iqbal", "start": (24.9000, 67.0800), "end": (24.9100, 67.0900)},
]

ZONES = {
    "ZN001": {"name": "North Karachi", "lat": 24.9500, "lon": 67.0500},
    "ZN002": {"name": "South Karachi", "lat": 24.8100, "lon": 67.0300},
    "ZN003": {"name": "East Karachi", "lat": 24.9000, "lon": 67.1000},
    "ZN004": {"name": "West Karachi", "lat": 24.9200, "lon": 66.9800},
    "ZN005": {"name": "Central Karachi", "lat": 24.8800, "lon": 67.0450},
}


class TrafficAPIConnector:
    """
    Connector for Google Maps Traffic API.
    Provides real-time and simulated traffic data.
    """
    
    def __init__(self, api_key: str = None):
        self.api_key = api_key or API_KEY
        self.session = requests.Session()
        self.call_count = 0
        
        if not self.api_key:
            logger.warning("No API key provided. Using simulated traffic data.")
    
    def get_distance_matrix(
        self, 
        origins: List[Tuple[float, float]], 
        destinations: List[Tuple[float, float]],
        departure_time: str = "now",
    ) -> Optional[Dict]:
        """
        Get distance matrix from Google Maps API.
        
        Args:
            origins: List of (lat, lon) origin points
            destinations: List of (lat, lon) destination points
            departure_time: 'now' or specific timestamp
            
        Returns:
            Distance matrix response
        """
        if not self.api_key:
            return None
        
        origins_str = "|".join([f"{lat},{lon}" for lat, lon in origins])
        destinations_str = "|".join([f"{lat},{lon}" for lat, lon in destinations])
        
        params = {
            "origins": origins_str,
            "destinations": destinations_str,
            "departure_time": departure_time,
            "traffic_model": "best_guess",
            "key": self.api_key,
        }
        
        try:
            response = self.session.get(DISTANCE_MATRIX_URL, params=params, timeout=15)
            self.call_count += 1
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"API error {response.status_code}: {response.text[:100]}")
                return None
                
        except requests.RequestException as e:
            logger.error(f"Request failed: {e}")
            return None
    
    def calculate_traffic_level(
        self, 
        duration_in_traffic: int, 
        duration_free_flow: int
    ) -> Tuple[str, float, int]:
        """
        Calculate traffic level from duration comparison.
        
        Args:
            duration_in_traffic: Time with traffic (seconds)
            duration_free_flow: Free flow time (seconds)
            
        Returns:
            (traffic_level, delay_factor, severity)
        """
        if duration_free_flow == 0:
            return "Low", 1.0, 1
        
        ratio = duration_in_traffic / duration_free_flow
        
        if ratio < 1.1:
            return "Low", 1.0, 1
        elif ratio < 1.3:
            return "Low-Medium", 1.15, 2
        elif ratio < 1.5:
            return "Medium", 1.30, 2
        elif ratio < 1.8:
            return "High", 1.60, 3
        elif ratio < 2.2:
            return "Severe", 2.00, 4
        else:
            return "Gridlock", 2.50, 5
    
    def fetch_route_traffic(self, route: Dict) -> Optional[Dict]:
        """Fetch traffic data for a specific route."""
        result = self.get_distance_matrix(
            origins=[route["start"]],
            destinations=[route["end"]],
        )
        
        if result and result.get("rows"):
            element = result["rows"][0]["elements"][0]
            
            if element["status"] == "OK":
                duration_free = element.get("duration", {}).get("value", 0)
                duration_traffic = element.get("duration_in_traffic", {}).get("value", duration_free)
                distance = element.get("distance", {}).get("value", 0) / 1000  # meters to km
                
                traffic_level, delay_factor, severity = self.calculate_traffic_level(
                    duration_traffic, duration_free
                )
                
                return {
                    "route_name": route["name"],
                    "observation_timestamp": datetime.now().isoformat(),
                    "traffic_date": datetime.now().strftime("%Y-%m-%d"),
                    "traffic_hour": datetime.now().hour,
                    "start_lat": route["start"][0],
                    "start_lon": route["start"][1],
                    "end_lat": route["end"][0],
                    "end_lon": route["end"][1],
                    "distance_km": round(distance, 2),
                    "duration_free_flow_sec": duration_free,
                    "duration_in_traffic_sec": duration_traffic,
                    "traffic_level": traffic_level,
                    "delay_factor": delay_factor,
                    "severity_level": severity,
                    "delay_sec": duration_traffic - duration_free,
                    "congestion_pct": round((1 - duration_free / max(duration_traffic, 1)) * 100, 1),
                    "avg_speed_kmh": round((distance / max(duration_traffic, 1)) * 3600, 1),
                    "free_flow_speed_kmh": round((distance / max(duration_free, 1)) * 3600, 1),
                }
        
        return None
    
    def fetch_all_routes(self) -> pd.DataFrame:
        """Fetch traffic for all configured routes."""
        if not self.api_key:
            return self._generate_simulated_traffic()
        
        records = []
        
        for route in ROUTES:
            logger.info(f"Fetching traffic for {route['name']}...")
            data = self.fetch_route_traffic(route)
            if data:
                records.append(data)
            time.sleep(0.5)  # Rate limiting
        
        return pd.DataFrame(records)
    
    def fetch_zone_traffic(self, zone_id: str) -> Optional[Dict]:
        """Fetch traffic summary for a zone."""
        zone = ZONES.get(zone_id)
        if not zone:
            return None
        
        # Use zone center as origin/destination for multiple sample routes
        return {
            "zone_id": zone_id,
            "zone_name": zone["name"],
            "observation_timestamp": datetime.now().isoformat(),
            **self._simulate_zone_traffic(zone_id),
        }
    
    def _simulate_zone_traffic(self, zone_id: str) -> Dict:
        """Generate realistic simulated traffic for a zone."""
        hour = datetime.now().hour
        
        # Peak hour patterns
        if hour in [8, 9, 10]:  # Morning rush
            base_congestion = np.random.uniform(40, 70)
            traffic_level = np.random.choice(["Medium", "High", "Severe"], p=[0.2, 0.5, 0.3])
        elif hour in [17, 18, 19]:  # Evening rush
            base_congestion = np.random.uniform(50, 85)
            traffic_level = np.random.choice(["High", "Severe", "Gridlock"], p=[0.3, 0.5, 0.2])
        elif hour in [12, 13, 14]:  # Lunch
            base_congestion = np.random.uniform(30, 55)
            traffic_level = np.random.choice(["Low-Medium", "Medium", "High"], p=[0.3, 0.5, 0.2])
        elif hour >= 22 or hour <= 5:  # Night
            base_congestion = np.random.uniform(5, 20)
            traffic_level = np.random.choice(["Low", "Low-Medium"], p=[0.8, 0.2])
        else:
            base_congestion = np.random.uniform(20, 45)
            traffic_level = np.random.choice(["Low-Medium", "Medium"], p=[0.5, 0.5])
        
        delay_factor = {
            "Low": 1.0, "Low-Medium": 1.15, "Medium": 1.30,
            "High": 1.60, "Severe": 2.00, "Gridlock": 2.50
        }.get(traffic_level, 1.0)
        
        severity = {
            "Low": 1, "Low-Medium": 2, "Medium": 2,
            "High": 3, "Severe": 4, "Gridlock": 5
        }.get(traffic_level, 1)
        
        return {
            "traffic_level": traffic_level,
            "congestion_pct": round(base_congestion, 1),
            "delay_factor": delay_factor,
            "severity_level": severity,
            "avg_speed_kmh": round(np.random.uniform(15, 45), 1),
            "free_flow_speed_kmh": round(np.random.uniform(40, 60), 1),
            "active_incidents": np.random.randint(0, 5),
            "is_peak_hour": hour in [8, 9, 10, 17, 18, 19],
        }
    
    def _generate_simulated_traffic(self) -> pd.DataFrame:
        """Generate simulated traffic data for all routes."""
        records = []
        
        for route in ROUTES:
            hour = datetime.now().hour
            distance = np.random.uniform(5, 15)
            free_flow_speed = np.random.uniform(45, 60)
            free_flow_time = distance / free_flow_speed * 3600
            
            # Add traffic delay
            if hour in [17, 18, 19]:
                multiplier = np.random.uniform(1.5, 2.5)
            elif hour in [8, 9, 10]:
                multiplier = np.random.uniform(1.3, 2.0)
            else:
                multiplier = np.random.uniform(1.0, 1.5)
            
            traffic_time = free_flow_time * multiplier
            traffic_level, delay_factor, severity = self.calculate_traffic_level(
                int(traffic_time), int(free_flow_time)
            )
            
            records.append({
                "route_name": route["name"],
                "observation_timestamp": datetime.now().isoformat(),
                "traffic_date": datetime.now().strftime("%Y-%m-%d"),
                "traffic_hour": hour,
                "distance_km": round(distance, 2),
                "traffic_level": traffic_level,
                "delay_factor": delay_factor,
                "severity_level": severity,
                "congestion_pct": round((1 - 1/multiplier) * 100, 1),
                "avg_speed_kmh": round(distance / traffic_time * 3600, 1),
                "free_flow_speed_kmh": round(free_flow_speed, 1),
            })
        
        return pd.DataFrame(records)
    
    def save_to_bronze(self, df: pd.DataFrame) -> str:
        """Save traffic data to Bronze layer."""
        output_dir = Path(DATA_DIR) / datetime.now().strftime("%Y/%m/%d")
        output_dir.mkdir(parents=True, exist_ok=True)
        
        output_file = output_dir / f"traffic_{datetime.now().strftime('%Y%m%d_%H%M%S')}.parquet"
        df.to_parquet(output_file, index=False)
        
        logger.info(f"✅ Saved {len(df)} records to {output_file}")
        return str(output_file)


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax Traffic API Connector")
    parser.add_argument("--routes", nargs="+", help="Specific routes to fetch")
    parser.add_argument("--output-dir", type=str, default=DATA_DIR, help="Output directory")
    parser.add_argument("--simulated", action="store_true", help="Force simulated data")
    args = parser.parse_args()
    
    connector = TrafficAPIConnector()
    
    if args.simulated or not API_KEY:
        df = connector._generate_simulated_traffic()
    else:
        df = connector.fetch_all_routes()
    
    output_path = connector.save_to_bronze(df)
    
    print(f"\n📊 Traffic Summary:")
    print(f"  Records: {len(df)}")
    print(f"  Avg Congestion: {df['congestion_pct'].mean():.1f}%")
    print(f"  Worst Route: {df.loc[df['congestion_pct'].idxmax(), 'route_name']}")
    print(f"  Saved to: {output_path}")


if __name__ == "__main__":
    main()