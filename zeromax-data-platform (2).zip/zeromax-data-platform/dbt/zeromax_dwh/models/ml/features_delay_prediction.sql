{{
  config(
    materialized='table',
    tags=['ml', 'feature_store', 'delay_prediction'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE ml_engineer"
    ]
  )
}}

-- ============================================================
-- ML FEATURE STORE: FEATURES_DELAY_PREDICTION
-- ============================================================
-- Feature engineering for delivery delay prediction model.
-- Target: delay_min (regression) or delay_category (classification)
-- ============================================================

WITH feature_base AS (
    SELECT
        fd.delivery_sk,
        fd.delivery_id,
        fd.order_datetime,
        
        -- ==========================================
        -- TARGET VARIABLE
        -- ==========================================
        fd.delay_min AS target_delay_min,
        CASE 
            WHEN fd.delay_min <= 5 THEN 0     -- On-Time
            WHEN fd.delay_min <= 15 THEN 1     -- Minor Delay
            WHEN fd.delay_min <= 30 THEN 2     -- Moderate Delay
            ELSE 3                              -- Major Delay
        END AS target_delay_class,
        
        -- ==========================================
        -- TEMPORAL FEATURES
        -- ==========================================
        EXTRACT(HOUR FROM fd.order_datetime) AS order_hour,
        EXTRACT(DOW FROM fd.order_datetime) AS order_day_of_week,
        EXTRACT(MONTH FROM fd.order_datetime) AS order_month,
        CASE WHEN EXTRACT(DOW FROM fd.order_datetime) IN (5, 6) THEN 1 ELSE 0 END AS is_weekend,
        CASE WHEN EXTRACT(HOUR FROM fd.order_datetime) IN (12, 13, 14, 18, 19, 20, 21) THEN 1 ELSE 0 END AS is_peak_hour,
        CASE WHEN EXTRACT(HOUR FROM fd.order_datetime) >= 22 OR EXTRACT(HOUR FROM fd.order_datetime) <= 4 THEN 1 ELSE 0 END AS is_night,
        
        -- ==========================================
        -- DISTANCE FEATURES
        -- ==========================================
        fd.distance_km,
        fd.optimal_distance_km,
        fd.route_efficiency_pct,
        CASE WHEN fd.distance_km > 8 THEN 1 ELSE 0 END AS is_long_distance,
        ROUND(fd.distance_km / NULLIF(fd.optimal_distance_km, 0), 2) AS route_inefficiency_ratio,
        
        -- ==========================================
        -- RESTAURANT FEATURES
        -- ==========================================
        fd.preparation_time_min,
        fd.restaurant_avg_prep_time,
        CASE WHEN fd.restaurant_avg_prep_time > 15 THEN 1 ELSE 0 END AS is_slow_restaurant,
        fd.restaurant_type,
        
        -- ==========================================
        -- DRIVER FEATURES
        -- ==========================================
        fd.experience_level,
        fd.speed_factor,
        fd.efficiency_score,
        fd.fatigue_factor,
        CASE 
            WHEN fd.experience_level IN ('Trainee', 'Junior') THEN 1 
            ELSE 0 
        END AS is_inexperienced_driver,
        CASE WHEN fd.fatigue_factor < 1.0 THEN 1 ELSE 0 END AS is_fatigued,
        
        -- ==========================================
        -- VEHICLE FEATURES
        -- ==========================================
        fd.vehicle_category,
        fd.vehicle_speed,
        CASE WHEN fd.vehicle_category = 'Bike' THEN 1 ELSE 0 END AS is_bike,
        CASE WHEN fd.vehicle_category = 'Rickshaw' THEN 1 ELSE 0 END AS is_rickshaw,
        
        -- ==========================================
        -- ENVIRONMENTAL FEATURES
        -- ==========================================
        fd.weather_condition,
        fd.weather_severity,
        fd.temperature_c,
        fd.humidity_pct,
        fd.wind_speed_kmh,
        fd.weather_delay_multiplier,
        CASE WHEN fd.weather_severity >= 3 THEN 1 ELSE 0 END AS is_severe_weather,
        CASE WHEN fd.weather_condition IN ('Rain', 'Thunderstorm', 'Dust Storm') THEN 1 ELSE 0 END AS is_hazardous_weather,
        
        -- Traffic
        fd.traffic_level,
        fd.traffic_severity,
        fd.traffic_delay_multiplier,
        fd.congestion_pct,
        CASE WHEN fd.traffic_severity >= 3 THEN 1 ELSE 0 END AS is_heavy_traffic,
        
        -- Combined severity
        fd.severity_index,
        (fd.weather_severity * fd.traffic_severity) AS weather_traffic_interaction,
        
        -- ==========================================
        -- ZONE FEATURES
        -- ==========================================
        fd.delivery_zone,
        fd.zone_traffic_factor,
        
        -- ==========================================
        -- CALENDAR FEATURES
        -- ==========================================
        CASE WHEN fd.is_ramadan THEN 1 ELSE 0 END AS is_ramadan,
        CASE WHEN fd.is_eid THEN 1 ELSE 0 END AS is_eid,
        CASE WHEN fd.is_holiday THEN 1 ELSE 0 END AS is_holiday,
        CASE WHEN fd.is_friday THEN 1 ELSE 0 END AS is_friday,
        
        -- ==========================================
        -- PAYMENT FEATURES
        -- ==========================================
        CASE WHEN fd.is_cod THEN 1 ELSE 0 END AS is_cod,
        
        -- ==========================================
        -- DERIVED FEATURES
        -- ==========================================
        -- Speed adjusted for conditions
        ROUND(fd.vehicle_speed * fd.speed_factor * (1 / NULLIF(fd.traffic_delay_multiplier, 1)), 1) AS effective_speed,
        
        -- Expected vs actual ratio
        ROUND(fd.expected_duration_min * 1.0 / NULLIF(fd.promised_duration_min, 0), 2) AS expected_vs_promised_ratio,
        
        -- Time pressure indicator
        CASE WHEN fd.promised_duration_min - fd.expected_duration_min < 10 THEN 1 ELSE 0 END AS is_tight_deadline,
        
        -- Distance per minute capacity
        ROUND(fd.distance_km * 1.0 / NULLIF(fd.promised_duration_min, 0) * 60, 2) AS required_speed_kmh,
        
        -- Pickup delay indicator
        CASE WHEN fd.pickup_delay_min > 5 THEN 1 ELSE 0 END AS has_pickup_delay
        
    FROM {{ ref('fct_delivery') }} fd
    WHERE fd.delivery_status IN ('On-Time', 'Late')  -- Exclude failed deliveries
      AND fd.order_datetime >= DATEADD(month, -6, CURRENT_DATE())
)

SELECT
    *,
    
    -- ==========================================
    -- FEATURE ENCODING (One-Hot)
    -- ==========================================
    
    -- Experience one-hot
    CASE WHEN experience_level = 'Trainee' THEN 1 ELSE 0 END AS exp_trainee,
    CASE WHEN experience_level = 'Junior' THEN 1 ELSE 0 END AS exp_junior,
    CASE WHEN experience_level = 'Intermediate' THEN 1 ELSE 0 END AS exp_intermediate,
    CASE WHEN experience_level = 'Senior' THEN 1 ELSE 0 END AS exp_senior,
    CASE WHEN experience_level = 'Expert' THEN 1 ELSE 0 END AS exp_expert,
    CASE WHEN experience_level = 'Veteran' THEN 1 ELSE 0 END AS exp_veteran,
    
    -- Vehicle one-hot
    CASE WHEN vehicle_category = 'Bike' THEN 1 ELSE 0 END AS veh_bike,
    CASE WHEN vehicle_category = 'Car' THEN 1 ELSE 0 END AS veh_car,
    CASE WHEN vehicle_category = 'Rickshaw' THEN 1 ELSE 0 END AS veh_rickshaw,
    
    -- Time period one-hot
    CASE WHEN order_hour BETWEEN 5 AND 8 THEN 1 ELSE 0 END AS time_early_morning,
    CASE WHEN order_hour BETWEEN 9 AND 11 THEN 1 ELSE 0 END AS time_morning,
    CASE WHEN order_hour BETWEEN 12 AND 15 THEN 1 ELSE 0 END AS time_lunch,
    CASE WHEN order_hour BETWEEN 16 AND 17 THEN 1 ELSE 0 END AS time_afternoon,
    CASE WHEN order_hour BETWEEN 18 AND 21 THEN 1 ELSE 0 END AS time_dinner,
    CASE WHEN order_hour >= 22 OR order_hour <= 4 THEN 1 ELSE 0 END AS time_night,
    
    -- Weather severity one-hot
    CASE WHEN weather_severity = 1 THEN 1 ELSE 0 END AS weather_favorable,
    CASE WHEN weather_severity = 2 THEN 1 ELSE 0 END AS weather_minor,
    CASE WHEN weather_severity = 3 THEN 1 ELSE 0 END AS weather_moderate,
    CASE WHEN weather_severity >= 4 THEN 1 ELSE 0 END AS weather_severe,
    
    -- Traffic one-hot
    CASE WHEN traffic_level IN ('Low', 'Low-Medium') THEN 1 ELSE 0 END AS traffic_light,
    CASE WHEN traffic_level = 'Medium' THEN 1 ELSE 0 END AS traffic_medium,
    CASE WHEN traffic_level = 'High' THEN 1 ELSE 0 END AS traffic_heavy,
    CASE WHEN traffic_level IN ('Severe', 'Gridlock') THEN 1 ELSE 0 END AS traffic_critical,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS feature_generated_at,
    'features_delay_prediction' AS feature_source

FROM feature_base