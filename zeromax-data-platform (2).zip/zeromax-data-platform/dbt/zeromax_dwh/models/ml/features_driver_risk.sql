{{
  config(
    materialized='table',
    tags=['ml', 'feature_store', 'driver_risk'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE ml_engineer"
    ]
  )
}}

-- ============================================================
-- ML FEATURE STORE: FEATURES_DRIVER_RISK
-- ============================================================
-- Feature engineering for driver risk scoring model.
-- Target: Driver performance degradation / churn risk
-- ============================================================

WITH driver_history AS (
    SELECT
        fd.driver_sk,
        fd.driver_id,
        fd.driver_name,
        fd.experience_level,
        fd.vehicle_category,
        fd.driver_home_zone,
        
        -- ==========================================
        -- AGGREGATED METRICS (Last 90 days)
        -- ==========================================
        COUNT(DISTINCT fd.delivery_sk) AS deliveries_90d,
        COUNT(DISTINCT DATE_TRUNC('day', fd.order_datetime)) AS active_days_90d,
        
        -- Quality metrics
        ROUND(AVG(fd.customer_rating), 2) AS avg_rating_90d,
        ROUND(AVG(fd.delay_min), 1) AS avg_delay_90d,
        SUM(fd.is_on_time) AS on_time_count_90d,
        SUM(fd.is_late) AS late_count_90d,
        SUM(fd.is_failed) AS failed_count_90d,
        
        -- Efficiency
        ROUND(AVG(fd.route_efficiency_pct), 1) AS avg_route_efficiency_90d,
        ROUND(AVG(fd.distance_km), 2) AS avg_distance_90d,
        ROUND(AVG(fd.delivery_duration_min), 1) AS avg_delivery_time_90d,
        
        -- Financial
        SUM(fd.profit_pkr) AS total_profit_90d,
        SUM(fd.delay_penalty_pkr) AS total_penalties_90d,
        
        -- Peak performance
        COUNT(CASE WHEN fd.is_peak_hour THEN 1 END) AS peak_deliveries_90d,
        COUNT(CASE WHEN fd.is_night THEN 1 END) AS night_deliveries_90d,
        
        -- Weather resilience
        ROUND(AVG(CASE WHEN fd.weather_severity >= 3 THEN fd.customer_rating END), 2) AS rating_bad_weather,
        ROUND(AVG(CASE WHEN fd.weather_severity <= 1 THEN fd.customer_rating END), 2) AS rating_good_weather,
        
        -- Fatigue
        ROUND(AVG(fd.fatigue_factor), 3) AS avg_fatigue_90d,
        MAX(fd.deliveries_so_far_today) AS max_daily_deliveries_90d
        
    FROM {{ ref('fct_delivery') }} fd
    WHERE fd.order_datetime >= DATEADD(day, -90, CURRENT_DATE())
    GROUP BY fd.driver_sk, fd.driver_id, fd.driver_name, 
             fd.experience_level, fd.vehicle_category, fd.driver_home_zone
),

-- Trend analysis (compare last 30 days vs previous 30 days)
driver_trends AS (
    SELECT
        fd.driver_sk,
        
        -- Last 30 days
        ROUND(AVG(CASE WHEN fd.order_datetime >= DATEADD(day, -30, CURRENT_DATE()) 
                  THEN fd.customer_rating END), 2) AS rating_last_30d,
        ROUND(AVG(CASE WHEN fd.order_datetime >= DATEADD(day, -30, CURRENT_DATE()) 
                  THEN fd.delay_min END), 1) AS delay_last_30d,
        SUM(CASE WHEN fd.order_datetime >= DATEADD(day, -30, CURRENT_DATE()) 
            THEN fd.profit_pkr END) AS profit_last_30d,
        
        -- Previous 30 days (30-60 days ago)
        ROUND(AVG(CASE WHEN fd.order_datetime BETWEEN DATEADD(day, -60, CURRENT_DATE()) 
                  AND DATEADD(day, -30, CURRENT_DATE())
                  THEN fd.customer_rating END), 2) AS rating_prev_30d,
        ROUND(AVG(CASE WHEN fd.order_datetime BETWEEN DATEADD(day, -60, CURRENT_DATE()) 
                  AND DATEADD(day, -30, CURRENT_DATE())
                  THEN fd.delay_min END), 1) AS delay_prev_30d
        
    FROM {{ ref('fct_delivery') }} fd
    WHERE fd.order_datetime >= DATEADD(day, -60, CURRENT_DATE())
    GROUP BY fd.driver_sk
)

SELECT
    dh.driver_sk,
    dh.driver_id,
    dh.driver_name,
    dh.experience_level,
    dh.vehicle_category,
    dh.driver_home_zone,
    
    -- ==========================================
    -- TARGET INDICATORS
    -- ==========================================
    -- Performance decline (rating drop > 0.5)
    CASE 
        WHEN dh.avg_rating_90d < 3.5 THEN 1 
        WHEN dt.rating_last_30d < dt.rating_prev_30d - 0.5 THEN 1
        ELSE 0 
    END AS target_performance_decline,
    
    -- High penalty ratio
    CASE 
        WHEN dh.total_penalties_90d * 1.0 / NULLIF(dh.total_profit_90d, 0) > 0.2 THEN 1 
        ELSE 0 
    END AS target_high_penalty,
    
    -- ==========================================
    -- FEATURES
    -- ==========================================
    
    -- Volume features
    dh.deliveries_90d,
    dh.active_days_90d,
    ROUND(dh.deliveries_90d * 1.0 / NULLIF(dh.active_days_90d, 0), 1) AS deliveries_per_day,
    
    -- Quality features
    dh.avg_rating_90d,
    dh.avg_delay_90d,
    ROUND(dh.on_time_count_90d * 100.0 / NULLIF(dh.deliveries_90d, 0), 1) AS on_time_rate_90d,
    ROUND(dh.failed_count_90d * 100.0 / NULLIF(dh.deliveries_90d, 0), 1) AS failure_rate_90d,
    
    -- Trend features
    dt.rating_last_30d,
    dt.delay_last_30d,
    dt.rating_prev_30d,
    dt.delay_prev_30d,
    ROUND(dt.rating_last_30d - dt.rating_prev_30d, 2) AS rating_trend,
    ROUND(dt.delay_last_30d - dt.delay_prev_30d, 1) AS delay_trend,
    
    -- Efficiency features
    dh.avg_route_efficiency_90d,
    dh.avg_distance_90d,
    dh.avg_delivery_time_90d,
    
    -- Financial features
    dh.total_profit_90d,
    dh.total_penalties_90d,
    ROUND(dh.total_penalties_90d * 100.0 / NULLIF(dh.total_profit_90d, 0), 2) AS penalty_ratio,
    
    -- Work pattern features
    dh.peak_deliveries_90d,
    dh.night_deliveries_90d,
    ROUND(dh.peak_deliveries_90d * 100.0 / NULLIF(dh.deliveries_90d, 0), 1) AS peak_ratio,
    ROUND(dh.night_deliveries_90d * 100.0 / NULLIF(dh.deliveries_90d, 0), 1) AS night_ratio,
    
    -- Weather resilience
    dh.rating_bad_weather,
    dh.rating_good_weather,
    ROUND(dh.rating_bad_weather - dh.rating_good_weather, 2) AS weather_impact_on_rating,
    
    -- Fatigue features
    dh.avg_fatigue_90d,
    dh.max_daily_deliveries_90d,
    
    -- ==========================================
    -- DERIVED RISK FEATURES
    -- ==========================================
    
    -- Performance volatility
    CASE WHEN ABS(dt.rating_last_30d - dt.rating_prev_30d) > 1.0 THEN 1 ELSE 0 END AS is_performance_volatile,
    
    -- Declining trend
    CASE WHEN dt.rating_last_30d < dt.rating_prev_30d 
         AND dt.delay_last_30d > dt.delay_prev_30d THEN 1 ELSE 0 END AS is_declining,
    
    -- Overwork indicator
    CASE WHEN dh.deliveries_per_day > 15 OR dh.max_daily_deliveries_90d > 20 THEN 1 ELSE 0 END AS is_overworked,
    
    -- Bad weather sensitivity
    CASE WHEN dh.rating_bad_weather < dh.rating_good_weather - 1.0 THEN 1 ELSE 0 END AS is_weather_sensitive,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS feature_generated_at,
    'features_driver_risk' AS feature_source

FROM driver_history dh
LEFT JOIN driver_trends dt ON dh.driver_sk = dt.driver_sk