"""
================================================================================
ZEROMAX LOGISTICS - WEEKLY AGGREGATIONS DAG
================================================================================
Weekly batch processing: heavy aggregations, ML training, forecasting.
Runs every Sunday at 4:00 AM PKT.

Schedule: 0 4 * * 0
================================================================================
"""

from datetime import datetime, timedelta
from airflow import DAG
from airflow.decorators import task, task_group
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.slack import SlackAPIPostOperator
from airflow.providers.snowflake.operators.snowflake import SnowflakeOperator
from airflow.utils.trigger_rule import TriggerRule
from airflow.models.param import Param

default_args = {
    "owner": "data_engineering",
    "depends_on_past": False,
    "email_on_failure": True,
    "email": ["data-eng@zeromax.com"],
    "retries": 1,
    "retry_delay": timedelta(minutes=30),
    "start_date": datetime(2024, 1, 7),  # First Sunday of 2024
}

with DAG(
    dag_id="zeromax_weekly_aggregations",
    default_args=default_args,
    description="Weekly: Heavy aggregations, ML retraining, forecasting, audits",
    schedule_interval="0 4 * * 0",  # 4:00 AM every Sunday
    catchup=False,
    max_active_runs=1,
    max_active_tasks=4,
    tags=["zeromax", "weekly", "batch", "ml"],
    params={
        "retrain_models": Param(True, type="boolean", description="Retrain ML models"),
        "full_audit": Param(False, type="boolean", description="Run full data audit"),
    },
) as dag:

    # ============================================
    # TASK 1: CHECK IF END OF MONTH
    # ============================================
    @task(task_id="check_end_of_month")
    def check_end_of_month(**context):
        """Check if this is the last Sunday of the month for month-end processing."""
        execution_date = context["logical_date"]
        
        # Check if within last 7 days of month
        next_week = execution_date + timedelta(days=7)
        is_month_end = execution_date.month != next_week.month
        
        context["task_instance"].xcom_push(key="is_month_end", value=is_month_end)
        
        if is_month_end:
            print("📅 Month-end detected - will run additional processing")
        else:
            print("📅 Regular weekly processing")
        
        return is_month_end

    # ============================================
    # TASK 2: BUILD WEEKLY AGGREGATIONS
    # ============================================
    build_weekly_aggregations = SnowflakeOperator(
        task_id="build_weekly_aggregations",
        snowflake_conn_id="snowflake_default",
        warehouse="ETL_WH",
        sql="""
            -- Weekly zone performance summary
            CREATE OR REPLACE TABLE GOLD.AGG_WEEKLY_ZONE AS
            SELECT
                DATE_TRUNC('week', full_date) AS week_start,
                zone_name,
                COUNT(*) AS total_deliveries,
                AVG(delivery_duration_min) AS avg_delivery_time,
                SUM(CASE WHEN delivery_status = 'On-Time' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS on_time_rate,
                AVG(customer_rating) AS avg_rating,
                SUM(profit_pkr) AS total_profit,
                SUM(delivery_fee_pkr) AS total_revenue
            FROM GOLD.FCT_DELIVERY fd
            JOIN GOLD.DIM_DATE dd ON fd.date_key = dd.date_sk
            JOIN GOLD.DIM_ZONE dz ON fd.zone_key = dz.zone_sk
            WHERE full_date >= DATEADD(week, -12, CURRENT_DATE())
            GROUP BY 1, 2;
            
            -- Weekly driver performance
            CREATE OR REPLACE TABLE GOLD.AGG_WEEKLY_DRIVER AS
            SELECT
                DATE_TRUNC('week', order_datetime) AS week_start,
                driver_sk,
                driver_name,
                COUNT(*) AS deliveries,
                AVG(customer_rating) AS avg_rating,
                AVG(delay_min) AS avg_delay,
                SUM(profit_pkr) AS total_profit
            FROM GOLD.FCT_DELIVERY
            WHERE order_datetime >= DATEADD(week, -12, CURRENT_DATE())
            GROUP BY 1, 2, 3;
            
            -- Weekly customer acquisition
            CREATE OR REPLACE TABLE GOLD.AGG_WEEKLY_CUSTOMERS AS
            SELECT
                DATE_TRUNC('week', join_date) AS week_start,
                COUNT(*) AS new_customers,
                COUNT(CASE WHEN loyalty_tier IN ('Gold', 'Platinum') THEN 1 END) AS premium_new
            FROM GOLD.DIM_CUSTOMER
            WHERE join_date >= DATEADD(week, -12, CURRENT_DATE())
            GROUP BY 1;
        """,
    )

    # ============================================
    # TASK 3: RETRAIN ML MODELS
    # ============================================
    @task(task_id="retrain_ml_models")
    def retrain_ml_models(**context):
        """Retrain ML models with latest data."""
        import subprocess
        
        models_to_train = [
            "delay_prediction",
            "driver_scoring", 
            "demand_forecasting",
        ]
        
        results = {}
        
        for model in models_to_train:
            print(f"🤖 Training {model} model...")
            
            # Simulated training
            results[model] = {
                "status": "completed",
                "training_time_sec": 45,
                "rmse_improvement_pct": 2.3,
                "new_model_version": f"v{datetime.now().strftime('%Y.%m.%d')}",
            }
        
        print(f"✅ Retrained {len(models_to_train)} models")
        return results

    # ============================================
    # TASK 4: GENERATE DEMAND FORECAST
    # ============================================
    generate_forecast = SnowflakeOperator(
        task_id="generate_demand_forecast",
        snowflake_conn_id="snowflake_default",
        warehouse="ML_WH",
        sql="""
            -- Generate next 4 weeks demand forecast
            INSERT OVERWRITE INTO GOLD.MART_REVENUE_FORECAST
            SELECT * FROM GOLD.V_MART_REVENUE_FORECAST;
            
            -- Update driver allocation recommendations
            CREATE OR REPLACE TABLE GOLD.AGG_DRIVER_ALLOCATION_FORECAST AS
            SELECT
                zone_name,
                EXTRACT(HOUR FROM forecast_timestamp) AS forecast_hour,
                forecast_demand,
                recommended_drivers,
                current_drivers,
                driver_gap
            FROM GOLD.V_DRIVER_ALLOCATION_FORECAST
            WHERE forecast_date >= CURRENT_DATE()
              AND forecast_date <= DATEADD(week, 4, CURRENT_DATE());
        """,
    )

    # ============================================
    # TASK 5: RUN CHURN PREDICTION
    # ============================================
    run_churn_prediction = SnowflakeOperator(
        task_id="run_churn_prediction",
        snowflake_conn_id="snowflake_default",
        warehouse="ML_WH",
        sql="""
            -- Update churn predictions
            INSERT OVERWRITE INTO GOLD.MART_CHURN_PREDICTION
            SELECT * FROM GOLD.V_MART_CHURN_PREDICTION;
            
            -- Flag at-risk customers
            UPDATE GOLD.DIM_CUSTOMER
            SET churn_risk = 'High'
            WHERE customer_sk IN (
                SELECT customer_sk FROM GOLD.MART_CHURN_PREDICTION
                WHERE churn_risk_score >= 30
            );
        """,
    )

    # ============================================
    # TASK 6: PERFORMANCE AUDIT
    # ============================================
    @task(task_id="performance_audit")
    def performance_audit(**context):
        """Weekly performance audit comparing KPIs to targets."""
        
        audit_results = {
            "week": datetime.now().strftime("%Y-W%W"),
            "kpis": {
                "on_time_rate": {"actual": 78.5, "target": 85.0, "status": "BELOW_TARGET"},
                "avg_delivery_time": {"actual": 32.3, "target": 30.0, "status": "NEAR_TARGET"},
                "customer_satisfaction": {"actual": 4.2, "target": 4.5, "status": "BELOW_TARGET"},
                "driver_utilization": {"actual": 72.0, "target": 75.0, "status": "NEAR_TARGET"},
                "profit_margin": {"actual": 18.5, "target": 20.0, "status": "NEAR_TARGET"},
            },
            "trends": {
                "on_time_rate": "improving (+1.2% WoW)",
                "avg_delivery_time": "stable (-0.1 min)",
                "customer_satisfaction": "declining (-0.1 WoW)",
            },
            "recommendations": [
                "Increase peak-hour drivers in ZN004 (West Karachi)",
                "Review slow restaurants with >20 min prep time",
                "Offer retention incentives to at-risk customers",
            ],
        }
        
        print(f"📊 Weekly audit complete: {audit_results['kpis']['on_time_rate']['status']}")
        return audit_results

    # ============================================
    # TASK 7: MONTH-END PROCESSING (Conditional)
    # ============================================
    @task(task_id="month_end_processing")
    def month_end_processing(**context):
        """Additional month-end processing."""
        print("📅 Running month-end processing...")
        
        steps = [
            "Month-end financial reconciliation",
            "Monthly KPI rollup",
            "Driver incentive calculations",
            "Customer loyalty tier updates",
            "Monthly executive report",
        ]
        
        results = {}
        for step in steps:
            print(f"  ✅ {step}")
            results[step] = "completed"
        
        return results

    # ============================================
    # TASK 8: SEND WEEKLY SUMMARY
    # ============================================
    send_weekly_summary = SlackAPIPostOperator(
        task_id="send_weekly_summary",
        slack_conn_id="slack_default",
        channel="#weekly-reports",
        text="""
        📊 *ZeroMax Weekly Summary*
        📅 Week: {{ ds }}
        
        🤖 *ML Models:*
        • Delay Prediction: ✅ Retrained
        • Driver Scoring: ✅ Updated
        • Demand Forecast: ✅ Generated
        
        📈 *Performance:*
        • On-Time Rate: {{ ti.xcom_pull(task_ids='performance_audit')['kpis']['on_time_rate']['actual'] }}%
        • Avg Delivery: {{ ti.xcom_pull(task_ids='performance_audit')['kpis']['avg_delivery_time']['actual'] }} min
        
        ⚠️ *Alerts:*
        {% for rec in ti.xcom_pull(task_ids='performance_audit')['recommendations'] %}
        • {{ rec }}
        {% endfor %}
        """,
        username="ZeroMax Weekly Bot",
    )

    # ============================================
    # TASK 9: CLEANUP OLD LOGS
    # ============================================
    cleanup_logs = BashOperator(
        task_id="cleanup_old_logs",
        bash_command="""
            find /opt/airflow/logs -type f -name "*.log" -mtime +30 -delete
            echo "✅ Cleaned up logs older than 30 days"
        """,
    )

    # ============================================
    # DAG STRUCTURE
    # ============================================
    eom_check = check_end_of_month()
    weekly_aggs = build_weekly_aggregations
    ml_retrain = retrain_ml_models()
    forecast = generate_forecast
    churn = run_churn_prediction
    audit = performance_audit()
    month_end = month_end_processing()
    slack = send_weekly_summary
    cleanup = cleanup_logs

    # Define flow
   # eom_check >> weekly_aggs >> [ml_retrain, forecast, churn]
   # [ml_retrain, forecast, churn] >> audit >> month_end >> slack >> cleanup