{{
  config(
    materialized='table',
    tags=['gold', 'dimension', 'payment', 'reference'],
    post_hook=[
      "GRANT SELECT ON {{ this }} TO ROLE reporter"
    ]
  )
}}

-- ============================================================
-- GOLD LAYER: DIM_PAYMENT
-- ============================================================
-- Payment method reference dimension.
-- Maps payment types to fees, processing times, and categories.
-- ============================================================

WITH payment_methods AS (
    SELECT * FROM (VALUES
        ('Credit Card', 2.5, 0, FALSE, 'Digital', 'Visa/Mastercard credit cards'),
        ('Debit Card', 1.8, 0, FALSE, 'Digital', 'Bank debit cards'),
        ('Cash on Delivery', 0.0, 2, TRUE, 'Cash', 'Cash payment at delivery'),
        ('JazzCash', 1.5, 1, FALSE, 'Mobile Wallet', 'JazzCash mobile wallet'),
        ('Easypaisa', 1.5, 1, FALSE, 'Mobile Wallet', 'Easypaisa mobile wallet'),
        ('Bank Transfer', 0.5, 5, FALSE, 'Bank', 'Direct bank transfer'),
        ('Digital Wallet', 1.2, 0, FALSE, 'Mobile Wallet', 'Other digital wallets')
    ) AS p(method, fee_pct, processing_min, is_cod, category, description)
)

SELECT
    -- Surrogate Key
    ROW_NUMBER() OVER (ORDER BY category, fee_pct) AS payment_sk,
    
    -- Payment Attributes
    method AS payment_method,
    fee_pct,
    processing_min,
    is_cod,
    category AS payment_category,
    description AS payment_description,
    
    -- Derived Attributes
    
    -- Is Digital
    CASE WHEN category IN ('Digital', 'Mobile Wallet') THEN TRUE ELSE FALSE END AS is_digital,
    
    -- Is Instant
    CASE WHEN processing_min = 0 THEN TRUE ELSE FALSE END AS is_instant,
    
    -- Fee Tier
    CASE
        WHEN fee_pct = 0 THEN 'No Fee'
        WHEN fee_pct <= 1.0 THEN 'Low Fee'
        WHEN fee_pct <= 2.0 THEN 'Medium Fee'
        ELSE 'High Fee'
    END AS fee_tier,
    
    -- Processing Category
    CASE
        WHEN processing_min = 0 THEN 'Instant'
        WHEN processing_min <= 2 THEN 'Quick'
        ELSE 'Delayed'
    END AS processing_category,
    
    -- Cost Impact on Profit
    CASE
        WHEN fee_pct = 0 THEN 'No Impact'
        WHEN fee_pct <= 1.5 THEN 'Low Impact'
        WHEN fee_pct <= 2.0 THEN 'Medium Impact'
        ELSE 'High Impact'
    END AS profit_impact,
    
    -- Adoption Priority (encourage lower fee methods)
    CASE
        WHEN fee_pct <= 1.0 AND processing_min <= 1 THEN 'Encourage'
        WHEN fee_pct <= 2.0 THEN 'Acceptable'
        WHEN fee_pct > 2.0 THEN 'Discourage'
        ELSE 'Neutral'
    END AS adoption_strategy,
    
    -- Metadata
    CURRENT_TIMESTAMP() AS dw_created_at,
    'dim_payment' AS dw_source

FROM payment_methods