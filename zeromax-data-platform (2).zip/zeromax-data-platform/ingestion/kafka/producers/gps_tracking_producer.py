"""
================================================================================
ZEROMAX LOGISTICS - GPS TRACKING KAFKA PRODUCER
================================================================================
Produces simulated GPS tracking events for active deliveries.
Simulates real-time driver location updates.

Usage:
    python gps_tracking_producer.py
    python gps_tracking_producer.py --drivers 50 --interval 5
================================================================================
"""

import os
import sys
import json
import time
import random
import logging
import math
from datetime import datetime
from typing import Dict, List, Tuple

from confluent_kafka import Producer
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger(__name__)

KAFKA_CONFIG = {
    "bootstrap.servers": os.getenv("KAFKA_BOOTSTRAP_SERVERS", "localhost:9092"),
    "client.id": "zeromax-gps-producer",
    "acks": 1,
    "compression.type": "lz4",
    "linger.ms": 10,
}

GPS_TOPIC = "zeromax.gps_tracking"

# Karachi central point
KARACHI_CENTER = (24.8607, 67.0011)

# Major routes in Karachi
ROUTES = [
    {"name": "Shahrah-e-Faisal", "start": (24.8700, 67.0500), "end": (24.8500, 67.1200)},
    {"name": "M.A. Jinnah Road", "start": (24.8600, 67.0200), "end": (24.8800, 67.0400)},
    {"name": "University Road", "start": (24.9100, 67.0800), "end": (24.8900, 67.1100)},
    {"name": "Korangi Road", "start": (24.8200, 67.0800), "end": (24.8400, 67.1300)},
    {"name": "Northern Bypass", "start": (24.9500, 67.0500), "end": (24.9200, 66.9800)},
]


class DriverSimulator:
    """Simulates a single driver's GPS movements."""
    
    def __init__(self, driver_id: str, route: Dict):
        self.driver_id = driver_id
        self.route = route
        self.route_name = route["name"]
        self.current_lat, self.current_lon = route["start"]
        self.target_lat, self.target_lon = route["end"]
        self.speed = random.uniform(20, 50)  # km/h
        self.heading = self._calculate_heading()
        self.is_returning = False
        self.stops_remaining = random.randint(1, 5)
        self.battery = random.randint(30, 100)
        
    def _calculate_heading(self) -> float:
        """Calculate heading in degrees."""
        d_lon = self.target_lon - self.current_lon
        d_lat = self.target_lat - self.current_lat
        return math.degrees(math.atan2(d_lon, d_lat)) % 360
    
    def _haversine_distance(self, lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """Calculate distance between two points in km."""
        R = 6371
        d_lat = math.radians(lat2 - lat1)
        d_lon = math.radians(lon2 - lon1)
        a = (math.sin(d_lat / 2) ** 2 + 
             math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * 
             math.sin(d_lon / 2) ** 2)
        return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    
    def update_position(self) -> Dict:
        """Update driver position and return GPS event."""
        # Move towards target
        distance_to_target = self._haversine_distance(
            self.current_lat, self.current_lon,
            self.target_lat, self.target_lon
        )
        
        # Calculate step size (km per update)
        step_size = self.speed / 3600 * 5  # 5 second intervals
        
        if distance_to_target < step_size:
            # Reached destination, turn around or pick new target
            if self.stops_remaining > 0:
                self.stops_remaining -= 1
                # Pick a random point within 2km
                self.target_lat = self.current_lat + random.uniform(-0.02, 0.02)
                self.target_lon = self.current_lon + random.uniform(-0.02, 0.02)
            else:
                # Return to start
                self.target_lat, self.target_lon = self.route["start"]
                self.stops_remaining = random.randint(1, 5)
                self.is_returning = not self.is_returning
            
            self.heading = self._calculate_heading()
        else:
            # Move step_size towards target
            ratio = step_size / distance_to_target
            self.current_lat += (self.target_lat - self.current_lat) * ratio
            self.current_lon += (self.target_lon - self.current_lon) * ratio
        
        # Add some noise
        self.current_lat += random.uniform(-0.0001, 0.0001)
        self.current_lon += random.uniform(-0.0001, 0.0001)
        
        # Vary speed slightly
        self.speed += random.uniform(-2, 2)
        self.speed = max(5, min(60, self.speed))
        
        # Decrease battery
        self.battery = max(0, self.battery - random.uniform(0, 0.05))
        if self.battery < 10:
            self.battery = random.randint(70, 100)  # "Recharged"
        
        # Generate event
        event = {
            "driver_id": self.driver_id,
            "delivery_id": f"DLV{random.randint(1, 25000):06d}",
            "timestamp": datetime.now().isoformat(),
            "latitude": round(self.current_lat, 6),
            "longitude": round(self.current_lon, 6),
            "speed_kmh": round(self.speed, 1),
            "heading": round(self.heading, 1),
            "battery_pct": round(self.battery, 1),
            "route_name": self.route_name,
            "accuracy_m": random.choice([5, 10, 15, 20]),
            "satellites": random.randint(4, 12),
            "is_moving": self.speed > 2,
        }
        
        return event


class GPSTrackingProducer:
    """Produces GPS tracking events for multiple drivers."""
    
    def __init__(self):
        self.producer = Producer(KAFKA_CONFIG)
        self.drivers: List[DriverSimulator] = []
        
    def add_driver(self, driver_id: str, route: Dict = None) -> None:
        """Add a new driver to simulate."""
        if route is None:
            route = random.choice(ROUTES)
        driver = DriverSimulator(driver_id, route)
        self.drivers.append(driver)
        logger.info(f"Added driver {driver_id} on route: {driver.route_name}")
    
    def delivery_callback(self, err, msg):
        """Callback for message delivery."""
        if err:
            logger.error(f"Delivery failed: {err}")
    
    def produce_events(self) -> int:
        """Produce one GPS event per driver."""
        events_produced = 0
        
        for driver in self.drivers:
            event = driver.update_position()
            
            self.producer.produce(
                topic=GPS_TOPIC,
                key=driver.driver_id.encode("utf-8"),
                value=json.dumps(event).encode("utf-8"),
                callback=self.delivery_callback,
            )
            events_produced += 1
        
        self.producer.poll(0)
        return events_produced
    
    def flush(self):
        """Flush all pending messages."""
        self.producer.flush()


def main():
    """Main producer loop."""
    import argparse
    
    parser = argparse.ArgumentParser(description="ZeroMax GPS Tracking Producer")
    parser.add_argument("--drivers", type=int, default=50, help="Number of drivers to simulate")
    parser.add_argument("--interval", type=float, default=5.0, help="Update interval in seconds")
    parser.add_argument("--duration", type=int, default=0, help="Duration in seconds (0=infinite)")
    args = parser.parse_args()
    
    producer = GPSTrackingProducer()
    
    # Create drivers
    for i in range(1, args.drivers + 1):
        driver_id = f"DRV{i:04d}"
        route = random.choice(ROUTES)
        producer.add_driver(driver_id, route)
    
    logger.info(f"Starting GPS tracking for {args.drivers} drivers")
    logger.info(f"Update interval: {args.interval}s")
    logger.info("Press Ctrl+C to stop")
    
    start_time = time.time()
    events_total = 0
    
    try:
        while True:
            events = producer.produce_events()
            events_total += events
            
            if events_total % 500 == 0:
                producer.flush()
                elapsed = time.time() - start_time
                rate = events_total / elapsed if elapsed > 0 else 0
                logger.info(f"📍 GPS events: {events_total} total ({rate:.1f} events/sec)")
            
            if args.duration > 0 and (time.time() - start_time) > args.duration:
                break
            
            time.sleep(args.interval)
            
    except KeyboardInterrupt:
        logger.info("\nShutting down...")
    finally:
        producer.flush()
        elapsed = time.time() - start_time
        logger.info(f"✅ Total: {events_total} GPS events in {elapsed:.1f}s")


if __name__ == "__main__":
    main()